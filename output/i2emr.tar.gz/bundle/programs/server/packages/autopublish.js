(function () {



/* Exports */
Package._define("autopublish");

})();
