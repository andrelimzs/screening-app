var require = meteorInstall({"imports":{"api":{"formLayouts.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/formLayouts.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  formLayouts: () => formLayouts
});
let React, Component, Fragment;
module.link("react", {
  default(v) {
    React = v;
  },

  Component(v) {
    Component = v;
  },

  Fragment(v) {
    Fragment = v;
  }

}, 0);
let Divider;
module.link("@material-ui/core/Divider", {
  default(v) {
    Divider = v;
  }

}, 1);
let Typography;
module.link("@material-ui/core/Typography", {
  default(v) {
    Typography = v;
  }

}, 2);
let formSchemas;
module.link("/imports/api/formSchemas", {
  formSchemas(v) {
    formSchemas = v;
  }

}, 3);
let AutoForm;
module.link("uniforms-material/AutoForm", {
  default(v) {
    AutoForm = v;
  }

}, 4);
let AutoField;
module.link("uniforms-material/AutoField", {
  default(v) {
    AutoField = v;
  }

}, 5);
let TextField;
module.link("uniforms-material/TextField", {
  default(v) {
    TextField = v;
  }

}, 6);
let SubmitField;
module.link("uniforms-material/SubmitField", {
  default(v) {
    SubmitField = v;
  }

}, 7);
let SelectField;
module.link("uniforms-material/SelectField", {
  default(v) {
    SelectField = v;
  }

}, 8);
let HiddenField;
module.link("uniforms-material/HiddenField", {
  default(v) {
    HiddenField = v;
  }

}, 9);
let NumField;
module.link("uniforms-material/NumField", {
  default(v) {
    NumField = v;
  }

}, 10);
let ListField;
module.link("uniforms-material/ListField", {
  default(v) {
    ListField = v;
  }

}, 11);
let DateField;
module.link("uniforms-material/DateField", {
  default(v) {
    DateField = v;
  }

}, 12);
let RadioField;
module.link("uniforms-material/RadioField", {
  default(v) {
    RadioField = v;
  }

}, 13);
let BoolField;
module.link("uniforms-material/BoolField", {
  default(v) {
    BoolField = v;
  }

}, 14);
let LongTextField;
module.link("uniforms-material/LongTextField", {
  default(v) {
    LongTextField = v;
  }

}, 15);
let BaseField;
module.link("uniforms/BaseField", {
  default(v) {
    BaseField = v;
  }

}, 16);
let nothing;
module.link("uniforms/nothing", {
  default(v) {
    nothing = v;
  }

}, 17);
let Children;
module.link("react", {
  Children(v) {
    Children = v;
  }

}, 18);
let Radio;
module.link("@material-ui/core", {
  Radio(v) {
    Radio = v;
  }

}, 19);

// Define DisplayIf
// Used to display fields depending on another field's response
const DisplayIf = ({
  children,
  condition
}, {
  uniforms
}) => condition(uniforms) ? Children.only(children) : nothing;

DisplayIf.contextTypes = BaseField.contextTypes;

const requireDoctorConsult = info => React.createElement(Fragment, null, (typeof info["Height & weight"] !== "undefined" && info["Height & weight"][0].docConsultForHW || typeof info["Blood Glucose & Hb"] !== "undefined" && info["Blood Glucose & Hb"][0].docConsultForBloodGlucAndHb || typeof info["Pap Smear"] !== "undefined" && info["Pap Smear"][0].docConsultForPap || typeof info["Blood Pressure"] !== "undefined" && info["Blood Pressure"][0].docConsultForBP) && React.createElement(Divider, null) && React.createElement(Typography, {
  color: "secondary",
  variant: "h6"
}, "Require consult for:"), typeof info["Height & weight"] !== "undefined" && info["Height & weight"][0].docConsultForHW && React.createElement(Typography, {
  color: "secondary"
}, "Height and Weight"), typeof info["Blood Glucose & Hb"] !== "undefined" && info["Blood Glucose & Hb"][0].docConsultForBloodGlucAndHb && React.createElement(Typography, {
  color: "secondary"
}, "Blood Glucose and Hb"), typeof info["Pap Smear"] !== "undefined" && info["Pap Smear"][0].docConsultForPap && React.createElement(Typography, {
  color: "secondary"
}, "Pap Smear"), typeof info["Blood Pressure"] !== "undefined" && info["Blood Pressure"][0].docConsultForBP && React.createElement(Typography, {
  color: "secondary"
}, "Blood Pressure") && React.createElement(Divider, null)); // Define the layouts


const formLayouts = {
  "Registration": {
    "Patient Info": info => React.createElement(Fragment, null, React.createElement(TextField, {
      name: "name"
    }), React.createElement(SelectField, {
      name: "gender"
    }), "Enter birthdate in dd/mm/yyyy format", React.createElement(TextField, {
      name: "birthday"
    }), React.createElement(NumField, {
      name: "age",
      decimal: false
    }), React.createElement(Divider, {
      variant: "middle"
    }), React.createElement(TextField, {
      name: "district"
    }), React.createElement(TextField, {
      name: "address"
    }), React.createElement(TextField, {
      name: "zipcode",
      decimal: false
    }), React.createElement("br", null), React.createElement(TextField, {
      name: "contactNumber",
      decimal: false
    }), React.createElement(AutoField, {
      name: "spokenLanguages"
    }), React.createElement(AutoField, {
      name: "writtenLanguages"
    }), React.createElement(Divider, {
      variant: "middle"
    }), React.createElement(RadioField, {
      name: "anyDrugAllergies"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.anyDrugAllergies === "Yes"
    }, React.createElement(TextField, {
      name: "drugAllergies"
    })), React.createElement(Divider, {
      variant: "middle"
    }), React.createElement(RadioField, {
      name: "pregnant"
    })),
    "Patient Profiling": info => React.createElement(Fragment, null, React.createElement("h2", null, "Diabetes Mellitus"), "Has a western-trained doctor ever told you that you have diabetes?", React.createElement(RadioField, {
      name: "patientProfile1"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.patientProfile1 === "No"
    }, React.createElement(Fragment, null, "If no to Q1, when was the last time you checked your blood sugar?", React.createElement(SelectField, {
      name: "patientProfile2"
    }), "If no to Q1, do you have any of the following symptoms? (select all that apply)", React.createElement(AutoField, {
      name: "patientProfile3"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.patientProfile1 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q1, how often are you seeing your doctor for your diabetes?", React.createElement(SelectField, {
      name: "patientProfile4"
    }), "If yes to Q1, are you taking any medication for your diabetes? If so, can you name them?", React.createElement(BoolField, {
      name: "anyWesternMedicine"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.anyWesternMedicine === true
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "westernMedicine"
    }), "If yes to Western medicine, how many times do you forget to take your diabetes medication in a week?", React.createElement(SelectField, {
      name: "patientProfile6"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.patientProfile1 === "Yes"
    }, React.createElement(Fragment, null, React.createElement(BoolField, {
      name: "anyTraditionalMedicine"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.anyTraditionalMedicine === true
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "traditionalMedicine"
    }))), React.createElement("h2", null, "Hyperlipidemia"), "Has a western-trained doctor ever told you that you have high cholesterol?", React.createElement(RadioField, {
      name: "hyperlipidemiaQ1"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.hyperlipidemiaQ1 === "No"
    }, React.createElement(Fragment, null, "If no to Q1, when was the last time you checked your blood cholesterol?", React.createElement(SelectField, {
      name: "hyperlipidemiaQ2"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.hyperlipidemiaQ1 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q1, how often are you seeing your doctor for your high cholesterol?", React.createElement(SelectField, {
      name: "hyperlipidemiaQ3"
    }), "If yes to Q1, are you taking any medication for your high cholesterol? If so, can you name them?", React.createElement(BoolField, {
      name: "hyperlipidemiaAnyWesternMedicine"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.hyperlipidemiaAnyWesternMedicine === true
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "hyperlipidemiaWesternMedicine"
    }), "If yes to taking Western medicine, how many times do you forget to take your high cholesterol medication in a week?", React.createElement(SelectField, {
      name: "hyperlipidemiaQ5"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.hyperlipidemiaQ1 === "Yes"
    }, React.createElement(Fragment, null, React.createElement(BoolField, {
      name: "hyperlipidemiaAnyTraditionalMedicine"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.hyperlipidemiaAnyTraditionalMedicine === true
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "hyperlipidemiaTraditionalMedicine"
    }))))), React.createElement("h2", null, "Hypertension"), "Has a western-trained doctor ever told you that you have high blood pressure (BP)?", React.createElement(RadioField, {
      name: "hypertensionQ1"
    }), "When was the last time you checked your blood pressure?", React.createElement(SelectField, {
      name: "hypertensionQ2"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.hypertensionQ1 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q1, how often are you seeing your doctor for your high blood pressure?", React.createElement(SelectField, {
      name: "hypertensionQ3"
    }), "If yes to Q1, are you taking any medication for your high blood pressure? If so, can you name them?", React.createElement(BoolField, {
      name: "hypertensionAnyWesternMedicine"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.hypertensionAnyWesternMedicine === true
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "hypertensionWesternMedicine"
    }), "If yes to taking Western medicine, how many times do you forget to take your high blood pressure medication in a week?", React.createElement(SelectField, {
      name: "hypertensionQ5"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.hypertensionQ1 === "Yes"
    }, React.createElement(Fragment, null, React.createElement(BoolField, {
      name: "hypertensionAnyTraditionalMedicine"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.hypertensionAnyTraditionalMedicine === true
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "hypertensionTraditionalMedicine"
    }))))), React.createElement("h2", null, "TB Screening"), "Have you ever been diagnosed with tuberculosis?", React.createElement(RadioField, {
      name: "TBQ1"
    }), "Have you ever lived with someone with tuberculosis?", React.createElement(SelectField, {
      name: "TBQ2"
    }), "Do you have any of the following symptoms? Select all that apply", React.createElement(AutoField, {
      name: "TBQ3"
    }), React.createElement("h2", null, "Medical history: others"), "Do you have any medical conditions we should take note of? (if none, indicate NIL)", React.createElement(TextField, {
      name: "medicalHistory1"
    }), "How are you managing these conditions? (check-ups, medicines, diet/exercise, others)", React.createElement(TextField, {
      name: "medicalHistory2"
    }), "Where do you go to for routine healthcare?", React.createElement(TextField, {
      name: "medicalHistory3"
    }), "Where do you go to for emergency medical services (eg. fall, injury, fainting)?", React.createElement(TextField, {
      name: "medicalHistory4"
    }), "Are you taking any other medications? (If yes, indicate what medication and why. If none, indicate NIL)", React.createElement(TextField, {
      name: "medicalHistory5"
    }), React.createElement("h2", null, "Surgery and hospitalisations"), "Have you had any surgery previously?", React.createElement(RadioField, {
      name: "surgAndHospQ1"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.surgAndHospQ1 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q1, what surgery?", React.createElement(TextField, {
      name: "surgAndHospQ2"
    }))), "Have you been hospitalised in the past 5 years?", React.createElement(RadioField, {
      name: "surgAndHospQ3"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.surgAndHospQ3 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q3, why were you hospitalised?", React.createElement(TextField, {
      name: "surgAndHospQ4"
    }))), React.createElement("h2", null, "Ocular History"), "Have you had any eye surgeries?", React.createElement(RadioField, {
      name: "ocularHisQ1a"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.ocularHisQ1a === "Yes"
    }, React.createElement(Fragment, null, "If yes to 1a, please specify", React.createElement(TextField, {
      name: "ocularHisQ1b"
    }))), "Any previous trauma to the eye?", React.createElement(RadioField, {
      name: "ocularHisQ2a"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.ocularHisQ2a === "Yes"
    }, React.createElement(Fragment, null, "If yes to 2a, please specify", React.createElement(TextField, {
      name: "ocularHisQ2b"
    }))), "Are you under the care of any eye specialist or receiving treatment for the eye from any hospital/clinic?", React.createElement(RadioField, {
      name: "ocularHisQ3a"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.ocularHisQ3a === "Yes"
    }, React.createElement(Fragment, null, "If yes to 3a, please specify where", React.createElement(TextField, {
      name: "ocularHisQ3b"
    }), "If yes to 3a, when was your last review?", React.createElement(TextField, {
      name: "ocularHisQ3c"
    }), "If yes to 3a, what was the condition?", React.createElement(AutoField, {
      name: "ocularHisQ3d"
    }))), React.createElement(DisplayIf, {
      condition: context => Array.isArray(context.model.ocularHisQ3d) && context.model.ocularHisQ3d.includes('Others (please specify)')
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "otherOcularCond"
    }))), "Have you had any falls in the last 1 year?", React.createElement(RadioField, {
      name: "ocularHisQ4"
    }), "How do you perceive your vision?", React.createElement(SelectField, {
      name: "ocularHisQ5a"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.ocularHisQ5a === "Poor"
    }, React.createElement(Fragment, null, "If answer to 5a was 'Poor', do you intend to seek medical help?", React.createElement(RadioField, {
      name: "ocularHisQ5b"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.ocularHisQ5b === "No"
    }, React.createElement(Fragment, null, "If no to 5b, why?", React.createElement(AutoField, {
      name: "ocularHisQ5c"
    }))), React.createElement(DisplayIf, {
      condition: context => Array.isArray(context.model.ocularHisQ5c) && context.model.ocularHisQ5c.includes('Others (please specify)')
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "otherReasons"
    }))), React.createElement("h2", null, "Barriers to Healthcare"), "What type of doctor do you see for your existing conditions?", React.createElement(SelectField, {
      name: "barrierQ1"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.barrierQ1 === "Seldom/Never visits the doctor"
    }, React.createElement(Fragment, null, "If answer to Q1 was 'Seldom/Never visits the doctor', why do you not follow-up with your doctor for your existing conditions?", React.createElement(BoolField, {
      name: "noNeed"
    }), React.createElement(BoolField, {
      name: "time"
    }), React.createElement(BoolField, {
      name: "mobility"
    }), React.createElement(BoolField, {
      name: "financial"
    }), React.createElement(BoolField, {
      name: "scared"
    }), React.createElement(BoolField, {
      name: "preferTradMed"
    }), React.createElement(BoolField, {
      name: "anyOtherBarriers"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.anyOtherBarriers === true
    }, React.createElement(Fragment, null, React.createElement(TextField, {
      name: "otherBarriers"
    }))), React.createElement("h2", null, "Family History"), "Do your parents, siblings or children have any of the following conditions? Note: CAD = coronary artery disease (narrowed blood vessels supplying heart muscle)", React.createElement(AutoField, {
      name: "familyHistory"
    }), React.createElement("h2", null, "Framingham Lipids Risk Stratification"), "Has a doctor told you that you have any heart problems? If yes, please elaborate", React.createElement(TextField, {
      name: "FLRSQ1"
    }), "Have you ever been diagnosed by your doctor to have a stroke?", React.createElement(RadioField, {
      name: "FLRSQ2"
    }), "Has your doctor ever told you that you have any problems with your blood vessels/blood flow? If yes, please elaborate", React.createElement(TextField, {
      name: "FLRSQ3"
    }), "Have you ever been diagnosed by your doctor to have chronic kidney disease?", React.createElement(RadioField, {
      name: "FLRSQ4"
    }), "Do you currently smoke?", React.createElement(RadioField, {
      name: "FLRSQ5"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.FLRSQ5 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q5, what do you smoke? (select all that apply)", React.createElement(AutoField, {
      name: "FLRSQ6"
    }), "If yes to Q5, how much do you smoke?", React.createElement(SelectField, {
      name: "FLRSQ7"
    }), "If yes to Q5, how many years have you been smoking for?", React.createElement(TextField, {
      name: "FLRSQ8"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.FLRSQ5 === "No"
    }, React.createElement(Fragment, null, "If no to Q5, have you ever smoked before?", React.createElement(SelectField, {
      name: "FLRSQ9"
    }))), "Do you chew paan or tobacco?", React.createElement(RadioField, {
      name: "FLRSQ10"
    }), React.createElement("h2", null, "Social History"), "Do you drink alcohol?", React.createElement(RadioField, {
      name: "socialHisQ1"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.socialHisQ1 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q1, how many glasses of alcohol do you drink per day?", React.createElement("br", null), React.createElement(NumField, {
      name: "socialHisQ2"
    }), React.createElement("br", null))), "What is your occupation?", React.createElement(BoolField, {
      name: "student"
    }), React.createElement(BoolField, {
      name: "housewife"
    }), React.createElement(BoolField, {
      name: "relig"
    }), React.createElement(BoolField, {
      name: "prof"
    }), React.createElement(BoolField, {
      name: "service"
    }), React.createElement(BoolField, {
      name: "manual"
    }), React.createElement(BoolField, {
      name: "skilledLab"
    }), React.createElement(BoolField, {
      name: "farming"
    }), React.createElement(BoolField, {
      name: "mining"
    }), React.createElement(BoolField, {
      name: "manu"
    }), React.createElement(BoolField, {
      name: "unemployed"
    }), React.createElement(BoolField, {
      name: "anyOtherOcc"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.anyOtherOcc === true
    }, React.createElement(Fragment, null, "If yes to Q1, how many glasses of alcohol do you drink per day?", React.createElement(TextField, {
      name: "otherOcc"
    }))), "Nature of work/lifestyle", React.createElement(SelectField, {
      name: "socialHisQ4"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.socialHisQ3 === "Farming/Agriculture"
    }, React.createElement(Fragment, null, "If answer to Q3 is 'Farming/agriculture', do you use pesticides in your farming?", React.createElement(RadioField, {
      name: "socialHisQ5"
    }))), "Monthly Income in INR (only if participant is willing to disclose)", React.createElement("br", null), React.createElement(NumField, {
      name: "socialHisQ6"
    }), React.createElement(Divider, {
      variant: "middle"
    }), "Marital status", React.createElement(SelectField, {
      name: "socialHisQ7"
    }), "Number of children", React.createElement("br", null), React.createElement(NumField, {
      name: "socialHisQ8"
    }), React.createElement(Divider, {
      variant: "middle"
    }), "How many people live in your household (including you)?", React.createElement("br", null), React.createElement(NumField, {
      name: "socialHisQ9"
    }), React.createElement(Divider, {
      variant: "middle"
    }), "How many dependents are there in your household (children, spouse, parents, relatives living with you who rely on you for financial support)?", React.createElement(NumField, {
      name: "socialHisQ10"
    }), React.createElement(Divider, {
      variant: "middle"
    }), "How many people in your household contribute to household income?", React.createElement("br", null), React.createElement(NumField, {
      name: "socialHisQ11"
    }), React.createElement(Divider, {
      variant: "middle"
    }), "How many people in your household do not contribute to or depend on household income? (KIV)", React.createElement(Divider, {
      variant: "middle"
    }), "What is your highest education level?", React.createElement(SelectField, {
      name: "socialHisQ13"
    })),
    "Station Selection": info => React.createElement(Fragment, null, React.createElement("h2", null, "Height and Weight + Waist:Hip measurement"), "Can we measure your height, weight, waist size and hip size?", React.createElement(RadioField, {
      name: "stationSelect1"
    }), React.createElement("h2", null, "Blood glucose and Hb"), "Can we check your blood sugar? This will be done by pricking your finger to get a small drop of blood", React.createElement(RadioField, {
      name: "stationSelect2"
    }), "Can we check if you have anemia? This will be done by pricking your finger to get a small drop of blood", React.createElement(RadioField, {
      name: "stationSelect3"
    }), React.createElement("h2", null, "BP"), "Can we check your blood pressure?", React.createElement(RadioField, {
      name: "stationSelect4"
    }), React.createElement("h2", null, "Phlebotomy (for patients aged 40 years old and above)"), "For patients aged 40 years old and above, Do you have the following conditions?", React.createElement(AutoField, {
      name: "stationSelect5"
    }), React.createElement(DisplayIf, {
      condition: context => Array.isArray(context.model.stationSelect5) && context.model.stationSelect5.length >= 2
    }, React.createElement(Fragment, null, "Can we do a blood test to see if you have high cholesterol? A blood sample will be taken by a trained staff. This will then be sent to the lab, and a report will be mailed to you after some time", React.createElement(RadioField, {
      name: "stationSelect6"
    }))), React.createElement("h2", null, "Pap Smear"), "Are you married (or have you ever been married)?", React.createElement(RadioField, {
      name: "stationSelect7"
    }), React.createElement(DisplayIf, {
      condition: context => context.model.stationSelect7 === "Yes"
    }, React.createElement(Fragment, null, "If yes to Q7, have you done a Pap smear in the past 3 years?", React.createElement(RadioField, {
      name: "stationSelect8"
    }))), React.createElement(DisplayIf, {
      condition: context => context.model.stationSelect8 === "No"
    }, React.createElement(Fragment, null, "If no to Q8, would you want to undergo a free Pap smear today to check for cervical cancer?", React.createElement(RadioField, {
      name: "stationSelect9"
    }))), React.createElement("h2", null, "Breast"), "Would you want to undergo a breast examination for breast cancer today?", React.createElement(RadioField, {
      name: "stationSelect10"
    }), React.createElement("h2", null, "Women's Edu"), "Can we teach you about women's health? For adults, we will be sharing about menstrual health and breast self examinations. For girls aged 10-18 years old, we will be sharing about menstrual health only.", React.createElement(RadioField, {
      name: "stationSelect11"
    }), React.createElement("h2", null, "Doctors' consult"), "Would you like to see a doctor today? (You will be asked to see the doctor if your test results are abnormal, but would you otherwise want to see the doctor?)", React.createElement(RadioField, {
      name: "stationSelect12"
    }), React.createElement("h2", null, "Eye screening"), "Can we check your eyes/vision?", React.createElement(RadioField, {
      name: "stationSelect13"
    }), React.createElement("h2", null, "Education"), "Can we teach you about healthy lifestyles and how to prevent common diseases like diabetes and high blood pressure?", React.createElement(RadioField, {
      name: "stationSelect14"
    }))
  },
  "Height & weight": info => React.createElement(Fragment, null, React.createElement("h2", null, "Height and Weight"), React.createElement(TextField, {
    name: "height"
  }), React.createElement("br", null), React.createElement(TextField, {
    name: "weight"
  }), React.createElement("br", null), React.createElement("h2", null, "Waist:Hip"), React.createElement(TextField, {
    name: "waist"
  }), React.createElement("br", null), React.createElement(TextField, {
    name: "hip"
  }), React.createElement("br", null), React.createElement("h2", null, "Overview"), React.createElement(BoolField, {
    name: "docConsultForHW"
  })),
  "Blood Glucose & Hb": info => React.createElement(Fragment, null, React.createElement(TextField, {
    name: "cbg"
  }), React.createElement("br", null), React.createElement(TextField, {
    name: "hb"
  }), React.createElement("br", null), React.createElement(BoolField, {
    name: "docConsultForBloodGlucAndHb"
  })),
  "Blood Pressure": info => React.createElement(Fragment, null, React.createElement("div", null, React.createElement(TextField, {
    name: "bp1Sys"
  })), React.createElement("div", null, React.createElement(TextField, {
    name: "bp1Dia"
  })), React.createElement("div", null, React.createElement(TextField, {
    name: "bp2Sys"
  })), React.createElement("div", null, React.createElement(TextField, {
    name: "bp2Dia"
  })), React.createElement(DisplayIf, {
    condition: context => Math.abs(context.model.bp2Sys - context.model.bp1Sys) > 5 || Math.abs(context.model.bp2Dia - context.model.bp1Dia) > 5
  }, React.createElement(Fragment, null, React.createElement("div", null, React.createElement(TextField, {
    name: "bp3Sys"
  })), React.createElement("div", null, React.createElement(TextField, {
    name: "bp3Dia"
  })))), React.createElement("div", null, React.createElement(BoolField, {
    name: "docConsultForBP"
  }))),
  "Phlebotomy": info => React.createElement(Fragment, null, React.createElement(BoolField, {
    name: "phleboCompleted"
  })),
  "Pap Smear": info => React.createElement(Fragment, null, React.createElement(BoolField, {
    name: "papCompleted"
  }), React.createElement(LongTextField, {
    name: "papNotes"
  }), React.createElement(BoolField, {
    name: "docConsultForPap"
  })),
  "Breast Exam": info => React.createElement(Fragment, null, React.createElement(BoolField, {
    name: "abnormalities"
  }), React.createElement(DisplayIf, {
    condition: context => context.model.abnormalities === true
  }, React.createElement(Fragment, null, React.createElement(LongTextField, {
    name: "abDescribe"
  }))), React.createElement(BoolField, {
    name: "fnacCompleted"
  }), React.createElement(BoolField, {
    name: "eduCompleted"
  })),
  "Women's Edu": {
    "Pre-Women's Education Quiz": info => React.createElement(Fragment, null, "Completed breast examination?", React.createElement(BoolField, {
      name: "breastCompleted"
    }), "From a scale of 1-5, how much do you know about menstrual cycles? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "preWomenEduSurvey1"
    }), "Which of the following is/are normal symptom(s) of menstrual periods?", React.createElement(SelectField, {
      name: "preWomenEduQ1"
    }), "All of the following are reasons for missed periods except", React.createElement(SelectField, {
      name: "preWomenEduQ2"
    }), "Which of the following is true about menstruation", React.createElement(SelectField, {
      name: "preWomenEduQ3"
    }), "When is the best time to do a breast self examination?", React.createElement(SelectField, {
      name: "preWomenEduQ4"
    }), "How often should you do a breast self examination?", React.createElement(SelectField, {
      name: "preWomenEduQ5"
    }), "You should go to the doctor if you notice:", React.createElement(SelectField, {
      name: "preWomenEduQ6"
    })),
    "Post-Women's Education Quiz": info => React.createElement(Fragment, null, "From a scale of 1-5, how much do you know about menstrual cycles? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "postWomenEduSurvey1"
    }), "Which of the following is/are normal symptom(s) of menstrual periods?", React.createElement(SelectField, {
      name: "postWomenEduQ1"
    }), "All of the following are reasons for missed periods except", React.createElement(SelectField, {
      name: "postWomenEduQ2"
    }), "Which of the following is true about menstruation", React.createElement(SelectField, {
      name: "postWomenEduQ3"
    }), "When is the best time to do a breast self examination?", React.createElement(SelectField, {
      name: "postWomenEduQ4"
    }), "How often should you do a breast self examination?", React.createElement(SelectField, {
      name: "postWomenEduQ5"
    }), "You should go to the doctor if you notice:", React.createElement(SelectField, {
      name: "postWomenEduQ6"
    }))
  },
  "Doctors' Consult": info => React.createElement(Fragment, null, requireDoctorConsult(info), "Chief complaint", React.createElement(SelectField, {
    name: "docConsult1"
  }), React.createElement(DisplayIf, {
    condition: context => Array.isArray(context.model.docConsult1) && context.model.docConsult1.includes('Others (free text)')
  }, React.createElement(Fragment, null, "Other complaints", React.createElement(TextField, {
    name: "otherComplaints"
  }))), "Doctors' notes/advice", React.createElement(LongTextField, {
    name: "docConsult2"
  }), React.createElement(BoolField, {
    name: "docConsult3"
  }), React.createElement(DisplayIf, {
    condition: context => context.model.docConsult3 === true
  }, React.createElement(Fragment, null, "Referral details", React.createElement(LongTextField, {
    name: "docConsult4"
  }))), "Name of doctor", React.createElement(TextField, {
    name: "docConsult5"
  })),
  "Eye Screening": info => React.createElement(Fragment, null, React.createElement(BoolField, {
    name: "specs"
  }), React.createElement(TextField, {
    name: "rightWoGlass"
  }), React.createElement(TextField, {
    name: "leftWoGlass"
  }), React.createElement(TextField, {
    name: "rightWiGlass"
  }), React.createElement(TextField, {
    name: "leftWiGlass"
  }), React.createElement(TextField, {
    name: "rightNearVis"
  }), React.createElement(TextField, {
    name: "leftNearVis"
  }), React.createElement(LongTextField, {
    name: "lids"
  }), React.createElement(LongTextField, {
    name: "conjunctiva"
  }), React.createElement(LongTextField, {
    name: "cornea"
  }), React.createElement(LongTextField, {
    name: "antSeg"
  }), React.createElement(LongTextField, {
    name: "iris"
  }), React.createElement(LongTextField, {
    name: "pupil"
  }), React.createElement(LongTextField, {
    name: "lens"
  }), React.createElement(LongTextField, {
    name: "ocuMvmt"
  }), React.createElement(LongTextField, {
    name: "iop"
  }), React.createElement(LongTextField, {
    name: "duct"
  }), React.createElement(LongTextField, {
    name: "cdr"
  }), React.createElement(LongTextField, {
    name: "macula"
  }), React.createElement(LongTextField, {
    name: "retina"
  }), React.createElement(LongTextField, {
    name: "diagnosis"
  }), React.createElement(LongTextField, {
    name: "advice"
  }), React.createElement(LongTextField, {
    name: "nameDoc"
  })),
  "Education": {
    "Pre-Education Survey": info => React.createElement(Fragment, null, requireDoctorConsult(info), "From a scale of 1-5, how much do you know about metabolic syndrome (Hypertension, Hyperlipidemia, Obesity, High Blood Sugar)? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "preEduSurvey1"
    }), "From a scale of 1-5, how much do you know about healthy lifestyle and diet? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "preEduSurvey2"
    }), "From a scale of 1-5, how much do you know about cancer risk factors? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "preEduSurvey3"
    }), "From a scale of 1-5, how much do you know about good eyecare habits? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "preEduSurvey4"
    })),
    "Pre-Education Quiz": info => React.createElement(Fragment, null, requireDoctorConsult(info), React.createElement(Divider, {
      variant: "middle"
    }), "You are at higher risk of developing high cholesterol if you", React.createElement(SelectField, {
      name: "preEduQuiz1"
    }), "All of the following are complications of diabetes except", React.createElement(SelectField, {
      name: "preEduQuiz2"
    }), "How much exercise should we get a week?", React.createElement(SelectField, {
      name: "preEduQuiz3"
    }), "What makes up a healthy plate?", React.createElement(SelectField, {
      name: "preEduQuiz4"
    }), "Which of the following is the healthier choice to make?", React.createElement(SelectField, {
      name: "preEduQuiz5"
    }), "Which of the following is a cancer risk factor(s)?", React.createElement(SelectField, {
      name: "preEduQuiz6"
    }), "Which of the following is not considered good eyecare habits?", React.createElement(SelectField, {
      name: "preEduQuiz7"
    })),
    "Post-Education Survey": info => React.createElement(Fragment, null, requireDoctorConsult(info), "From a scale of 1-5, how much do you know about metabolic syndrome (Hypertension, Hyperlipidemia, Obesity, High Blood Sugar)? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "postEduSurvey1"
    }), "From a scale of 1-5, how much do you know about healthy lifestyle and diet? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "postEduSurvey2"
    }), "From a scale of 1-5, how much do you know about cancer risk factors? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "postEduSurvey3"
    }), "From a scale of 1-5, how much do you know about good eyecare habits? 1 being not at all, and 5 being a lot", React.createElement(SelectField, {
      name: "postEduSurvey4"
    })),
    "Post-Education Quiz": info => React.createElement(Fragment, null, requireDoctorConsult(info), "You are at higher risk of developing high cholesterol if you", React.createElement(SelectField, {
      name: "postEduQuiz1"
    }), "All of the following are complications of diabetes except", React.createElement(SelectField, {
      name: "postEduQuiz2"
    }), "How much exercise should we get a week?", React.createElement(SelectField, {
      name: "postEduQuiz3"
    }), "What makes up a healthy plate?", React.createElement(SelectField, {
      name: "postEduQuiz4"
    }), "Which of the following is the healthier choice to make?", React.createElement(SelectField, {
      name: "postEduQuiz5"
    }), "Which of the following is a cancer risk factor(s)?", React.createElement(SelectField, {
      name: "postEduQuiz6"
    }), "Which of the following is not considered good eyecare habits?", React.createElement(SelectField, {
      name: "postEduQuiz7"
    }))
  },
  "Post-Screening Feedback": info => React.createElement(Fragment, null, "I have had a good experience at the screening", React.createElement(SelectField, {
    name: "postScreeningFeedback1"
  }), "I came for the screening because: (Select all that apply)", React.createElement(AutoField, {
    name: "postScreeningFeedback2"
  }), "I know that regular health screening is important", React.createElement(SelectField, {
    name: "postScreeningFeedback3"
  }), "I know that it is important to detect chronic diseases and cancers early", React.createElement(SelectField, {
    name: "postScreeningFeedback4"
  }), "I am willing to take the trouble to attend health screenings", React.createElement(SelectField, {
    name: "postScreeningFeedback5"
  }), "I am willing to attend my follow-up sessions", React.createElement(SelectField, {
    name: "postScreeningFeedback6"
  }), "The student volunteers attended to my needs", React.createElement(SelectField, {
    name: "postScreeningFeedback7"
  }), "The student volunteers were well-trained", React.createElement(SelectField, {
    name: "postScreeningFeedback8"
  }), "The waiting time to enter the screening was reasonable", React.createElement(SelectField, {
    name: "postScreeningFeedback9"
  }), "The waiting time for each station was reasonable", React.createElement(SelectField, {
    name: "postScreeningFeedback10"
  }), "The flow of the screening was easy to follow", React.createElement(SelectField, {
    name: "postScreeningFeedback11"
  }), "I would recommend my family/friends to attend this screening", React.createElement(SelectField, {
    name: "postScreeningFeedback12"
  }), "What encouraged you to come for our event? Select all that apply", React.createElement(AutoField, {
    name: "postScreeningFeedback13"
  }), "How often do you attend a health screening?", React.createElement(SelectField, {
    name: "postScreeningFeedback14"
  }))
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"formSchemas.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/formSchemas.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  formSchemas: () => formSchemas
});
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let Patientinfo;
module.link("/imports/api/patientinfo", {
  default(v) {
    Patientinfo = v;
  }

}, 1);
// Customise validation error messages
SimpleSchema.setDefaultMessages({
  messages: {
    en: {
      "IDnotUnique": "ID is already registered"
    }
  }
}); // Define the schema

const formSchemas = {
  "Registration": {
    "Patient Info": new SimpleSchema({
      name: {
        type: String,
        regEx: /^\D+$/,
        label: "Name"
      },
      // id: {
      //   type: String,
      //   regEx: /^[0-9]+$/,
      // },
      gender: {
        type: String,
        allowedValues: ['male', 'female']
      },
      birthday: {
        type: String,
        regEx: /^[0-9]{1,2}\/[0-9]{1,2}\/[1-2][0-9]{3}$/
      },
      age: {
        type: SimpleSchema.Integer,
        min: 0,
        autoValue: function () {
          const birthdate = this.siblingField("birthday").value;
          const currentYear = new Date();
          const birthYear = Number(birthdate.substring(birthdate.length - 4, birthdate.length));
          const age = currentYear.getFullYear() - birthYear;
          return age;
        }
      },
      district: {
        type: String
      },
      address: {
        type: String
      },
      zipcode: {
        type: String,
        regEx: /^[0-9]+$/
      },
      contactNumber: {
        type: String,
        regEx: /^[0-9]+$/
      },
      spokenLanguages: {
        type: Array
      },
      'spokenLanguages.$': {
        type: String,
        allowedValues: ['Sambalpuri', 'Odia', 'English', 'Others']
      },
      writtenLanguages: {
        type: Array
      },
      'writtenLanguages.$': {
        type: String,
        allowedValues: ['Sambalpuri', 'Odia', 'English', 'Others']
      },
      anyDrugAllergies: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      drugAllergies: {
        type: String,
        optional: true
      },
      pregnant: {
        type: String,
        allowedValues: ['Yes', 'No']
      }
    }),
    "Patient Profiling": new SimpleSchema({
      patientProfile1: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      patientProfile2: {
        type: String,
        allowedValues: ['Within past 3 years', 'More than 3 years ago'],
        optional: true
      },
      patientProfile3: {
        type: Array,
        optional: true
      },
      'patientProfile3.$': {
        type: String,
        optional: true,
        allowedValues: ['Increased urination', 'Increased thirst', 'Weight loss', 'Increased hunger', 'Increased tiredness', 'Blurred vision', 'Slow-healing wounds', 'Numbness/tingling in hands and/or feet', 'None of the above']
      },
      patientProfile4: {
        type: String,
        optional: true,
        allowedValues: ['Regular (Interval of 6 months or less)', 'Occasionally (Interval of more than 6 months)', 'Seldom (last appointment was >1 year ago)', 'Not at all']
      },
      anyWesternMedicine: {
        type: Boolean,
        optional: true,
        label: "Yes, Western medicine"
      },
      westernMedicine: {
        type: String,
        optional: true
      },
      anyTraditionalMedicine: {
        type: Boolean,
        optional: true,
        label: "Yes, Traditional medicine"
      },
      traditionalMedicine: {
        type: String,
        optional: true
      },
      patientProfile6: {
        type: String,
        optional: true,
        allowedValues: ['0', '1-3', '4-6', '> or equal to 7']
      },
      hyperlipidemiaQ1: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      hyperlipidemiaQ2: {
        type: String,
        optional: true,
        allowedValues: ['Within past 3 years', 'More than 3 years ago']
      },
      hyperlipidemiaQ3: {
        type: String,
        optional: true,
        allowedValues: ['Regular (Interval of 6 months or less)', 'Occasionally (Interval of more than 6 months)', 'Seldom (last appointment was >1 year ago)', 'Not at all']
      },
      hyperlipidemiaAnyWesternMedicine: {
        type: Boolean,
        optional: true,
        label: "Yes, Western medicine"
      },
      hyperlipidemiaWesternMedicine: {
        type: String,
        optional: true
      },
      hyperlipidemiaAnyTraditionalMedicine: {
        type: Boolean,
        optional: true,
        label: "Yes, Traditional medicine"
      },
      hyperlipidemiaTraditionalMedicine: {
        type: String,
        optional: true
      },
      hyperlipidemiaQ5: {
        type: String,
        optional: true,
        allowedValues: ['0', '1-3', '4-6', '> or equal to 7']
      },
      hypertensionQ1: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      hypertensionQ2: {
        type: String,
        allowedValues: ['Within past 3 years', 'More than 3 years ago']
      },
      hypertensionQ3: {
        type: String,
        optional: true,
        allowedValues: ['Regular (Interval of 6 months or less)', 'Occasionally (Interval of more than 6 months)', 'Seldom (last appointment was >1 year ago)', 'Not at all']
      },
      hypertensionAnyWesternMedicine: {
        type: Boolean,
        optional: true,
        label: "Yes, Western medicine"
      },
      hypertensionWesternMedicine: {
        type: String,
        optional: true
      },
      hypertensionAnyTraditionalMedicine: {
        type: Boolean,
        optional: true,
        label: "Yes, Traditional medicine"
      },
      hypertensionTraditionalMedicine: {
        type: String,
        optional: true
      },
      hypertensionQ5: {
        type: String,
        optional: true,
        allowedValues: ['0', '1-3', '4-6', '> or equal to 7']
      },
      TBQ1: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      TBQ2: {
        type: String,
        allowedValues: ['Yes, the person was diagnosed with TB within the past 4 months', 'Yes, the person was diagnosed with TB more than 4 months ago', 'No']
      },
      TBQ3: {
        type: Array
      },
      'TBQ3.$': {
        type: String,
        allowedValues: ['Cough that has lasted more than 2 weeks', 'Coughing up blood', 'Breathlessness', 'Weight loss', 'Night sweats', 'Fever', 'Loss of appetite', 'None of the above']
      },
      medicalHistory1: {
        type: String
      },
      medicalHistory2: {
        type: String
      },
      medicalHistory3: {
        type: String
      },
      medicalHistory4: {
        type: String
      },
      medicalHistory5: {
        type: String
      },
      surgAndHospQ1: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      surgAndHospQ2: {
        type: String,
        optional: true
      },
      surgAndHospQ3: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      surgAndHospQ4: {
        type: String,
        optional: true
      },
      ocularHisQ1a: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      ocularHisQ1b: {
        type: String,
        optional: true
      },
      ocularHisQ2a: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      ocularHisQ2b: {
        type: String,
        optional: true
      },
      ocularHisQ3a: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      ocularHisQ3b: {
        type: String,
        optional: true
      },
      ocularHisQ3c: {
        type: String,
        optional: true
      },
      ocularHisQ3d: {
        type: Array,
        optional: true
      },
      'ocularHisQ3d.$': {
        type: String,
        allowedValues: ['Cataract', 'Glaucoma', 'Diabetic Retinopathy', 'Age-related Macular Degeneration', 'Others (please specify)']
      },
      otherOcularCond: {
        type: String,
        optional: true
      },
      ocularHisQ4: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      ocularHisQ5a: {
        type: String,
        allowedValues: ['Normal', 'Good enough for my daily activities', 'Poor']
      },
      ocularHisQ5b: {
        type: String,
        optional: true,
        allowedValues: ['Yes', 'No']
      },
      ocularHisQ5c: {
        type: Array,
        optional: true
      },
      'ocularHisQ5c.$': {
        type: String,
        allowedValues: ['Concerns about finances', 'Too far away/difficult to get to the clinic/hospital', 'Previously told by eye specialist that nothing can be done', 'Nothing can be done as it is part of ageing', 'Others (please specify)']
      },
      otherReasons: {
        type: String,
        optional: true
      },
      barrierQ1: {
        type: String,
        allowedValues: ['Hospital', 'Clinics', 'Traditional Medicine', 'Seldom/Never visits the doctor']
      },
      noNeed: {
        type: Boolean,
        optional: true,
        label: "Do not see the need for the tests"
      },
      time: {
        type: Boolean,
        optional: true,
        label: "Challenging to make time to go for appointments"
      },
      mobility: {
        type: Boolean,
        optional: true,
        label: "Difficulty getting to clinic (mobility)"
      },
      financial: {
        type: Boolean,
        optional: true,
        label: "Financial issues"
      },
      scared: {
        type: Boolean,
        optional: true,
        label: "Scared of doctor"
      },
      preferTradMed: {
        type: Boolean,
        optional: true,
        label: "Prefer traditional medicine"
      },
      anyOtherBarriers: {
        type: Boolean,
        optional: true,
        label: "Others: (free text)"
      },
      otherBarriers: {
        type: String,
        optional: true
      },
      familyHistory: {
        type: Array
      },
      'familyHistory.$': {
        type: String,
        allowedValues: ['High blood pressure', 'High blood cholesterol', 'Heart attack or coronary arterial disease (narrowed blood vessel supplying the heart)*', 'Stroke', 'Diabetes', 'Cancer', 'No, they do not have any of the above']
      },
      FLRSQ1: {
        type: String
      },
      FLRSQ2: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      FLRSQ3: {
        type: String
      },
      FLRSQ4: {
        type: String,
        allowedValues: ['Yes', 'No', 'Unsure']
      },
      FLRSQ5: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      FLRSQ6: {
        type: Array,
        optional: true
      },
      'FLRSQ6.$': {
        type: String,
        optional: true,
        allowedValues: ['Cigarette', 'Beedi', 'Tobacco', 'Opium']
      },
      FLRSQ7: {
        type: String,
        optional: true,
        allowedValues: ['Less than 1 cigarette (or equivalent) per day on average', 'Between 1 to 10 cigarettes (or equivalent) per day on average', 'More than 10 cigarettes (or equivalent) per day on average']
      },
      FLRSQ8: {
        type: String,
        optional: true
      },
      FLRSQ9: {
        type: String,
        optional: true,
        allowedValues: ['I have stopped smoking completely', 'I have never smoked before']
      },
      FLRSQ10: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      socialHisQ1: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      socialHisQ2: {
        type: Number,
        optional: true
      },
      student: {
        type: Boolean,
        optional: true,
        label: "Student"
      },
      housewife: {
        type: Boolean,
        optional: true,
        label: "Homemaker/Housewife"
      },
      relig: {
        type: Boolean,
        optional: true,
        label: "Religious Work"
      },
      prof: {
        type: Boolean,
        optional: true,
        label: "Professional (teacher, engineer, architect, doctor, nurse, lawyer, management, finance, etc)"
      },
      service: {
        type: Boolean,
        optional: true,
        label: "Service industry (e.g. restaurant server, call centre, receptionist, hotel staff)"
      },
      manual: {
        type: Boolean,
        optional: true,
        label: "Manual labourer (e.g. construction, cleaning, clothes washing)"
      },
      skilledLab: {
        type: Boolean,
        optional: true,
        label: "Skilled labourer (e.g. plumbing, electrician, cook, tailor)"
      },
      farming: {
        type: Boolean,
        optional: true,
        label: "Farming/Agriculture"
      },
      mining: {
        type: Boolean,
        optional: true,
        label: "Mining"
      },
      manu: {
        type: Boolean,
        optional: true,
        label: "Manufacturing"
      },
      unemployed: {
        type: Boolean,
        optional: true,
        label: "Unemployed"
      },
      anyOtherOcc: {
        type: Boolean,
        optional: true,
        label: "Others (please specify) - free text"
      },
      otherOcc: {
        type: String,
        optional: true
      },
      socialHisQ4: {
        type: String,
        allowedValues: ['Labour', 'Sedentary']
      },
      socialHisQ5: {
        type: String,
        allowedValues: ['Yes', 'No'],
        optional: true
      },
      socialHisQ6: {
        type: String,
        optional: true
      },
      socialHisQ7: {
        type: String,
        allowedValues: ['Unmarried', 'Married', 'Widowed', 'Divorced']
      },
      socialHisQ8: {
        type: Number
      },
      socialHisQ9: {
        type: Number
      },
      socialHisQ10: {
        type: Number
      },
      socialHisQ11: {
        type: Number
      },
      socialHisQ13: {
        type: String,
        allowedValues: ['No Formal Qualifications', '6th standard or less', '7th-9th standard', '10th standard', '11th standard', '12th standard', 'Vocational training (e.g. plumbing, construction, cooking)', 'Bachelors or equivalent', 'Post-graduate (Masters/Doctorate or equivalent)', 'Refuse to answer']
      }
    }),
    "Station Selection": new SimpleSchema({
      stationSelect1: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      stationSelect2: {
        type: String,
        allowedValues: ['Yes', 'No', 'Not applicable (child)']
      },
      stationSelect3: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      stationSelect4: {
        type: String,
        allowedValues: ['Yes', 'No', 'Not applicable (child)']
      },
      stationSelect5: {
        type: Array
      },
      'stationSelect5.$': {
        type: String,
        allowedValues: ['High blood pressure', 'Diabetes', 'Cigarette smoking', 'Family member with coronary artery disease', 'Family member with high cholesterol', 'Chronic kidney disease', 'None of the above/not applicable (Age < 40)']
      },
      stationSelect6: {
        type: String,
        optional: true,
        allowedValues: ['Yes', 'No', 'Not applicable (child)']
      },
      stationSelect7: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      stationSelect8: {
        type: String,
        optional: true,
        allowedValues: ['Yes', 'No']
      },
      stationSelect9: {
        type: String,
        optional: true,
        allowedValues: ['Yes', 'No']
      },
      stationSelect10: {
        type: String,
        allowedValues: ['Yes', 'No', 'Not applicable (child)']
      },
      stationSelect11: {
        type: String,
        allowedValues: ['Yes', 'No', 'Not applicable (child < 10 years old)']
      },
      stationSelect12: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      stationSelect13: {
        type: String,
        allowedValues: ['Yes', 'No']
      },
      stationSelect14: {
        type: String,
        allowedValues: ['Yes', 'No', 'Not applicable (child)']
      }
    })
  },
  "Height & weight": new SimpleSchema({
    height: {
      type: Number,
      min: 0.7,
      max: 2.8,
      label: "Height (m)"
    },
    // childHeight: {
    //   type: String,
    //   allowedValues: ['Below 3rd percentile curve', 
    //                   'Between 3rd and 97th percentile curves',
    //                   'Above 97th percentile curve'],
    // },
    weight: {
      type: Number,
      min: 5,
      max: 500,
      label: "Weight (kg)"
    },
    // childWeight:{
    //   type: String,
    //   allowedValues: ['Below 3rd percentile curve', 
    //                   'Between 3rd and 97th percentile curves',
    //                   'Above 97th percentile curve'],
    // },
    waist: {
      type: Number,
      label: "Waist circumference (cm)"
    },
    hip: {
      type: Number,
      label: "Hip circumference (cm)"
    },
    docConsultForHW: {
      type: Boolean,
      label: "Doctors consult required?"
    }
  }),
  "Blood Glucose & Hb": new SimpleSchema({
    cbg: {
      type: SimpleSchema.Integer,
      min: 20,
      max: 400,
      label: "Capillary Blood Glucose (mg/dL)"
    },
    hb: {
      type: Number,
      min: 4,
      max: 40,
      label: "Hemoglobin (g/dL)"
    },
    docConsultForBloodGlucAndHb: {
      type: Boolean,
      label: "Doctors consult required?"
    }
  }),
  "Phlebotomy": new SimpleSchema({
    phleboCompleted: {
      type: Boolean,
      label: "Phlebotomy completed?"
    }
  }),
  "Pap Smear": new SimpleSchema({
    papCompleted: {
      type: Boolean,
      label: "Pap smear completed?"
    },
    papNotes: {
      type: String,
      optional: true,
      label: "Notes (if any)"
    },
    docConsultForPap: {
      type: Boolean,
      label: "Doctors consult required?"
    }
  }),
  "Breast Exam": new SimpleSchema({
    abnormalities: {
      type: Boolean,
      label: "Any abnormalities noted (e.g. lumps, skin changes)?"
    },
    abDescribe: {
      type: String,
      optional: true,
      label: "If yes to the previous question, please describe the abnormalities"
    },
    fnacCompleted: {
      type: Boolean,
      label: "FNAC Completed?"
    },
    eduCompleted: {
      type: Boolean,
      label: "Breast Screening Education Completed?"
    }
  }),
  "Blood Pressure": new SimpleSchema({
    bp1Sys: {
      type: SimpleSchema.Integer,
      min: 50,
      max: 300,
      label: "1st Systolic blood pressure"
    },
    bp1Dia: {
      type: SimpleSchema.Integer,
      min: 20,
      max: 200,
      label: "1st Diastolic blood pressure"
    },
    bp2Sys: {
      type: SimpleSchema.Integer,
      min: 50,
      max: 300,
      label: "2nd Systolic blood pressure"
    },
    bp2Dia: {
      type: SimpleSchema.Integer,
      min: 20,
      max: 200,
      label: "2nd Diastolic blood pressure"
    },
    bp3Sys: {
      type: SimpleSchema.Integer,
      optional: true,
      min: 50,
      max: 300,
      label: "3rd Systolic blood pressure"
    },
    bp3Dia: {
      type: SimpleSchema.Integer,
      optional: true,
      min: 20,
      max: 200,
      label: "3rd Diastolic blood pressure"
    },
    docConsultForBP: {
      type: Boolean,
      label: "Doctors consult required?"
    }
  }),
  "Doctors' Consult": new SimpleSchema({
    docConsult1: {
      type: Array
    },
    'docConsult1.$': {
      type: String,
      allowedValues: ['Overweight/obesity', 'Heart burn', 'Diabetes', 'High blood pressure', 'Heart disease', 'Unexplained weight loss', 'Respiratory problems', 'Joint pain/back pain', 'Stroke', 'Visual impairment', 'Mental health issues', 'Alcohol overuse', 'Drug addiction', 'Infectious diseases e.g. malaria, tuberculosis', 'Others (free text)']
    },
    otherComplaints: {
      type: String,
      optional: true
    },
    docConsult2: {
      type: String
    },
    docConsult3: {
      type: Boolean,
      label: "Provided with referral letter?"
    },
    docConsult4: {
      type: String,
      optional: true
    },
    docConsult5: {
      type: String
    }
  }),
  "Eye Screening": new SimpleSchema({
    specs: {
      type: Boolean,
      label: "Does the participant use spectacles?"
    },
    rightWoGlass: {
      type: String,
      label: "Right eye without glasses"
    },
    leftWoGlass: {
      type: String,
      label: "Left eye without glasses"
    },
    rightWiGlass: {
      type: String,
      label: "Right eye with glasses"
    },
    leftWiGlass: {
      type: String,
      label: "Left eye with glasses"
    },
    rightNearVis: {
      type: String,
      label: "Right eye near vision"
    },
    leftNearVis: {
      type: String,
      label: "Left eye near vision"
    },
    lids: {
      type: String,
      label: "Lids"
    },
    conjunctiva: {
      type: String,
      label: "Conjunctiva"
    },
    cornea: {
      type: String,
      label: "Cornea"
    },
    antSeg: {
      type: String,
      label: "Anterior Segment"
    },
    iris: {
      type: String,
      label: "Iris"
    },
    pupil: {
      type: String,
      label: "Pupil"
    },
    lens: {
      type: String,
      label: "Lens"
    },
    ocuMvmt: {
      type: String,
      label: "Ocular Movements"
    },
    iop: {
      type: String,
      label: "IOP"
    },
    duct: {
      type: String,
      label: "Duct"
    },
    cdr: {
      type: String,
      label: "CDR"
    },
    macula: {
      type: String,
      label: "Macula"
    },
    retina: {
      type: String,
      label: "Retina"
    },
    diagnosis: {
      type: String,
      label: "Diagnosis"
    },
    advice: {
      type: String,
      label: "Advice"
    },
    nameDoc: {
      type: String,
      label: "Name of Doctor"
    }
  }),
  "Women's Edu": {
    "Pre-Women's Education Quiz": new SimpleSchema({
      breastCompleted: {
        type: Boolean,
        label: "Breast Screening Completed?"
      },
      preWomenEduSurvey1: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      preWomenEduQ1: {
        type: String,
        allowedValues: ['Abdominal cramps', 'Acne', 'Headache', 'All of the above']
      },
      preWomenEduQ2: {
        type: String,
        allowedValues: ['Stress', 'Pregnancy', 'Weight loss', 'Abrasions']
      },
      preWomenEduQ3: {
        type: String,
        allowedValues: ['Menstruation is dirty', 'Menstruation happens every 28 days, on average', 'We should change our sanitary pads once every few days', 'We should clean the area from back to front']
      },
      preWomenEduQ4: {
        type: String,
        allowedValues: ['1st day of menses', '7-10 days after start of menses', '21 days after start of menses', '2 days before start of menses']
      },
      preWomenEduQ5: {
        type: String,
        allowedValues: ['Once a week', 'Once a month', 'Once a year', 'Once in 2 years']
      },
      preWomenEduQ6: {
        type: String,
        allowedValues: ['A lump that can be seen/felt in the breast or underarm', 'Nipple that is pushed inwards', 'Dimpling of skin over the breast', 'Ulceration of skin over the breast', 'All of the above']
      }
    }),
    "Post-Women's Education Quiz": new SimpleSchema({
      postWomenEduSurvey1: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      postWomenEduQ1: {
        type: String,
        allowedValues: ['Abdominal cramps', 'Acne', 'Headache', 'All of the above']
      },
      postWomenEduQ2: {
        type: String,
        allowedValues: ['Stress', 'Pregnancy', 'Weight loss', 'Abrasions']
      },
      postWomenEduQ3: {
        type: String,
        allowedValues: ['Menstruation is dirty', 'Menstruation happens every 28 days, on average', 'We should change our sanitary pads once every few days', 'We should clean the area from back to front']
      },
      postWomenEduQ4: {
        type: String,
        allowedValues: ['1st day of menses', '7-10 days after start of menses', '21 days after start of menses', '2 days before start of menses']
      },
      postWomenEduQ5: {
        type: String,
        allowedValues: ['Once a week', 'Once a month', 'Once a year', 'Once in 2 years']
      },
      postWomenEduQ6: {
        type: String,
        allowedValues: ['A lump that can be seen/felt in the breast or underarm', 'Nipple that is pushed inwards', 'Dimpling of skin over the breast', 'Ulceration of skin over the breast', 'All of the above']
      }
    })
  },
  "Education": {
    "Pre-Education Survey": new SimpleSchema({
      preEduSurvey1: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      preEduSurvey2: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      preEduSurvey3: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      preEduSurvey4: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      }
    }),
    "Pre-Education Quiz": new SimpleSchema({
      preEduQuiz1: {
        type: String,
        allowedValues: ['Do not exercise', 'Have diabetes', 'Smoke', 'All of the above']
      },
      preEduQuiz2: {
        type: String,
        allowedValues: ['Do not exercise', 'Have diabetes', 'Smoke', 'All of the above']
      },
      preEduQuiz3: {
        type: String,
        allowedValues: ['60 mins', '90 mins', '120 mins', '150 mins']
      },
      preEduQuiz4: {
        type: String,
        allowedValues: ['1/2 rice, 1/4 fruits and vegetables, 1/4 protein', '2/5 rice, 1/5 vegetables, 1/5 fruits, 1/5 protein', '1/3 rice, 1/3 vegetables, 1/3 protein', '1/2 fruits and vegetables, 1/4 rice, 1/4 protein']
      },
      preEduQuiz5: {
        type: String,
        allowedValues: ['Daal', 'Mattar Paneer', 'Chole Bhattura', 'Butter Paneer']
      },
      preEduQuiz6: {
        type: String,
        allowedValues: ['Tobacco', 'Alcohol', 'Pesticides', 'All of the above']
      },
      preEduQuiz7: {
        type: String,
        allowedValues: ['Get comprehensive eye exams regularly', 'Use a computer for 2h to finish my work', 'Read under sufficiently bright light', 'Wear sunglasses and caps when outdoors to protect eyes from UV rays']
      }
    }),
    "Post-Education Survey": new SimpleSchema({
      postEduSurvey1: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      postEduSurvey2: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      postEduSurvey3: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      },
      postEduSurvey4: {
        type: String,
        allowedValues: ['1', '2', '3', '4', '5']
      }
    }),
    "Post-Education Quiz": new SimpleSchema({
      postEduQuiz1: {
        type: String,
        allowedValues: ['Do not exercise', 'Have diabetes', 'Smoke', 'All of the above']
      },
      postEduQuiz2: {
        type: String,
        allowedValues: ['Do not exercise', 'Have diabetes', 'Smoke', 'All of the above']
      },
      postEduQuiz3: {
        type: String,
        allowedValues: ['60 mins', '90 mins', '120 mins', '150 mins']
      },
      postEduQuiz4: {
        type: String,
        allowedValues: ['1/2 rice, 1/4 fruits and vegetables, 1/4 protein', '2/5 rice, 1/5 vegetables, 1/5 fruits, 1/5 protein', '1/3 rice, 1/3 vegetables, 1/3 protein', '1/2 fruits and vegetables, 1/4 rice, 1/4 protein']
      },
      postEduQuiz5: {
        type: String,
        allowedValues: ['Daal', 'Mattar Paneer', 'Chole Bhattura', 'Butter Paneer']
      },
      postEduQuiz6: {
        type: String,
        allowedValues: ['Tobacco', 'Alcohol', 'Pesticides', 'All of the above']
      },
      postEduQuiz7: {
        type: String,
        allowedValues: ['Get comprehensive eye exams regularly', 'Use a computer for 2h to finish my work', 'Read under sufficiently bright light', 'Wear sunglasses and caps when outdoors to protect eyes from UV rays']
      }
    })
  },
  "Post-Screening Feedback": new SimpleSchema({
    postScreeningFeedback1: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback2: {
      type: Array
    },
    'postScreeningFeedback2.$': {
      type: String,
      allowedValues: ['I am concerned about my health', 'I have never been screened before', 'Friends/family told me to come', 'There is a free health screening', 'There is a free goodie bag', 'I was drawn to the crowd', 'It was conveniently located', 'It is at a convenient time']
    },
    postScreeningFeedback3: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback4: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback5: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback6: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback7: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback8: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback9: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback10: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback11: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback12: {
      type: String,
      allowedValues: ['Strongly agree', 'Agree', 'Disagree', 'Strongly disagree']
    },
    postScreeningFeedback13: {
      type: Array
    },
    'postScreeningFeedback13.$': {
      type: String,
      allowedValues: ['Happened to pass by', 'Posters', 'Newspaper', 'Door-to-door publicity', 'Heard from neighbours/relatives/friends']
    },
    postScreeningFeedback14: {
      type: String,
      allowedValues: ['Never', 'More than 3 years ago', 'Once in 3 years', 'Once in 2 years', 'Once a year', 'More than once a year']
    }
  })
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"links.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/links.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
module.exportDefault(Links = new Mongo.Collection('links'));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"patientinfo.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/patientinfo.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let formSchemas;
module.link("/imports/api/formSchemas", {
  formSchemas(v) {
    formSchemas = v;
  }

}, 4);
let formLayouts;
module.link("/imports/api/formLayouts", {
  formLayouts(v) {
    formLayouts = v;
  }

}, 5);
module.exportDefault(Patientinfo = new Mongo.Collection('patientinfo'));
// if (Meteor.isServer) {
//   Meteor.publish('patientinfo', function () {
//     return Patientinfo.find();
//   })
// }
Meteor.methods({
  'patientinfo.insert'(data) {
    // Determine stations to visit based on:
    // Based on gender & age
    const isMale = data["Patient Info"].gender === "male";
    const isChild = data["Patient Info"].age <= 18; // Stations to remove

    var stationsToRemove = ["Registration"];

    if (isMale) {
      stationsToRemove.push("Pap Smear", "Breast Exam", "Women's Edu");
    }

    if (isChild) {
      stationsToRemove.push("Blood Pressure", "Phlebotomy", "Pap Smear", "Breast Exam");
    } // Remove opt-out stations


    console.log(data["Station Selection"]);

    for (var station in data["Station Selection"]) {
      if (data["Station Selection"][station] === "No") {
        stationsToRemove.push(station);
      }
    } // Construct station queue by filtering out stations to exclude
    // https://stackoverflow.com/questions/5767325/how-do-i-remove-a-particular-element-from-an-array-in-javascript


    data.stationQueue = Object.keys(formLayouts).filter(s => !stationsToRemove.includes(s));
    data.nextStation = data.stationQueue[0];
    data.busy = false; // Assign unique id

    data.id = Patientinfo.find({}).count() + 1;
    Patientinfo.insert(data);
  },

  'patientinfo.update'(data) {
    const id = data.id;
    delete data.id;
    delete data.nextStation; // Retrieve station queue

    var stationQueue = Patientinfo.find({
      id: id
    }).fetch()[0].stationQueue; // Proceed to next station

    stationQueue.shift();
    const nextStation = typeof stationQueue[0] !== "undefined" ? stationQueue[0] : "Done";
    Patientinfo.update({
      id: id
    }, {
      $set: {
        nextStation: nextStation,
        busy: false,
        stationQueue: stationQueue
      },
      $push: data
    }); // console.log(Patientinfo.findOne({id:id}));
  },

  'patientinfo.setBusy'(id, value) {
    const patientStatus = Patientinfo.findOne({
      id: id
    }) !== "undefined" ? Patientinfo.findOne({
      id: id
    }).busy : false;

    if (patientStatus === value) {
      console.log("Patient conflict");
      return false;
    } else {
      Patientinfo.update({
        id: id
      }, {
        $set: {
          busy: value
        }
      });

      if (Meteor.isServer && value === true) {
        this.connection.onClose(() => {
          Patientinfo.update({
            id: id
          }, {
            $set: {
              busy: false
            }
          });
        });
      }

      return true;
    }
  },

  'patientinfo.skipStation'(id, currentStation, stationToSkip) {
    // Retrieve station queue
    const stationQueue = Patientinfo.find({
      id: id
    }).fetch()[0].stationQueue; // Filter out station

    const newQueue = stationQueue.filter(field => field !== stationToSkip);
    const nextStation = typeof newQueue[0] !== "undefined" ? newQueue[0] : "Done";
    const isChangingCurrent = currentStation === stationToSkip;
    Patientinfo.update({
      id: id
    }, {
      $set: {
        nextStation: nextStation,
        busy: isChangingCurrent,
        stationQueue: newQueue
      }
    });
  },

  'patientinfo.editPatientInfo'(id, parent, label, value) {
    console.log(value);
    const constructOperator = parent + "." + label;
    Patientinfo.update({
      id: id
    }, {
      $set: {
        [constructOperator]: value
      }
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"stationforms.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/stationforms.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
module.exportDefault(Stationforms = new Mongo.Collection('stationforms'));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Links;
module.link("/imports/api/links", {
  default(v) {
    Links = v;
  }

}, 1);
let Patientinfo;
module.link("/imports/api/patientinfo", {
  default(v) {
    Patientinfo = v;
  }

}, 2);
let Stationforms;
module.link("/imports/api/stationforms", {
  default(v) {
    Stationforms = v;
  }

}, 3);
let formLayouts;
module.link("/imports/api/formLayouts", {
  formLayouts(v) {
    formLayouts = v;
  }

}, 4);

function addPatient(name, id, nextStation) {
  Patientinfo.insert({
    name: name,
    id: id,
    nextStation: nextStation,
    busy: false,
    createdAt: new Date()
  });
}

function addForm(station, formData) {
  Stationforms.insert({
    name: station,
    data: formData
  });
}

Meteor.startup(() => {
  // Patientinfo.remove({});
  // Stationforms.remove({});
  // Reset all patients who were midway through a station
  Patientinfo.update({
    busy: true
  }, {
    $set: {
      busy: false
    }
  }, {
    multi: true
  });

  if (Patientinfo.find().count() === 0) {
    Patientinfo.insert({
      id: '1',
      "Patient Info": {
        name: 'Tom',
        gender: 'male',
        age: '24',
        contactNumber: '12344321',
        spokenLanguages: ['English', 'Others'],
        writtenLanguages: ['English'],
        address: 'Baker Street',
        anyDrugAllergies: 'Yes',
        drugAllergies: 'Panadol'
      },
      stationQueue: ["Blood Glucose & Hb", "Blood Pressure", "Phlebotomy", "Doctors' Consult", "Eye Screening", "Education"],
      nextStation: 'Height & weight',
      busy: false,
      createdAt: new Date()
    });
    Patientinfo.insert({
      id: '2',
      "Patient Info": {
        name: 'Gary',
        gender: 'male',
        age: '24',
        contactNumber: '12344321',
        spokenLanguages: ['English', 'Others'],
        writtenLanguages: ['English'],
        address: 'Baker Street',
        anyDrugAllergies: 'No'
      },
      stationQueue: ["Blood Glucose & Hb", "Blood Pressure", "Phlebotomy", "Doctors' Consult", "Eye Screening", "Education"],
      nextStation: 'Height & weight',
      busy: false,
      createdAt: new Date()
    });
    Patientinfo.insert({
      id: '3',
      "Patient Info": {
        name: 'Reyansh Aditya Vihaan',
        gender: 'male',
        age: '24',
        contactNumber: '12344321',
        spokenLanguages: ['English', 'Others'],
        writtenLanguages: ['English'],
        address: 'Baker Street',
        anyDrugAllergies: 'Yes',
        drugAllergies: 'Panadol'
      },
      stationQueue: [],
      nextStation: 'Education',
      busy: false,
      createdAt: new Date()
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZm9ybUxheW91dHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Zvcm1TY2hlbWFzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9saW5rcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcGF0aWVudGluZm8uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3N0YXRpb25mb3Jtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiZm9ybUxheW91dHMiLCJSZWFjdCIsIkNvbXBvbmVudCIsIkZyYWdtZW50IiwibGluayIsImRlZmF1bHQiLCJ2IiwiRGl2aWRlciIsIlR5cG9ncmFwaHkiLCJmb3JtU2NoZW1hcyIsIkF1dG9Gb3JtIiwiQXV0b0ZpZWxkIiwiVGV4dEZpZWxkIiwiU3VibWl0RmllbGQiLCJTZWxlY3RGaWVsZCIsIkhpZGRlbkZpZWxkIiwiTnVtRmllbGQiLCJMaXN0RmllbGQiLCJEYXRlRmllbGQiLCJSYWRpb0ZpZWxkIiwiQm9vbEZpZWxkIiwiTG9uZ1RleHRGaWVsZCIsIkJhc2VGaWVsZCIsIm5vdGhpbmciLCJDaGlsZHJlbiIsIlJhZGlvIiwiRGlzcGxheUlmIiwiY2hpbGRyZW4iLCJjb25kaXRpb24iLCJ1bmlmb3JtcyIsIm9ubHkiLCJjb250ZXh0VHlwZXMiLCJyZXF1aXJlRG9jdG9yQ29uc3VsdCIsImluZm8iLCJkb2NDb25zdWx0Rm9ySFciLCJkb2NDb25zdWx0Rm9yQmxvb2RHbHVjQW5kSGIiLCJkb2NDb25zdWx0Rm9yUGFwIiwiZG9jQ29uc3VsdEZvckJQIiwiY29udGV4dCIsIm1vZGVsIiwiYW55RHJ1Z0FsbGVyZ2llcyIsInBhdGllbnRQcm9maWxlMSIsImFueVdlc3Rlcm5NZWRpY2luZSIsImFueVRyYWRpdGlvbmFsTWVkaWNpbmUiLCJoeXBlcmxpcGlkZW1pYVExIiwiaHlwZXJsaXBpZGVtaWFBbnlXZXN0ZXJuTWVkaWNpbmUiLCJoeXBlcmxpcGlkZW1pYUFueVRyYWRpdGlvbmFsTWVkaWNpbmUiLCJoeXBlcnRlbnNpb25RMSIsImh5cGVydGVuc2lvbkFueVdlc3Rlcm5NZWRpY2luZSIsImh5cGVydGVuc2lvbkFueVRyYWRpdGlvbmFsTWVkaWNpbmUiLCJzdXJnQW5kSG9zcFExIiwic3VyZ0FuZEhvc3BRMyIsIm9jdWxhckhpc1ExYSIsIm9jdWxhckhpc1EyYSIsIm9jdWxhckhpc1EzYSIsIkFycmF5IiwiaXNBcnJheSIsIm9jdWxhckhpc1EzZCIsImluY2x1ZGVzIiwib2N1bGFySGlzUTVhIiwib2N1bGFySGlzUTViIiwib2N1bGFySGlzUTVjIiwiYmFycmllclExIiwiYW55T3RoZXJCYXJyaWVycyIsIkZMUlNRNSIsInNvY2lhbEhpc1ExIiwiYW55T3RoZXJPY2MiLCJzb2NpYWxIaXNRMyIsInN0YXRpb25TZWxlY3Q1IiwibGVuZ3RoIiwic3RhdGlvblNlbGVjdDciLCJzdGF0aW9uU2VsZWN0OCIsIk1hdGgiLCJhYnMiLCJicDJTeXMiLCJicDFTeXMiLCJicDJEaWEiLCJicDFEaWEiLCJhYm5vcm1hbGl0aWVzIiwiZG9jQ29uc3VsdDEiLCJkb2NDb25zdWx0MyIsIlNpbXBsZVNjaGVtYSIsIlBhdGllbnRpbmZvIiwic2V0RGVmYXVsdE1lc3NhZ2VzIiwibWVzc2FnZXMiLCJlbiIsIm5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVnRXgiLCJsYWJlbCIsImdlbmRlciIsImFsbG93ZWRWYWx1ZXMiLCJiaXJ0aGRheSIsImFnZSIsIkludGVnZXIiLCJtaW4iLCJhdXRvVmFsdWUiLCJiaXJ0aGRhdGUiLCJzaWJsaW5nRmllbGQiLCJ2YWx1ZSIsImN1cnJlbnRZZWFyIiwiRGF0ZSIsImJpcnRoWWVhciIsIk51bWJlciIsInN1YnN0cmluZyIsImdldEZ1bGxZZWFyIiwiZGlzdHJpY3QiLCJhZGRyZXNzIiwiemlwY29kZSIsImNvbnRhY3ROdW1iZXIiLCJzcG9rZW5MYW5ndWFnZXMiLCJ3cml0dGVuTGFuZ3VhZ2VzIiwiZHJ1Z0FsbGVyZ2llcyIsIm9wdGlvbmFsIiwicHJlZ25hbnQiLCJwYXRpZW50UHJvZmlsZTIiLCJwYXRpZW50UHJvZmlsZTMiLCJwYXRpZW50UHJvZmlsZTQiLCJCb29sZWFuIiwid2VzdGVybk1lZGljaW5lIiwidHJhZGl0aW9uYWxNZWRpY2luZSIsInBhdGllbnRQcm9maWxlNiIsImh5cGVybGlwaWRlbWlhUTIiLCJoeXBlcmxpcGlkZW1pYVEzIiwiaHlwZXJsaXBpZGVtaWFXZXN0ZXJuTWVkaWNpbmUiLCJoeXBlcmxpcGlkZW1pYVRyYWRpdGlvbmFsTWVkaWNpbmUiLCJoeXBlcmxpcGlkZW1pYVE1IiwiaHlwZXJ0ZW5zaW9uUTIiLCJoeXBlcnRlbnNpb25RMyIsImh5cGVydGVuc2lvbldlc3Rlcm5NZWRpY2luZSIsImh5cGVydGVuc2lvblRyYWRpdGlvbmFsTWVkaWNpbmUiLCJoeXBlcnRlbnNpb25RNSIsIlRCUTEiLCJUQlEyIiwiVEJRMyIsIm1lZGljYWxIaXN0b3J5MSIsIm1lZGljYWxIaXN0b3J5MiIsIm1lZGljYWxIaXN0b3J5MyIsIm1lZGljYWxIaXN0b3J5NCIsIm1lZGljYWxIaXN0b3J5NSIsInN1cmdBbmRIb3NwUTIiLCJzdXJnQW5kSG9zcFE0Iiwib2N1bGFySGlzUTFiIiwib2N1bGFySGlzUTJiIiwib2N1bGFySGlzUTNiIiwib2N1bGFySGlzUTNjIiwib3RoZXJPY3VsYXJDb25kIiwib2N1bGFySGlzUTQiLCJvdGhlclJlYXNvbnMiLCJub05lZWQiLCJ0aW1lIiwibW9iaWxpdHkiLCJmaW5hbmNpYWwiLCJzY2FyZWQiLCJwcmVmZXJUcmFkTWVkIiwib3RoZXJCYXJyaWVycyIsImZhbWlseUhpc3RvcnkiLCJGTFJTUTEiLCJGTFJTUTIiLCJGTFJTUTMiLCJGTFJTUTQiLCJGTFJTUTYiLCJGTFJTUTciLCJGTFJTUTgiLCJGTFJTUTkiLCJGTFJTUTEwIiwic29jaWFsSGlzUTIiLCJzdHVkZW50IiwiaG91c2V3aWZlIiwicmVsaWciLCJwcm9mIiwic2VydmljZSIsIm1hbnVhbCIsInNraWxsZWRMYWIiLCJmYXJtaW5nIiwibWluaW5nIiwibWFudSIsInVuZW1wbG95ZWQiLCJvdGhlck9jYyIsInNvY2lhbEhpc1E0Iiwic29jaWFsSGlzUTUiLCJzb2NpYWxIaXNRNiIsInNvY2lhbEhpc1E3Iiwic29jaWFsSGlzUTgiLCJzb2NpYWxIaXNROSIsInNvY2lhbEhpc1ExMCIsInNvY2lhbEhpc1ExMSIsInNvY2lhbEhpc1ExMyIsInN0YXRpb25TZWxlY3QxIiwic3RhdGlvblNlbGVjdDIiLCJzdGF0aW9uU2VsZWN0MyIsInN0YXRpb25TZWxlY3Q0Iiwic3RhdGlvblNlbGVjdDYiLCJzdGF0aW9uU2VsZWN0OSIsInN0YXRpb25TZWxlY3QxMCIsInN0YXRpb25TZWxlY3QxMSIsInN0YXRpb25TZWxlY3QxMiIsInN0YXRpb25TZWxlY3QxMyIsInN0YXRpb25TZWxlY3QxNCIsImhlaWdodCIsIm1heCIsIndlaWdodCIsIndhaXN0IiwiaGlwIiwiY2JnIiwiaGIiLCJwaGxlYm9Db21wbGV0ZWQiLCJwYXBDb21wbGV0ZWQiLCJwYXBOb3RlcyIsImFiRGVzY3JpYmUiLCJmbmFjQ29tcGxldGVkIiwiZWR1Q29tcGxldGVkIiwiYnAzU3lzIiwiYnAzRGlhIiwib3RoZXJDb21wbGFpbnRzIiwiZG9jQ29uc3VsdDIiLCJkb2NDb25zdWx0NCIsImRvY0NvbnN1bHQ1Iiwic3BlY3MiLCJyaWdodFdvR2xhc3MiLCJsZWZ0V29HbGFzcyIsInJpZ2h0V2lHbGFzcyIsImxlZnRXaUdsYXNzIiwicmlnaHROZWFyVmlzIiwibGVmdE5lYXJWaXMiLCJsaWRzIiwiY29uanVuY3RpdmEiLCJjb3JuZWEiLCJhbnRTZWciLCJpcmlzIiwicHVwaWwiLCJsZW5zIiwib2N1TXZtdCIsImlvcCIsImR1Y3QiLCJjZHIiLCJtYWN1bGEiLCJyZXRpbmEiLCJkaWFnbm9zaXMiLCJhZHZpY2UiLCJuYW1lRG9jIiwiYnJlYXN0Q29tcGxldGVkIiwicHJlV29tZW5FZHVTdXJ2ZXkxIiwicHJlV29tZW5FZHVRMSIsInByZVdvbWVuRWR1UTIiLCJwcmVXb21lbkVkdVEzIiwicHJlV29tZW5FZHVRNCIsInByZVdvbWVuRWR1UTUiLCJwcmVXb21lbkVkdVE2IiwicG9zdFdvbWVuRWR1U3VydmV5MSIsInBvc3RXb21lbkVkdVExIiwicG9zdFdvbWVuRWR1UTIiLCJwb3N0V29tZW5FZHVRMyIsInBvc3RXb21lbkVkdVE0IiwicG9zdFdvbWVuRWR1UTUiLCJwb3N0V29tZW5FZHVRNiIsInByZUVkdVN1cnZleTEiLCJwcmVFZHVTdXJ2ZXkyIiwicHJlRWR1U3VydmV5MyIsInByZUVkdVN1cnZleTQiLCJwcmVFZHVRdWl6MSIsInByZUVkdVF1aXoyIiwicHJlRWR1UXVpejMiLCJwcmVFZHVRdWl6NCIsInByZUVkdVF1aXo1IiwicHJlRWR1UXVpejYiLCJwcmVFZHVRdWl6NyIsInBvc3RFZHVTdXJ2ZXkxIiwicG9zdEVkdVN1cnZleTIiLCJwb3N0RWR1U3VydmV5MyIsInBvc3RFZHVTdXJ2ZXk0IiwicG9zdEVkdVF1aXoxIiwicG9zdEVkdVF1aXoyIiwicG9zdEVkdVF1aXozIiwicG9zdEVkdVF1aXo0IiwicG9zdEVkdVF1aXo1IiwicG9zdEVkdVF1aXo2IiwicG9zdEVkdVF1aXo3IiwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrMSIsInBvc3RTY3JlZW5pbmdGZWVkYmFjazIiLCJwb3N0U2NyZWVuaW5nRmVlZGJhY2szIiwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrNCIsInBvc3RTY3JlZW5pbmdGZWVkYmFjazUiLCJwb3N0U2NyZWVuaW5nRmVlZGJhY2s2IiwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrNyIsInBvc3RTY3JlZW5pbmdGZWVkYmFjazgiLCJwb3N0U2NyZWVuaW5nRmVlZGJhY2s5IiwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTAiLCJwb3N0U2NyZWVuaW5nRmVlZGJhY2sxMSIsInBvc3RTY3JlZW5pbmdGZWVkYmFjazEyIiwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTMiLCJwb3N0U2NyZWVuaW5nRmVlZGJhY2sxNCIsIk1vbmdvIiwiZXhwb3J0RGVmYXVsdCIsIkxpbmtzIiwiQ29sbGVjdGlvbiIsIk1ldGVvciIsImNoZWNrIiwibWV0aG9kcyIsImRhdGEiLCJpc01hbGUiLCJpc0NoaWxkIiwic3RhdGlvbnNUb1JlbW92ZSIsInB1c2giLCJjb25zb2xlIiwibG9nIiwic3RhdGlvbiIsInN0YXRpb25RdWV1ZSIsIk9iamVjdCIsImtleXMiLCJmaWx0ZXIiLCJzIiwibmV4dFN0YXRpb24iLCJidXN5IiwiaWQiLCJmaW5kIiwiY291bnQiLCJpbnNlcnQiLCJmZXRjaCIsInNoaWZ0IiwidXBkYXRlIiwiJHNldCIsIiRwdXNoIiwicGF0aWVudFN0YXR1cyIsImZpbmRPbmUiLCJpc1NlcnZlciIsImNvbm5lY3Rpb24iLCJvbkNsb3NlIiwiY3VycmVudFN0YXRpb24iLCJzdGF0aW9uVG9Ta2lwIiwibmV3UXVldWUiLCJmaWVsZCIsImlzQ2hhbmdpbmdDdXJyZW50IiwicGFyZW50IiwiY29uc3RydWN0T3BlcmF0b3IiLCJTdGF0aW9uZm9ybXMiLCJhZGRQYXRpZW50IiwiY3JlYXRlZEF0IiwiYWRkRm9ybSIsImZvcm1EYXRhIiwic3RhcnR1cCIsIm11bHRpIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJQyxLQUFKLEVBQVVDLFNBQVYsRUFBb0JDLFFBQXBCO0FBQTZCTCxNQUFNLENBQUNNLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNMLFNBQUssR0FBQ0ssQ0FBTjtBQUFRLEdBQXBCOztBQUFxQkosV0FBUyxDQUFDSSxDQUFELEVBQUc7QUFBQ0osYUFBUyxHQUFDSSxDQUFWO0FBQVksR0FBOUM7O0FBQStDSCxVQUFRLENBQUNHLENBQUQsRUFBRztBQUFDSCxZQUFRLEdBQUNHLENBQVQ7QUFBVzs7QUFBdEUsQ0FBcEIsRUFBNEYsQ0FBNUY7QUFBK0YsSUFBSUMsT0FBSjtBQUFZVCxNQUFNLENBQUNNLElBQVAsQ0FBWSwyQkFBWixFQUF3QztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDQyxXQUFPLEdBQUNELENBQVI7QUFBVTs7QUFBdEIsQ0FBeEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSUUsVUFBSjtBQUFlVixNQUFNLENBQUNNLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBekIsQ0FBM0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSUcsV0FBSjtBQUFnQlgsTUFBTSxDQUFDTSxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ0ssYUFBVyxDQUFDSCxDQUFELEVBQUc7QUFBQ0csZUFBVyxHQUFDSCxDQUFaO0FBQWM7O0FBQTlCLENBQXZDLEVBQXVFLENBQXZFO0FBQTBFLElBQUlJLFFBQUo7QUFBYVosTUFBTSxDQUFDTSxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0ksWUFBUSxHQUFDSixDQUFUO0FBQVc7O0FBQXZCLENBQXpDLEVBQWtFLENBQWxFO0FBQXFFLElBQUlLLFNBQUo7QUFBY2IsTUFBTSxDQUFDTSxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0ssYUFBUyxHQUFDTCxDQUFWO0FBQVk7O0FBQXhCLENBQTFDLEVBQW9FLENBQXBFO0FBQXVFLElBQUlNLFNBQUo7QUFBY2QsTUFBTSxDQUFDTSxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ00sYUFBUyxHQUFDTixDQUFWO0FBQVk7O0FBQXhCLENBQTFDLEVBQW9FLENBQXBFO0FBQXVFLElBQUlPLFdBQUo7QUFBZ0JmLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNPLGVBQVcsR0FBQ1AsQ0FBWjtBQUFjOztBQUExQixDQUE1QyxFQUF3RSxDQUF4RTtBQUEyRSxJQUFJUSxXQUFKO0FBQWdCaEIsTUFBTSxDQUFDTSxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ1EsZUFBVyxHQUFDUixDQUFaO0FBQWM7O0FBQTFCLENBQTVDLEVBQXdFLENBQXhFO0FBQTJFLElBQUlTLFdBQUo7QUFBZ0JqQixNQUFNLENBQUNNLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDUyxlQUFXLEdBQUNULENBQVo7QUFBYzs7QUFBMUIsQ0FBNUMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSVUsUUFBSjtBQUFhbEIsTUFBTSxDQUFDTSxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ1UsWUFBUSxHQUFDVixDQUFUO0FBQVc7O0FBQXZCLENBQXpDLEVBQWtFLEVBQWxFO0FBQXNFLElBQUlXLFNBQUo7QUFBY25CLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNXLGFBQVMsR0FBQ1gsQ0FBVjtBQUFZOztBQUF4QixDQUExQyxFQUFvRSxFQUFwRTtBQUF3RSxJQUFJWSxTQUFKO0FBQWNwQixNQUFNLENBQUNNLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDWSxhQUFTLEdBQUNaLENBQVY7QUFBWTs7QUFBeEIsQ0FBMUMsRUFBb0UsRUFBcEU7QUFBd0UsSUFBSWEsVUFBSjtBQUFlckIsTUFBTSxDQUFDTSxJQUFQLENBQVksOEJBQVosRUFBMkM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2EsY0FBVSxHQUFDYixDQUFYO0FBQWE7O0FBQXpCLENBQTNDLEVBQXNFLEVBQXRFO0FBQTBFLElBQUljLFNBQUo7QUFBY3RCLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNjLGFBQVMsR0FBQ2QsQ0FBVjtBQUFZOztBQUF4QixDQUExQyxFQUFvRSxFQUFwRTtBQUF3RSxJQUFJZSxhQUFKO0FBQWtCdkIsTUFBTSxDQUFDTSxJQUFQLENBQVksaUNBQVosRUFBOEM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2UsaUJBQWEsR0FBQ2YsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBOUMsRUFBNEUsRUFBNUU7QUFBZ0YsSUFBSWdCLFNBQUo7QUFBY3hCLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNnQixhQUFTLEdBQUNoQixDQUFWO0FBQVk7O0FBQXhCLENBQWpDLEVBQTJELEVBQTNEO0FBQStELElBQUlpQixPQUFKO0FBQVl6QixNQUFNLENBQUNNLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDaUIsV0FBTyxHQUFDakIsQ0FBUjtBQUFVOztBQUF0QixDQUEvQixFQUF1RCxFQUF2RDtBQUEyRCxJQUFJa0IsUUFBSjtBQUFhMUIsTUFBTSxDQUFDTSxJQUFQLENBQVksT0FBWixFQUFvQjtBQUFDb0IsVUFBUSxDQUFDbEIsQ0FBRCxFQUFHO0FBQUNrQixZQUFRLEdBQUNsQixDQUFUO0FBQVc7O0FBQXhCLENBQXBCLEVBQThDLEVBQTlDO0FBQWtELElBQUltQixLQUFKO0FBQVUzQixNQUFNLENBQUNNLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDcUIsT0FBSyxDQUFDbkIsQ0FBRCxFQUFHO0FBQUNtQixTQUFLLEdBQUNuQixDQUFOO0FBQVE7O0FBQWxCLENBQWhDLEVBQW9ELEVBQXBEOztBQXlCcHFEO0FBQ0E7QUFDQSxNQUFNb0IsU0FBUyxHQUFHLENBQUM7QUFBQ0MsVUFBRDtBQUFXQztBQUFYLENBQUQsRUFBd0I7QUFBQ0M7QUFBRCxDQUF4QixLQUF3Q0QsU0FBUyxDQUFDQyxRQUFELENBQVQsR0FBc0JMLFFBQVEsQ0FBQ00sSUFBVCxDQUFjSCxRQUFkLENBQXRCLEdBQWdESixPQUExRzs7QUFDQUcsU0FBUyxDQUFDSyxZQUFWLEdBQXlCVCxTQUFTLENBQUNTLFlBQW5DOztBQUVBLE1BQU1DLG9CQUFvQixHQUFJQyxJQUFELElBQzNCLG9CQUFDLFFBQUQsUUFDRyxDQUFFLE9BQU9BLElBQUksQ0FBQyxpQkFBRCxDQUFYLEtBQW9DLFdBQXBDLElBQW1EQSxJQUFJLENBQUMsaUJBQUQsQ0FBSixDQUF3QixDQUF4QixFQUEyQkMsZUFBL0UsSUFDQyxPQUFPRCxJQUFJLENBQUMsb0JBQUQsQ0FBWCxLQUF1QyxXQUF2QyxJQUFzREEsSUFBSSxDQUFDLG9CQUFELENBQUosQ0FBMkIsQ0FBM0IsRUFBOEJFLDJCQURyRixJQUVDLE9BQU9GLElBQUksQ0FBQyxXQUFELENBQVgsS0FBOEIsV0FBOUIsSUFBNkNBLElBQUksQ0FBQyxXQUFELENBQUosQ0FBa0IsQ0FBbEIsRUFBcUJHLGdCQUZuRSxJQUdDLE9BQU9ILElBQUksQ0FBQyxnQkFBRCxDQUFYLEtBQW1DLFdBQW5DLElBQWtEQSxJQUFJLENBQUMsZ0JBQUQsQ0FBSixDQUF1QixDQUF2QixFQUEwQkksZUFIOUUsS0FJQyxvQkFBQyxPQUFELE9BSkQsSUFLQyxvQkFBQyxVQUFEO0FBQVksT0FBSyxFQUFDLFdBQWxCO0FBQThCLFNBQU8sRUFBQztBQUF0QywwQkFOSixFQVNJLE9BQU9KLElBQUksQ0FBQyxpQkFBRCxDQUFYLEtBQW9DLFdBQXBDLElBQW1EQSxJQUFJLENBQUMsaUJBQUQsQ0FBSixDQUF3QixDQUF4QixFQUEyQkMsZUFBOUUsSUFDQSxvQkFBQyxVQUFEO0FBQVksT0FBSyxFQUFDO0FBQWxCLHVCQVZKLEVBYUksT0FBT0QsSUFBSSxDQUFDLG9CQUFELENBQVgsS0FBdUMsV0FBdkMsSUFBc0RBLElBQUksQ0FBQyxvQkFBRCxDQUFKLENBQTJCLENBQTNCLEVBQThCRSwyQkFBcEYsSUFDQSxvQkFBQyxVQUFEO0FBQVksT0FBSyxFQUFDO0FBQWxCLDBCQWRKLEVBaUJJLE9BQU9GLElBQUksQ0FBQyxXQUFELENBQVgsS0FBOEIsV0FBOUIsSUFBNkNBLElBQUksQ0FBQyxXQUFELENBQUosQ0FBa0IsQ0FBbEIsRUFBcUJHLGdCQUFsRSxJQUNBLG9CQUFDLFVBQUQ7QUFBWSxPQUFLLEVBQUM7QUFBbEIsZUFsQkosRUFxQkksT0FBT0gsSUFBSSxDQUFDLGdCQUFELENBQVgsS0FBbUMsV0FBbkMsSUFBa0RBLElBQUksQ0FBQyxnQkFBRCxDQUFKLENBQXVCLENBQXZCLEVBQTBCSSxlQUE1RSxJQUNBLG9CQUFDLFVBQUQ7QUFBWSxPQUFLLEVBQUM7QUFBbEIsb0JBREEsSUFJRixvQkFBQyxPQUFELE9BekJGLENBREYsQyxDQTZCQTs7O0FBQ08sTUFBTXJDLFdBQVcsR0FBRztBQUN6QixrQkFBZTtBQUNiLG9CQUFpQmlDLElBQUQsSUFDZCxvQkFBQyxRQUFELFFBQ0Usb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQURGLEVBR0Usb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQUhGLDBDQUtFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFMRixFQU1FLG9CQUFDLFFBQUQ7QUFBVSxVQUFJLEVBQUMsS0FBZjtBQUFxQixhQUFPLEVBQUU7QUFBOUIsTUFORixFQU9FLG9CQUFDLE9BQUQ7QUFBUyxhQUFPLEVBQUM7QUFBakIsTUFQRixFQVNFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFURixFQVVFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFWRixFQVdFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUMsU0FBaEI7QUFBMEIsYUFBTyxFQUFFO0FBQW5DLE1BWEYsRUFXOEMsK0JBWDlDLEVBWUUsb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQyxlQUFoQjtBQUFnQyxhQUFPLEVBQUU7QUFBekMsTUFaRixFQWFFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFiRixFQWNFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFkRixFQWVFLG9CQUFDLE9BQUQ7QUFBUyxhQUFPLEVBQUM7QUFBakIsTUFmRixFQWlCRSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BakJGLEVBa0JFLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUVLLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNDLGdCQUFkLEtBQW1DO0FBQXBFLE9BQ0Usb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQURGLENBbEJGLEVBcUJFLG9CQUFDLE9BQUQ7QUFBUyxhQUFPLEVBQUM7QUFBakIsTUFyQkYsRUF1QkUsb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQXZCRixDQUZXO0FBOEJiLHlCQUFzQlAsSUFBRCxJQUNuQixvQkFBQyxRQUFELFFBQ0Usb0RBREYsd0VBR0Usb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQUhGLEVBSUksb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRUssT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY0UsZUFBZCxLQUFrQztBQUFuRSxPQUF5RSxvQkFBQyxRQUFELDZFQUV2RSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BRnVFLHFGQUl2RSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BSnVFLENBQXpFLENBSkosRUFVSSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFSCxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjRSxlQUFkLEtBQWtDO0FBQW5FLE9BQTBFLG9CQUFDLFFBQUQsaUZBRXhFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFGd0UsOEZBSXhFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFKd0UsQ0FBMUUsQ0FWSixFQWdCSSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFSCxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjRyxrQkFBZCxLQUFxQztBQUF0RSxPQUE0RSxvQkFBQyxRQUFELFFBQzFFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFEMEUsMEdBRzFFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFIMEUsQ0FBNUUsQ0FoQkosRUFxQkksb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRUosT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY0UsZUFBZCxLQUFrQztBQUFuRSxPQUEwRSxvQkFBQyxRQUFELFFBQ3hFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFEd0UsQ0FBMUUsQ0FyQkosRUF3Qkksb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBR0gsT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY0ksc0JBQWQsS0FBeUM7QUFBM0UsT0FBaUYsb0JBQUMsUUFBRCxRQUMvRSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BRCtFLENBQWpGLENBeEJKLEVBNEJFLGlEQTVCRixnRkE4QkUsb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQTlCRixFQStCRSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFTCxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjSyxnQkFBZCxLQUFtQztBQUFwRSxPQUEwRSxvQkFBQyxRQUFELG1GQUV4RSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BRndFLENBQTFFLENBL0JGLEVBbUNFLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUVOLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNLLGdCQUFkLEtBQW1DO0FBQXBFLE9BQTJFLG9CQUFDLFFBQUQseUZBRXpFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFGeUUsc0dBSXpFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFKeUUsQ0FBM0UsQ0FuQ0YsRUF5Q0ksb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRU4sT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY00sZ0NBQWQsS0FBbUQ7QUFBcEYsT0FBMEYsb0JBQUMsUUFBRCxRQUN4RixvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BRHdGLHlIQUd4RixvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BSHdGLENBQTFGLENBekNKLEVBOENJLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUVQLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNLLGdCQUFkLEtBQW1DO0FBQXBFLE9BQTJFLG9CQUFDLFFBQUQsUUFDekUsb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQUR5RSxFQUV6RSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFHTixPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjTyxvQ0FBZCxLQUF1RDtBQUF6RixPQUErRixvQkFBQyxRQUFELFFBQzdGLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFENkYsQ0FBL0YsQ0FGeUUsQ0FBM0UsQ0E5Q0osRUFxREksK0NBckRKLHdGQXVESSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BdkRKLDZEQXlESSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BekRKLEVBMERJLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUVSLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNRLGNBQWQsS0FBaUM7QUFBbEUsT0FBeUUsb0JBQUMsUUFBRCw0RkFFdkUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQUZ1RSx5R0FJdkUsb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQUp1RSxDQUF6RSxDQTFESixFQWdFTSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFVCxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjUyw4QkFBZCxLQUFpRDtBQUFsRixPQUF3RixvQkFBQyxRQUFELFFBQ3RGLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFEc0YsNEhBR3RGLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFIc0YsQ0FBeEYsQ0FoRU4sRUFxRU0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRVYsT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY1EsY0FBZCxLQUFpQztBQUFsRSxPQUF5RSxvQkFBQyxRQUFELFFBQ3ZFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFEdUUsRUFFdkUsb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBR1QsT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY1Usa0NBQWQsS0FBcUQ7QUFBdkYsT0FBNkYsb0JBQUMsUUFBRCxRQUMzRixvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BRDJGLENBQTdGLENBRnVFLENBQXpFLENBckVOLEVBNEVNLCtDQTVFTixxREE4RU0sb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQTlFTix5REFnRk0sb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQWhGTixzRUFrRk0sb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQWxGTixFQW9GTSwwREFwRk4sd0ZBc0ZNLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUF0Rk4sMEZBd0ZNLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUF4Rk4sZ0RBMEZNLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUExRk4scUZBNEZNLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUE1Rk4sNkdBOEZNLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUE5Rk4sRUFnR00sK0RBaEdOLDBDQWtHTSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BbEdOLEVBbUdNLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUVYLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNXLGFBQWQsS0FBZ0M7QUFBakUsT0FBd0Usb0JBQUMsUUFBRCx1Q0FFdEUsb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQUZzRSxDQUF4RSxDQW5HTixxREF3R00sb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQXhHTixFQXlHTSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFWixPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjWSxhQUFkLEtBQWdDO0FBQWpFLE9BQXdFLG9CQUFDLFFBQUQsb0RBRXRFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFGc0UsQ0FBeEUsQ0F6R04sRUE4R00saURBOUdOLHFDQWdITSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BaEhOLEVBaUhNLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUViLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNhLFlBQWQsS0FBK0I7QUFBaEUsT0FBdUUsb0JBQUMsUUFBRCx3Q0FFckUsb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQUZxRSxDQUF2RSxDQWpITixxQ0FzSE0sb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQXRITixFQXVITSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFZCxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjYyxZQUFkLEtBQStCO0FBQWhFLE9BQXVFLG9CQUFDLFFBQUQsd0NBRXJFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFGcUUsQ0FBdkUsQ0F2SE4sK0dBNEhNLG9CQUFDLFVBQUQ7QUFBWSxVQUFJLEVBQUM7QUFBakIsTUE1SE4sRUE2SE0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRWYsT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY2UsWUFBZCxLQUErQjtBQUFoRSxPQUF1RSxvQkFBQyxRQUFELDhDQUVyRSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BRnFFLDhDQUlyRSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BSnFFLDJDQU1yRSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BTnFFLENBQXZFLENBN0hOLEVBcUlNLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUVoQixPQUFPLElBQUlpQixLQUFLLENBQUNDLE9BQU4sQ0FBY2xCLE9BQU8sQ0FBQ0MsS0FBUixDQUFja0IsWUFBNUIsS0FBNkNuQixPQUFPLENBQUNDLEtBQVIsQ0FBY2tCLFlBQWQsQ0FBMkJDLFFBQTNCLENBQW9DLHlCQUFwQztBQUE5RSxPQUE4SSxvQkFBQyxRQUFELFFBQzVJLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFENEksQ0FBOUksQ0FySU4sZ0RBeUlNLG9CQUFDLFVBQUQ7QUFBWSxVQUFJLEVBQUM7QUFBakIsTUF6SU4sc0NBMklNLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUEzSU4sRUE0SU0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRXBCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNvQixZQUFkLEtBQStCO0FBQWhFLE9BQXdFLG9CQUFDLFFBQUQsMkVBRXRFLG9CQUFDLFVBQUQ7QUFBWSxVQUFJLEVBQUM7QUFBakIsTUFGc0UsQ0FBeEUsQ0E1SU4sRUFnSk0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRXJCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWNxQixZQUFkLEtBQStCO0FBQWhFLE9BQXNFLG9CQUFDLFFBQUQsNkJBRXBFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFGb0UsQ0FBdEUsQ0FoSk4sRUFvSk0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRXRCLE9BQU8sSUFBSWlCLEtBQUssQ0FBQ0MsT0FBTixDQUFjbEIsT0FBTyxDQUFDQyxLQUFSLENBQWNzQixZQUE1QixLQUE2Q3ZCLE9BQU8sQ0FBQ0MsS0FBUixDQUFjc0IsWUFBZCxDQUEyQkgsUUFBM0IsQ0FBb0MseUJBQXBDO0FBQTlFLE9BQThJLG9CQUFDLFFBQUQsUUFDNUksb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQUQ0SSxDQUE5SSxDQXBKTixFQXdKTSx5REF4Sk4sa0VBMEpNLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUExSk4sRUEySk0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRXBCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWN1QixTQUFkLEtBQTRCO0FBQTdELE9BQStGLG9CQUFDLFFBQUQseUlBRTdGLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFGNkYsRUFHN0Ysb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQUg2RixFQUk3RixvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BSjZGLEVBSzdGLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFMNkYsRUFNN0Ysb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQU42RixFQU83RixvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BUDZGLEVBUTdGLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFSNkYsQ0FBL0YsQ0EzSk4sRUFxS00sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRXhCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWN3QixnQkFBZCxLQUFtQztBQUFwRSxPQUEwRSxvQkFBQyxRQUFELFFBQ3hFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFEd0UsQ0FBMUUsQ0FyS04sRUF5S00saURBektOLHFLQTJLTSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BM0tOLEVBNktNLHdFQTdLTixzRkErS00sb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQS9LTixtRUFpTE0sb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQWpMTiwySEFtTE0sb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQW5MTixpRkFxTE0sb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQXJMTiw2QkF1TE0sb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQXZMTixFQXdMTSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFekIsT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY3lCLE1BQWQsS0FBeUI7QUFBMUQsT0FBaUUsb0JBQUMsUUFBRCxvRUFFL0Qsb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQUYrRCwwQ0FJL0Qsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQUorRCw2REFNL0Qsb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQU4rRCxDQUFqRSxDQXhMTixFQWdNTSxvQkFBQyxTQUFEO0FBQVcsZUFBUyxFQUFFMUIsT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY3lCLE1BQWQsS0FBeUI7QUFBMUQsT0FBZ0Usb0JBQUMsUUFBRCxxREFFOUQsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQUY4RCxDQUFoRSxDQWhNTixrQ0FxTU0sb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQXJNTixFQXVNTSxpREF2TU4sMkJBeU1NLG9CQUFDLFVBQUQ7QUFBWSxVQUFJLEVBQUM7QUFBakIsTUF6TU4sRUEwTU0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRTFCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWMwQixXQUFkLEtBQThCO0FBQS9ELE9BQXNFLG9CQUFDLFFBQUQsMkVBQ0wsK0JBREssRUFFcEUsb0JBQUMsUUFBRDtBQUFVLFVBQUksRUFBQztBQUFmLE1BRm9FLEVBRXJDLCtCQUZxQyxDQUF0RSxDQTFNTiw4QkErTU0sb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQS9NTixFQWdOTSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BaE5OLEVBaU5NLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFqTk4sRUFrTk0sb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQWxOTixFQW1OTSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1Bbk5OLEVBb05NLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFwTk4sRUFxTk0sb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQXJOTixFQXNOTSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1BdE5OLEVBdU5NLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUF2Tk4sRUF3Tk0sb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQXhOTixFQXlOTSxvQkFBQyxTQUFEO0FBQVcsVUFBSSxFQUFDO0FBQWhCLE1Bek5OLEVBME5NLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUExTk4sRUEyTk0sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRTNCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWMyQixXQUFkLEtBQThCO0FBQS9ELE9BQXFFLG9CQUFDLFFBQUQsMkVBRW5FLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFGbUUsQ0FBckUsQ0EzTk4sOEJBZ09NLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFoT04sRUFpT00sb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRTVCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxLQUFSLENBQWM0QixXQUFkLEtBQThCO0FBQS9ELE9BQXNGLG9CQUFDLFFBQUQsNEZBRXBGLG9CQUFDLFVBQUQ7QUFBWSxVQUFJLEVBQUM7QUFBakIsTUFGb0YsQ0FBdEYsQ0FqT04sd0VBcU93RSwrQkFyT3hFLEVBc09NLG9CQUFDLFFBQUQ7QUFBVSxVQUFJLEVBQUM7QUFBZixNQXRPTixFQXVPTSxvQkFBQyxPQUFEO0FBQVMsYUFBTyxFQUFDO0FBQWpCLE1Bdk9OLG9CQXdPTSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BeE9OLHdCQXlPd0IsK0JBek94QixFQTBPTSxvQkFBQyxRQUFEO0FBQVUsVUFBSSxFQUFDO0FBQWYsTUExT04sRUEyT00sb0JBQUMsT0FBRDtBQUFTLGFBQU8sRUFBQztBQUFqQixNQTNPTiw2REE0TzZELCtCQTVPN0QsRUE2T00sb0JBQUMsUUFBRDtBQUFVLFVBQUksRUFBQztBQUFmLE1BN09OLEVBOE9NLG9CQUFDLE9BQUQ7QUFBUyxhQUFPLEVBQUM7QUFBakIsTUE5T04sbUpBZ1BNLG9CQUFDLFFBQUQ7QUFBVSxVQUFJLEVBQUM7QUFBZixNQWhQTixFQWlQTSxvQkFBQyxPQUFEO0FBQVMsYUFBTyxFQUFDO0FBQWpCLE1BalBOLHVFQWtQdUUsK0JBbFB2RSxFQW1QTSxvQkFBQyxRQUFEO0FBQVUsVUFBSSxFQUFDO0FBQWYsTUFuUE4sRUFvUE0sb0JBQUMsT0FBRDtBQUFTLGFBQU8sRUFBQztBQUFqQixNQXBQTixpR0FzUE0sb0JBQUMsT0FBRDtBQUFTLGFBQU8sRUFBQztBQUFqQixNQXRQTiwyQ0F3UE0sb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQXhQTixDQS9CVztBQTRSYix5QkFBc0JsQyxJQUFELElBQ25CLG9CQUFDLFFBQUQsUUFDQSw0RUFEQSxrRUFHQSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BSEEsRUFJQSx1REFKQSwyR0FNQSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BTkEsNkdBUUEsb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQVJBLEVBU0EscUNBVEEsdUNBV0Esb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQVhBLEVBWUEsd0ZBWkEscUZBY0Esb0JBQUMsU0FBRDtBQUFXLFVBQUksRUFBQztBQUFoQixNQWRBLEVBZUEsb0JBQUMsU0FBRDtBQUFXLGVBQVMsRUFBRUssT0FBTyxJQUFJaUIsS0FBSyxDQUFDQyxPQUFOLENBQWNsQixPQUFPLENBQUNDLEtBQVIsQ0FBYzZCLGNBQTVCLEtBQStDOUIsT0FBTyxDQUFDQyxLQUFSLENBQWM2QixjQUFkLENBQTZCQyxNQUE3QixJQUF1QztBQUF2SCxPQUEwSCxvQkFBQyxRQUFELDhNQUV4SCxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BRndILENBQTFILENBZkEsRUFtQkEsNENBbkJBLHNEQXFCQSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BckJBLEVBc0JBLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUUvQixPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjK0IsY0FBZCxLQUFpQztBQUFsRSxPQUF5RSxvQkFBQyxRQUFELHdFQUV2RSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BRnVFLENBQXpFLENBdEJBLEVBMEJBLG9CQUFDLFNBQUQ7QUFBVyxlQUFTLEVBQUVoQyxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjZ0MsY0FBZCxLQUFpQztBQUFsRSxPQUF3RSxvQkFBQyxRQUFELHVHQUV0RSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BRnNFLENBQXhFLENBMUJBLEVBOEJBLHlDQTlCQSw2RUFnQ0Esb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQWhDQSxFQWlDQSw4Q0FqQ0EsZ05BbUNBLG9CQUFDLFVBQUQ7QUFBWSxVQUFJLEVBQUM7QUFBakIsTUFuQ0EsRUFvQ0EsbURBcENBLG9LQXNDQSxvQkFBQyxVQUFEO0FBQVksVUFBSSxFQUFDO0FBQWpCLE1BdENBLEVBdUNBLGdEQXZDQSxvQ0F5Q0Esb0JBQUMsVUFBRDtBQUFZLFVBQUksRUFBQztBQUFqQixNQXpDQSxFQTBDQSw0Q0ExQ0EseUhBNENBLG9CQUFDLFVBQUQ7QUFBWSxVQUFJLEVBQUM7QUFBakIsTUE1Q0E7QUE3UlcsR0FEVTtBQWdWekIscUJBQW9CdEMsSUFBRCxJQUNqQixvQkFBQyxRQUFELFFBQ0Usb0RBREYsRUFHRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBSEYsRUFJRSwrQkFKRixFQUtFLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFMRixFQU1FLCtCQU5GLEVBT0UsNENBUEYsRUFRRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBUkYsRUFTRSwrQkFURixFQVVFLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFWRixFQVdFLCtCQVhGLEVBWUUsMkNBWkYsRUFhRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBYkYsQ0FqVnVCO0FBa1d6Qix3QkFBdUJBLElBQUQsSUFDcEIsb0JBQUMsUUFBRCxRQUNFLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFERixFQUVFLCtCQUZGLEVBR0Usb0JBQUMsU0FBRDtBQUFXLFFBQUksRUFBQztBQUFoQixJQUhGLEVBSUUsK0JBSkYsRUFLRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBTEYsQ0FuV3VCO0FBNFd6QixvQkFBbUJBLElBQUQsSUFDaEIsb0JBQUMsUUFBRCxRQUNFLGlDQUFLLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFBTCxDQURGLEVBRUUsaUNBQUssb0JBQUMsU0FBRDtBQUFXLFFBQUksRUFBQztBQUFoQixJQUFMLENBRkYsRUFHRSxpQ0FBSyxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBQUwsQ0FIRixFQUlFLGlDQUFLLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFBTCxDQUpGLEVBTUUsb0JBQUMsU0FBRDtBQUFXLGFBQVMsRUFBRUssT0FBTyxJQUFJa0MsSUFBSSxDQUFDQyxHQUFMLENBQVNuQyxPQUFPLENBQUNDLEtBQVIsQ0FBY21DLE1BQWQsR0FBdUJwQyxPQUFPLENBQUNDLEtBQVIsQ0FBY29DLE1BQTlDLElBQXdELENBQXhELElBQTZESCxJQUFJLENBQUNDLEdBQUwsQ0FBU25DLE9BQU8sQ0FBQ0MsS0FBUixDQUFjcUMsTUFBZCxHQUF1QnRDLE9BQU8sQ0FBQ0MsS0FBUixDQUFjc0MsTUFBOUMsSUFBd0Q7QUFBdEosS0FBMEosb0JBQUMsUUFBRCxRQUN4SixpQ0FBSyxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBQUwsQ0FEd0osRUFFeEosaUNBQUssb0JBQUMsU0FBRDtBQUFXLFFBQUksRUFBQztBQUFoQixJQUFMLENBRndKLENBQTFKLENBTkYsRUFXRSxpQ0FBSyxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBQUwsQ0FYRixDQTdXdUI7QUE0WHpCLGdCQUFlNUMsSUFBRCxJQUNaLG9CQUFDLFFBQUQsUUFDRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBREYsQ0E3WHVCO0FBa1l6QixlQUFjQSxJQUFELElBQ1gsb0JBQUMsUUFBRCxRQUNFLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFERixFQUVFLG9CQUFDLGFBQUQ7QUFBZSxRQUFJLEVBQUM7QUFBcEIsSUFGRixFQUdFLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFIRixDQW5ZdUI7QUEwWXpCLGlCQUFnQkEsSUFBRCxJQUNiLG9CQUFDLFFBQUQsUUFDRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBREYsRUFFRSxvQkFBQyxTQUFEO0FBQVcsYUFBUyxFQUFFSyxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjdUMsYUFBZCxLQUFnQztBQUFqRSxLQUF1RSxvQkFBQyxRQUFELFFBQ3JFLG9CQUFDLGFBQUQ7QUFBZSxRQUFJLEVBQUM7QUFBcEIsSUFEcUUsQ0FBdkUsQ0FGRixFQUtFLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFMRixFQU1FLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFORixDQTNZdUI7QUFxWnpCLGlCQUFlO0FBQ2Isa0NBQStCN0MsSUFBRCxJQUM1QixvQkFBQyxRQUFELHlDQUVFLG9CQUFDLFNBQUQ7QUFBVyxVQUFJLEVBQUM7QUFBaEIsTUFGRiw2R0FJRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BSkYsMkVBTUUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQU5GLGdFQVFFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFSRix1REFVRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BVkYsNERBWUUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQVpGLHdEQWNFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFkRixnREFnQkUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQWhCRixDQUZXO0FBc0JiLG1DQUFnQ0EsSUFBRCxJQUM3QixvQkFBQyxRQUFELG1IQUVFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFGRiwyRUFJRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BSkYsZ0VBTUUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQU5GLHVEQVFFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFSRiw0REFVRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BVkYsd0RBWUUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQVpGLGdEQWNFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFkRjtBQXZCVyxHQXJaVTtBQStiekIsc0JBQXFCQSxJQUFELElBQ2xCLG9CQUFDLFFBQUQsUUFDR0Qsb0JBQW9CLENBQUNDLElBQUQsQ0FEdkIscUJBR0Usb0JBQUMsV0FBRDtBQUFhLFFBQUksRUFBQztBQUFsQixJQUhGLEVBSUUsb0JBQUMsU0FBRDtBQUFXLGFBQVMsRUFBRUssT0FBTyxJQUFJaUIsS0FBSyxDQUFDQyxPQUFOLENBQWNsQixPQUFPLENBQUNDLEtBQVIsQ0FBY3dDLFdBQTVCLEtBQTRDekMsT0FBTyxDQUFDQyxLQUFSLENBQWN3QyxXQUFkLENBQTBCckIsUUFBMUIsQ0FBbUMsb0JBQW5DO0FBQTdFLEtBQXVJLG9CQUFDLFFBQUQsNEJBRXJJLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUFGcUksQ0FBdkksQ0FKRiwyQkFTRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBVEYsRUFVRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBVkYsRUFXRSxvQkFBQyxTQUFEO0FBQVcsYUFBUyxFQUFFcEIsT0FBTyxJQUFJQSxPQUFPLENBQUNDLEtBQVIsQ0FBY3lDLFdBQWQsS0FBOEI7QUFBL0QsS0FBcUUsb0JBQUMsUUFBRCw0QkFFbkUsb0JBQUMsYUFBRDtBQUFlLFFBQUksRUFBQztBQUFwQixJQUZtRSxDQUFyRSxDQVhGLG9CQWdCRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBaEJGLENBaGN1QjtBQW9kekIsbUJBQWtCL0MsSUFBRCxJQUNmLG9CQUFDLFFBQUQsUUFDRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBREYsRUFFRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBRkYsRUFHRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBSEYsRUFJRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBSkYsRUFLRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBTEYsRUFNRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBTkYsRUFPRSxvQkFBQyxTQUFEO0FBQVcsUUFBSSxFQUFDO0FBQWhCLElBUEYsRUFRRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBUkYsRUFTRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBVEYsRUFVRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBVkYsRUFXRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBWEYsRUFZRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBWkYsRUFhRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBYkYsRUFjRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBZEYsRUFlRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBZkYsRUFnQkUsb0JBQUMsYUFBRDtBQUFlLFFBQUksRUFBQztBQUFwQixJQWhCRixFQWlCRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBakJGLEVBa0JFLG9CQUFDLGFBQUQ7QUFBZSxRQUFJLEVBQUM7QUFBcEIsSUFsQkYsRUFtQkUsb0JBQUMsYUFBRDtBQUFlLFFBQUksRUFBQztBQUFwQixJQW5CRixFQW9CRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBcEJGLEVBcUJFLG9CQUFDLGFBQUQ7QUFBZSxRQUFJLEVBQUM7QUFBcEIsSUFyQkYsRUFzQkUsb0JBQUMsYUFBRDtBQUFlLFFBQUksRUFBQztBQUFwQixJQXRCRixFQXVCRSxvQkFBQyxhQUFEO0FBQWUsUUFBSSxFQUFDO0FBQXBCLElBdkJGLENBcmR1QjtBQWdmekIsZUFBYztBQUNaLDRCQUF5QkEsSUFBRCxJQUN0QixvQkFBQyxRQUFELFFBQ0dELG9CQUFvQixDQUFDQyxJQUFELENBRHZCLHlLQUlFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFKRix1SEFPRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BUEYsZ0hBVUUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQVZGLGdIQWFFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFiRixDQUZVO0FBbUJaLDBCQUF1QkEsSUFBRCxJQUNwQixvQkFBQyxRQUFELFFBQ0dELG9CQUFvQixDQUFDQyxJQUFELENBRHZCLEVBRUUsb0JBQUMsT0FBRDtBQUFTLGFBQU8sRUFBQztBQUFqQixNQUZGLGtFQUlFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFKRiwrREFNRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BTkYsNkNBUUUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQVJGLG9DQVVFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFWRiw2REFZRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BWkYsd0RBY0Usb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQWRGLG1FQWdCRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BaEJGLENBcEJVO0FBd0NaLDZCQUEwQkEsSUFBRCxJQUN2QixvQkFBQyxRQUFELFFBQ0dELG9CQUFvQixDQUFDQyxJQUFELENBRHZCLHlLQUlFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFKRix1SEFPRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BUEYsZ0hBVUUsb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQVZGLGdIQWFFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFiRixDQXpDVTtBQTBEWiwyQkFBd0JBLElBQUQsSUFDckIsb0JBQUMsUUFBRCxRQUNHRCxvQkFBb0IsQ0FBQ0MsSUFBRCxDQUR2QixrRUFHRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BSEYsK0RBS0Usb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQUxGLDZDQU9FLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFQRixvQ0FTRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BVEYsNkRBV0Usb0JBQUMsV0FBRDtBQUFhLFVBQUksRUFBQztBQUFsQixNQVhGLHdEQWFFLG9CQUFDLFdBQUQ7QUFBYSxVQUFJLEVBQUM7QUFBbEIsTUFiRixtRUFlRSxvQkFBQyxXQUFEO0FBQWEsVUFBSSxFQUFDO0FBQWxCLE1BZkY7QUEzRFUsR0FoZlc7QUErakJ6Qiw2QkFBNEJBLElBQUQsSUFDekIsb0JBQUMsUUFBRCx5REFFRSxvQkFBQyxXQUFEO0FBQWEsUUFBSSxFQUFDO0FBQWxCLElBRkYsK0RBSUUsb0JBQUMsU0FBRDtBQUFXLFFBQUksRUFBQztBQUFoQixJQUpGLHVEQU1FLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUFORiw4RUFRRSxvQkFBQyxXQUFEO0FBQWEsUUFBSSxFQUFDO0FBQWxCLElBUkYsa0VBVUUsb0JBQUMsV0FBRDtBQUFhLFFBQUksRUFBQztBQUFsQixJQVZGLGtEQVlFLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUFaRixpREFjRSxvQkFBQyxXQUFEO0FBQWEsUUFBSSxFQUFDO0FBQWxCLElBZEYsOENBZ0JFLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUFoQkYsNERBa0JFLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUFsQkYsc0RBb0JFLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUFwQkYsa0RBc0JFLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUF0QkYsa0VBd0JFLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUF4QkYsc0VBMEJFLG9CQUFDLFNBQUQ7QUFBVyxRQUFJLEVBQUM7QUFBaEIsSUExQkYsaURBNEJFLG9CQUFDLFdBQUQ7QUFBYSxRQUFJLEVBQUM7QUFBbEIsSUE1QkY7QUFoa0J1QixDQUFwQixDOzs7Ozs7Ozs7OztBQzVEUG5DLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNVLGFBQVcsRUFBQyxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUl3RSxZQUFKO0FBQWlCbkYsTUFBTSxDQUFDTSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDMkUsZ0JBQVksR0FBQzNFLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSTRFLFdBQUo7QUFBZ0JwRixNQUFNLENBQUNNLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDNEUsZUFBVyxHQUFDNUUsQ0FBWjtBQUFjOztBQUExQixDQUF2QyxFQUFtRSxDQUFuRTtBQUl6STtBQUNBMkUsWUFBWSxDQUFDRSxrQkFBYixDQUFnQztBQUM5QkMsVUFBUSxFQUFFO0FBQ1JDLE1BQUUsRUFBRTtBQUNGLHFCQUFlO0FBRGI7QUFESTtBQURvQixDQUFoQyxFLENBUUE7O0FBQ08sTUFBTTVFLFdBQVcsR0FBRztBQUN6QixrQkFBZTtBQUNiLG9CQUNBLElBQUl3RSxZQUFKLENBQWlCO0FBQ2ZLLFVBQUksRUFBRTtBQUNKQyxZQUFJLEVBQUVDLE1BREY7QUFFSkMsYUFBSyxFQUFFLE9BRkg7QUFHSkMsYUFBSyxFQUFFO0FBSEgsT0FEUztBQU1mO0FBQ0E7QUFDQTtBQUNBO0FBQ0FDLFlBQU0sRUFBRTtBQUNOSixZQUFJLEVBQUVDLE1BREE7QUFFTkkscUJBQWEsRUFBRSxDQUFDLE1BQUQsRUFBUyxRQUFUO0FBRlQsT0FWTztBQWNmQyxjQUFRLEVBQUU7QUFDUk4sWUFBSSxFQUFFQyxNQURFO0FBRVJDLGFBQUssRUFBRTtBQUZDLE9BZEs7QUFrQmZLLFNBQUcsRUFBRTtBQUNIUCxZQUFJLEVBQUVOLFlBQVksQ0FBQ2MsT0FEaEI7QUFFSEMsV0FBRyxFQUFFLENBRkY7QUFHSEMsaUJBQVMsRUFBRSxZQUFZO0FBQ3JCLGdCQUFNQyxTQUFTLEdBQUcsS0FBS0MsWUFBTCxDQUFrQixVQUFsQixFQUE4QkMsS0FBaEQ7QUFDQSxnQkFBTUMsV0FBVyxHQUFHLElBQUlDLElBQUosRUFBcEI7QUFDQSxnQkFBTUMsU0FBUyxHQUFHQyxNQUFNLENBQUNOLFNBQVMsQ0FBQ08sU0FBVixDQUFvQlAsU0FBUyxDQUFDN0IsTUFBVixHQUFpQixDQUFyQyxFQUF1QzZCLFNBQVMsQ0FBQzdCLE1BQWpELENBQUQsQ0FBeEI7QUFDQSxnQkFBTXlCLEdBQUcsR0FBR08sV0FBVyxDQUFDSyxXQUFaLEtBQTRCSCxTQUF4QztBQUNBLGlCQUFPVCxHQUFQO0FBQ0Q7QUFURSxPQWxCVTtBQTZCZmEsY0FBUSxFQUFFO0FBQ1JwQixZQUFJLEVBQUVDO0FBREUsT0E3Qks7QUFnQ2ZvQixhQUFPLEVBQUU7QUFDUHJCLFlBQUksRUFBRUM7QUFEQyxPQWhDTTtBQW1DZnFCLGFBQU8sRUFBRTtBQUNQdEIsWUFBSSxFQUFFQyxNQURDO0FBRVBDLGFBQUssRUFBRTtBQUZBLE9BbkNNO0FBdUNmcUIsbUJBQWEsRUFBRTtBQUNidkIsWUFBSSxFQUFFQyxNQURPO0FBRWJDLGFBQUssRUFBRTtBQUZNLE9BdkNBO0FBMkNmc0IscUJBQWUsRUFBRTtBQUNmeEIsWUFBSSxFQUFFaEM7QUFEUyxPQTNDRjtBQThDZiwyQkFBcUI7QUFDbkJnQyxZQUFJLEVBQUVDLE1BRGE7QUFFbkJJLHFCQUFhLEVBQUUsQ0FBQyxZQUFELEVBQWUsTUFBZixFQUF1QixTQUF2QixFQUFrQyxRQUFsQztBQUZJLE9BOUNOO0FBa0Rmb0Isc0JBQWdCLEVBQUU7QUFDaEJ6QixZQUFJLEVBQUVoQztBQURVLE9BbERIO0FBcURmLDRCQUFzQjtBQUNwQmdDLFlBQUksRUFBRUMsTUFEYztBQUVwQkkscUJBQWEsRUFBRSxDQUFDLFlBQUQsRUFBZSxNQUFmLEVBQXVCLFNBQXZCLEVBQWtDLFFBQWxDO0FBRkssT0FyRFA7QUF5RGZwRCxzQkFBZ0IsRUFBRTtBQUNoQitDLFlBQUksRUFBRUMsTUFEVTtBQUVoQkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBUSxJQUFSO0FBRkMsT0F6REg7QUE2RGZxQixtQkFBYSxFQUFFO0FBQ2IxQixZQUFJLEVBQUVDLE1BRE87QUFFYjBCLGdCQUFRLEVBQUU7QUFGRyxPQTdEQTtBQWlFZkMsY0FBUSxFQUFFO0FBQ1I1QixZQUFJLEVBQUVDLE1BREU7QUFFUkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBUSxJQUFSO0FBRlA7QUFqRUssS0FBakIsQ0FGYTtBQXlFYix5QkFDQSxJQUFJWCxZQUFKLENBQWlCO0FBQ2Z4QyxxQkFBZSxFQUFFO0FBQ2Y4QyxZQUFJLEVBQUVDLE1BRFM7QUFFZkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBUSxJQUFSO0FBRkEsT0FERjtBQUtmd0IscUJBQWUsRUFBRTtBQUNmN0IsWUFBSSxFQUFFQyxNQURTO0FBRWZJLHFCQUFhLEVBQUUsQ0FBQyxxQkFBRCxFQUF3Qix1QkFBeEIsQ0FGQTtBQUdmc0IsZ0JBQVEsRUFBRTtBQUhLLE9BTEY7QUFVZkcscUJBQWUsRUFBRTtBQUNmOUIsWUFBSSxFQUFFaEMsS0FEUztBQUVmMkQsZ0JBQVEsRUFBRTtBQUZLLE9BVkY7QUFjZiwyQkFBcUI7QUFDbkIzQixZQUFJLEVBQUVDLE1BRGE7QUFFbkIwQixnQkFBUSxFQUFFLElBRlM7QUFHbkJ0QixxQkFBYSxFQUFFLENBQUMscUJBQUQsRUFDQyxrQkFERCxFQUVDLGFBRkQsRUFHQyxrQkFIRCxFQUlDLHFCQUpELEVBS0MsZ0JBTEQsRUFNQyxxQkFORCxFQU9DLHdDQVBELEVBUUMsbUJBUkQ7QUFISSxPQWROO0FBNkJmMEIscUJBQWUsRUFBRTtBQUNmL0IsWUFBSSxFQUFFQyxNQURTO0FBRWYwQixnQkFBUSxFQUFFLElBRks7QUFHZnRCLHFCQUFhLEVBQUUsQ0FBQyx3Q0FBRCxFQUEyQywrQ0FBM0MsRUFBMkYsMkNBQTNGLEVBQXVJLFlBQXZJO0FBSEEsT0E3QkY7QUFrQ2ZsRCx3QkFBa0IsRUFBRTtBQUNsQjZDLFlBQUksRUFBRWdDLE9BRFk7QUFFbEJMLGdCQUFRLEVBQUUsSUFGUTtBQUdsQnhCLGFBQUssRUFBRTtBQUhXLE9BbENMO0FBdUNmOEIscUJBQWUsRUFBRTtBQUNmakMsWUFBSSxFQUFFQyxNQURTO0FBRWYwQixnQkFBUSxFQUFFO0FBRkssT0F2Q0Y7QUEyQ2Z2RSw0QkFBc0IsRUFBRTtBQUN0QjRDLFlBQUksRUFBRWdDLE9BRGdCO0FBRXRCTCxnQkFBUSxFQUFFLElBRlk7QUFHdEJ4QixhQUFLLEVBQUU7QUFIZSxPQTNDVDtBQWdEZitCLHlCQUFtQixFQUFFO0FBQ25CbEMsWUFBSSxFQUFFQyxNQURhO0FBRW5CMEIsZ0JBQVEsRUFBRTtBQUZTLE9BaEROO0FBb0RmUSxxQkFBZSxFQUFFO0FBQ2ZuQyxZQUFJLEVBQUVDLE1BRFM7QUFFZjBCLGdCQUFRLEVBQUUsSUFGSztBQUdmdEIscUJBQWEsRUFBRSxDQUFDLEdBQUQsRUFBTSxLQUFOLEVBQVksS0FBWixFQUFrQixpQkFBbEI7QUFIQSxPQXBERjtBQXlEZmhELHNCQUFnQixFQUFFO0FBQ2hCMkMsWUFBSSxFQUFFQyxNQURVO0FBRWhCSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUFRLElBQVI7QUFGQyxPQXpESDtBQTZEZitCLHNCQUFnQixFQUFFO0FBQ2hCcEMsWUFBSSxFQUFFQyxNQURVO0FBRWhCMEIsZ0JBQVEsRUFBRSxJQUZNO0FBR2hCdEIscUJBQWEsRUFBRSxDQUFDLHFCQUFELEVBQXdCLHVCQUF4QjtBQUhDLE9BN0RIO0FBa0VmZ0Msc0JBQWdCLEVBQUU7QUFDaEJyQyxZQUFJLEVBQUVDLE1BRFU7QUFFaEIwQixnQkFBUSxFQUFFLElBRk07QUFHaEJ0QixxQkFBYSxFQUFFLENBQUMsd0NBQUQsRUFBMkMsK0NBQTNDLEVBQTJGLDJDQUEzRixFQUF1SSxZQUF2STtBQUhDLE9BbEVIO0FBdUVmL0Msc0NBQWdDLEVBQUU7QUFDaEMwQyxZQUFJLEVBQUVnQyxPQUQwQjtBQUVoQ0wsZ0JBQVEsRUFBRSxJQUZzQjtBQUdoQ3hCLGFBQUssRUFBRTtBQUh5QixPQXZFbkI7QUE0RWZtQyxtQ0FBNkIsRUFBRTtBQUM3QnRDLFlBQUksRUFBRUMsTUFEdUI7QUFFN0IwQixnQkFBUSxFQUFFO0FBRm1CLE9BNUVoQjtBQWdGZnBFLDBDQUFvQyxFQUFFO0FBQ3BDeUMsWUFBSSxFQUFFZ0MsT0FEOEI7QUFFcENMLGdCQUFRLEVBQUUsSUFGMEI7QUFHcEN4QixhQUFLLEVBQUU7QUFINkIsT0FoRnZCO0FBcUZmb0MsdUNBQWlDLEVBQUU7QUFDakN2QyxZQUFJLEVBQUVDLE1BRDJCO0FBRWpDMEIsZ0JBQVEsRUFBRTtBQUZ1QixPQXJGcEI7QUF5RmZhLHNCQUFnQixFQUFFO0FBQ2hCeEMsWUFBSSxFQUFFQyxNQURVO0FBRWhCMEIsZ0JBQVEsRUFBRSxJQUZNO0FBR2hCdEIscUJBQWEsRUFBRSxDQUFDLEdBQUQsRUFBTSxLQUFOLEVBQVksS0FBWixFQUFrQixpQkFBbEI7QUFIQyxPQXpGSDtBQThGZjdDLG9CQUFjLEVBQUU7QUFDZHdDLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUFRLElBQVI7QUFGRCxPQTlGRDtBQWtHZm9DLG9CQUFjLEVBQUU7QUFDZHpDLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMscUJBQUQsRUFBd0IsdUJBQXhCO0FBRkQsT0FsR0Q7QUFzR2ZxQyxvQkFBYyxFQUFFO0FBQ2QxQyxZQUFJLEVBQUVDLE1BRFE7QUFFZDBCLGdCQUFRLEVBQUUsSUFGSTtBQUdkdEIscUJBQWEsRUFBRSxDQUFDLHdDQUFELEVBQTJDLCtDQUEzQyxFQUEyRiwyQ0FBM0YsRUFBdUksWUFBdkk7QUFIRCxPQXRHRDtBQTJHZjVDLG9DQUE4QixFQUFFO0FBQzlCdUMsWUFBSSxFQUFFZ0MsT0FEd0I7QUFFOUJMLGdCQUFRLEVBQUUsSUFGb0I7QUFHOUJ4QixhQUFLLEVBQUU7QUFIdUIsT0EzR2pCO0FBZ0hmd0MsaUNBQTJCLEVBQUU7QUFDM0IzQyxZQUFJLEVBQUVDLE1BRHFCO0FBRTNCMEIsZ0JBQVEsRUFBRTtBQUZpQixPQWhIZDtBQW9IZmpFLHdDQUFrQyxFQUFFO0FBQ2xDc0MsWUFBSSxFQUFFZ0MsT0FENEI7QUFFbENMLGdCQUFRLEVBQUUsSUFGd0I7QUFHbEN4QixhQUFLLEVBQUU7QUFIMkIsT0FwSHJCO0FBeUhmeUMscUNBQStCLEVBQUU7QUFDL0I1QyxZQUFJLEVBQUVDLE1BRHlCO0FBRS9CMEIsZ0JBQVEsRUFBRTtBQUZxQixPQXpIbEI7QUE2SGZrQixvQkFBYyxFQUFFO0FBQ2Q3QyxZQUFJLEVBQUVDLE1BRFE7QUFFZDBCLGdCQUFRLEVBQUUsSUFGSTtBQUdkdEIscUJBQWEsRUFBRSxDQUFDLEdBQUQsRUFBTSxLQUFOLEVBQVksS0FBWixFQUFrQixpQkFBbEI7QUFIRCxPQTdIRDtBQWtJZnlDLFVBQUksRUFBRTtBQUNKOUMsWUFBSSxFQUFFQyxNQURGO0FBRUpJLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQU8sSUFBUDtBQUZYLE9BbElTO0FBc0lmMEMsVUFBSSxFQUFFO0FBQ0ovQyxZQUFJLEVBQUVDLE1BREY7QUFFSkkscUJBQWEsRUFBRSxDQUFDLGdFQUFELEVBQ0MsOERBREQsRUFFQyxJQUZEO0FBRlgsT0F0SVM7QUE0SWYyQyxVQUFJLEVBQUU7QUFDSmhELFlBQUksRUFBRWhDO0FBREYsT0E1SVM7QUErSWYsZ0JBQVU7QUFDUmdDLFlBQUksRUFBRUMsTUFERTtBQUVSSSxxQkFBYSxFQUFFLENBQUMseUNBQUQsRUFDQyxtQkFERCxFQUVDLGdCQUZELEVBR0MsYUFIRCxFQUlDLGNBSkQsRUFLQyxPQUxELEVBTUMsa0JBTkQsRUFPQyxtQkFQRDtBQUZQLE9BL0lLO0FBMEpmNEMscUJBQWUsRUFBRTtBQUNmakQsWUFBSSxFQUFFQztBQURTLE9BMUpGO0FBNkpmaUQscUJBQWUsRUFBRTtBQUNmbEQsWUFBSSxFQUFFQztBQURTLE9BN0pGO0FBZ0tma0QscUJBQWUsRUFBRTtBQUNmbkQsWUFBSSxFQUFFQztBQURTLE9BaEtGO0FBbUtmbUQscUJBQWUsRUFBRTtBQUNmcEQsWUFBSSxFQUFFQztBQURTLE9BbktGO0FBc0tmb0QscUJBQWUsRUFBRTtBQUNmckQsWUFBSSxFQUFFQztBQURTLE9BdEtGO0FBeUtmdEMsbUJBQWEsRUFBRTtBQUNicUMsWUFBSSxFQUFFQyxNQURPO0FBRWJJLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQU8sSUFBUDtBQUZGLE9BektBO0FBNktmaUQsbUJBQWEsRUFBRTtBQUNidEQsWUFBSSxFQUFFQyxNQURPO0FBRWIwQixnQkFBUSxFQUFFO0FBRkcsT0E3S0E7QUFpTGYvRCxtQkFBYSxFQUFFO0FBQ2JvQyxZQUFJLEVBQUVDLE1BRE87QUFFYkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBTyxJQUFQO0FBRkYsT0FqTEE7QUFxTGZrRCxtQkFBYSxFQUFFO0FBQ2J2RCxZQUFJLEVBQUVDLE1BRE87QUFFYjBCLGdCQUFRLEVBQUU7QUFGRyxPQXJMQTtBQXlMZjlELGtCQUFZLEVBQUU7QUFDWm1DLFlBQUksRUFBRUMsTUFETTtBQUVaSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUFPLElBQVA7QUFGSCxPQXpMQztBQTZMZm1ELGtCQUFZLEVBQUU7QUFDWnhELFlBQUksRUFBRUMsTUFETTtBQUVaMEIsZ0JBQVEsRUFBRTtBQUZFLE9BN0xDO0FBaU1mN0Qsa0JBQVksRUFBRTtBQUNaa0MsWUFBSSxFQUFFQyxNQURNO0FBRVpJLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQU8sSUFBUDtBQUZILE9Bak1DO0FBcU1mb0Qsa0JBQVksRUFBRTtBQUNaekQsWUFBSSxFQUFFQyxNQURNO0FBRVowQixnQkFBUSxFQUFFO0FBRkUsT0FyTUM7QUF5TWY1RCxrQkFBWSxFQUFFO0FBQ1ppQyxZQUFJLEVBQUVDLE1BRE07QUFFWkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBTyxJQUFQO0FBRkgsT0F6TUM7QUE2TWZxRCxrQkFBWSxFQUFFO0FBQ1oxRCxZQUFJLEVBQUVDLE1BRE07QUFFWjBCLGdCQUFRLEVBQUU7QUFGRSxPQTdNQztBQWlOZmdDLGtCQUFZLEVBQUU7QUFDWjNELFlBQUksRUFBRUMsTUFETTtBQUVaMEIsZ0JBQVEsRUFBRTtBQUZFLE9Bak5DO0FBcU5mekQsa0JBQVksRUFBRTtBQUNaOEIsWUFBSSxFQUFFaEMsS0FETTtBQUVaMkQsZ0JBQVEsRUFBRTtBQUZFLE9Bck5DO0FBeU5mLHdCQUFrQjtBQUNoQjNCLFlBQUksRUFBRUMsTUFEVTtBQUVoQkkscUJBQWEsRUFBRSxDQUFDLFVBQUQsRUFDQyxVQURELEVBRUMsc0JBRkQsRUFHQyxrQ0FIRCxFQUlDLHlCQUpEO0FBRkMsT0F6Tkg7QUFpT2Z1RCxxQkFBZSxFQUFDO0FBQ2Q1RCxZQUFJLEVBQUVDLE1BRFE7QUFFZDBCLGdCQUFRLEVBQUU7QUFGSSxPQWpPRDtBQXFPZmtDLGlCQUFXLEVBQUU7QUFDWDdELFlBQUksRUFBRUMsTUFESztBQUVYSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUFPLElBQVA7QUFGSixPQXJPRTtBQXlPZmpDLGtCQUFZLEVBQUU7QUFDWjRCLFlBQUksRUFBRUMsTUFETTtBQUVaSSxxQkFBYSxFQUFFLENBQUMsUUFBRCxFQUFVLHFDQUFWLEVBQWdELE1BQWhEO0FBRkgsT0F6T0M7QUE2T2ZoQyxrQkFBWSxFQUFFO0FBQ1oyQixZQUFJLEVBQUVDLE1BRE07QUFFWjBCLGdCQUFRLEVBQUUsSUFGRTtBQUdadEIscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBTyxJQUFQO0FBSEgsT0E3T0M7QUFrUGYvQixrQkFBWSxFQUFFO0FBQ1owQixZQUFJLEVBQUVoQyxLQURNO0FBRVoyRCxnQkFBUSxFQUFFO0FBRkUsT0FsUEM7QUFzUGYsd0JBQWtCO0FBQ2hCM0IsWUFBSSxFQUFFQyxNQURVO0FBRWhCSSxxQkFBYSxFQUFFLENBQUMseUJBQUQsRUFDQyxzREFERCxFQUVDLDREQUZELEVBR0MsNkNBSEQsRUFJQyx5QkFKRDtBQUZDLE9BdFBIO0FBOFBmeUQsa0JBQVksRUFBRTtBQUNaOUQsWUFBSSxFQUFFQyxNQURNO0FBRVowQixnQkFBUSxFQUFFO0FBRkUsT0E5UEM7QUFrUWZwRCxlQUFTLEVBQUM7QUFDUnlCLFlBQUksRUFBRUMsTUFERTtBQUVSSSxxQkFBYSxFQUFFLENBQUMsVUFBRCxFQUNDLFNBREQsRUFFQyxzQkFGRCxFQUdDLGdDQUhEO0FBRlAsT0FsUUs7QUF5UWYwRCxZQUFNLEVBQUU7QUFDTi9ELFlBQUksRUFBRWdDLE9BREE7QUFFTkwsZ0JBQVEsRUFBRSxJQUZKO0FBR054QixhQUFLLEVBQUU7QUFIRCxPQXpRTztBQThRZjZELFVBQUksRUFBRTtBQUNKaEUsWUFBSSxFQUFFZ0MsT0FERjtBQUVKTCxnQkFBUSxFQUFFLElBRk47QUFHSnhCLGFBQUssRUFBRTtBQUhILE9BOVFTO0FBbVJmOEQsY0FBUSxFQUFFO0FBQ1JqRSxZQUFJLEVBQUVnQyxPQURFO0FBRVJMLGdCQUFRLEVBQUUsSUFGRjtBQUdSeEIsYUFBSyxFQUFFO0FBSEMsT0FuUks7QUF3UmYrRCxlQUFTLEVBQUU7QUFDVGxFLFlBQUksRUFBRWdDLE9BREc7QUFFVEwsZ0JBQVEsRUFBRSxJQUZEO0FBR1R4QixhQUFLLEVBQUU7QUFIRSxPQXhSSTtBQTZSZmdFLFlBQU0sRUFBRTtBQUNObkUsWUFBSSxFQUFFZ0MsT0FEQTtBQUVOTCxnQkFBUSxFQUFFLElBRko7QUFHTnhCLGFBQUssRUFBRTtBQUhELE9BN1JPO0FBa1NmaUUsbUJBQWEsRUFBRTtBQUNicEUsWUFBSSxFQUFFZ0MsT0FETztBQUViTCxnQkFBUSxFQUFFLElBRkc7QUFHYnhCLGFBQUssRUFBRTtBQUhNLE9BbFNBO0FBdVNmM0Isc0JBQWdCLEVBQUU7QUFDaEJ3QixZQUFJLEVBQUVnQyxPQURVO0FBRWhCTCxnQkFBUSxFQUFFLElBRk07QUFHaEJ4QixhQUFLLEVBQUU7QUFIUyxPQXZTSDtBQTRTZmtFLG1CQUFhLEVBQUU7QUFDYnJFLFlBQUksRUFBRUMsTUFETztBQUViMEIsZ0JBQVEsRUFBRTtBQUZHLE9BNVNBO0FBZ1RmMkMsbUJBQWEsRUFBRTtBQUNidEUsWUFBSSxFQUFFaEM7QUFETyxPQWhUQTtBQW1UZix5QkFBbUI7QUFDakJnQyxZQUFJLEVBQUVDLE1BRFc7QUFFakJJLHFCQUFhLEVBQUUsQ0FBQyxxQkFBRCxFQUNDLHdCQURELEVBRUMsd0ZBRkQsRUFHQyxRQUhELEVBSUMsVUFKRCxFQUtDLFFBTEQsRUFNQyx1Q0FORDtBQUZFLE9BblRKO0FBNlRma0UsWUFBTSxFQUFFO0FBQ052RSxZQUFJLEVBQUVDO0FBREEsT0E3VE87QUFnVWZ1RSxZQUFNLEVBQUU7QUFDTnhFLFlBQUksRUFBRUMsTUFEQTtBQUVOSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUFPLElBQVA7QUFGVCxPQWhVTztBQW9VZm9FLFlBQU0sRUFBRTtBQUNOekUsWUFBSSxFQUFFQztBQURBLE9BcFVPO0FBdVVmeUUsWUFBTSxFQUFFO0FBQ04xRSxZQUFJLEVBQUVDLE1BREE7QUFFTkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBTyxJQUFQLEVBQVksUUFBWjtBQUZULE9BdlVPO0FBMlVmNUIsWUFBTSxFQUFFO0FBQ051QixZQUFJLEVBQUVDLE1BREE7QUFFTkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBTyxJQUFQO0FBRlQsT0EzVU87QUErVWZzRSxZQUFNLEVBQUU7QUFDTjNFLFlBQUksRUFBRWhDLEtBREE7QUFFTjJELGdCQUFRLEVBQUU7QUFGSixPQS9VTztBQW1WZixrQkFBWTtBQUNWM0IsWUFBSSxFQUFFQyxNQURJO0FBRVYwQixnQkFBUSxFQUFFLElBRkE7QUFHVnRCLHFCQUFhLEVBQUUsQ0FBQyxXQUFELEVBQ0MsT0FERCxFQUVDLFNBRkQsRUFHQyxPQUhEO0FBSEwsT0FuVkc7QUEyVmZ1RSxZQUFNLEVBQUU7QUFDTjVFLFlBQUksRUFBRUMsTUFEQTtBQUVOMEIsZ0JBQVEsRUFBRSxJQUZKO0FBR050QixxQkFBYSxFQUFFLENBQUMsMERBQUQsRUFDQywrREFERCxFQUVDLDREQUZEO0FBSFQsT0EzVk87QUFrV2Z3RSxZQUFNLEVBQUU7QUFDTjdFLFlBQUksRUFBRUMsTUFEQTtBQUVOMEIsZ0JBQVEsRUFBRTtBQUZKLE9BbFdPO0FBc1dmbUQsWUFBTSxFQUFFO0FBQ045RSxZQUFJLEVBQUVDLE1BREE7QUFFTjBCLGdCQUFRLEVBQUUsSUFGSjtBQUdOdEIscUJBQWEsRUFBRSxDQUFDLG1DQUFELEVBQXFDLDRCQUFyQztBQUhULE9BdFdPO0FBMldmMEUsYUFBTyxFQUFFO0FBQ1AvRSxZQUFJLEVBQUVDLE1BREM7QUFFUEkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBTyxJQUFQO0FBRlIsT0EzV007QUErV2YzQixpQkFBVyxFQUFFO0FBQ1hzQixZQUFJLEVBQUVDLE1BREs7QUFFWEkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBTyxJQUFQO0FBRkosT0EvV0U7QUFtWGYyRSxpQkFBVyxFQUFFO0FBQ1hoRixZQUFJLEVBQUVpQixNQURLO0FBRVhVLGdCQUFRLEVBQUU7QUFGQyxPQW5YRTtBQXVYZnNELGFBQU8sRUFBRTtBQUNQakYsWUFBSSxFQUFFZ0MsT0FEQztBQUVQTCxnQkFBUSxFQUFFLElBRkg7QUFHUHhCLGFBQUssRUFBRTtBQUhBLE9BdlhNO0FBNFhmK0UsZUFBUyxFQUFFO0FBQ1RsRixZQUFJLEVBQUVnQyxPQURHO0FBRVRMLGdCQUFRLEVBQUUsSUFGRDtBQUdUeEIsYUFBSyxFQUFFO0FBSEUsT0E1WEk7QUFpWWZnRixXQUFLLEVBQUM7QUFDSm5GLFlBQUksRUFBRWdDLE9BREY7QUFFSkwsZ0JBQVEsRUFBRSxJQUZOO0FBR0p4QixhQUFLLEVBQUU7QUFISCxPQWpZUztBQXNZZmlGLFVBQUksRUFBRTtBQUNKcEYsWUFBSSxFQUFFZ0MsT0FERjtBQUVKTCxnQkFBUSxFQUFFLElBRk47QUFHSnhCLGFBQUssRUFBRTtBQUhILE9BdFlTO0FBMllma0YsYUFBTyxFQUFFO0FBQ1ByRixZQUFJLEVBQUVnQyxPQURDO0FBRVBMLGdCQUFRLEVBQUUsSUFGSDtBQUdQeEIsYUFBSyxFQUFFO0FBSEEsT0EzWU07QUFnWmZtRixZQUFNLEVBQUU7QUFDTnRGLFlBQUksRUFBRWdDLE9BREE7QUFFTkwsZ0JBQVEsRUFBRSxJQUZKO0FBR054QixhQUFLLEVBQUU7QUFIRCxPQWhaTztBQXFaZm9GLGdCQUFVLEVBQUM7QUFDVHZGLFlBQUksRUFBRWdDLE9BREc7QUFFVEwsZ0JBQVEsRUFBRSxJQUZEO0FBR1R4QixhQUFLLEVBQUU7QUFIRSxPQXJaSTtBQTBaZnFGLGFBQU8sRUFBRTtBQUNQeEYsWUFBSSxFQUFFZ0MsT0FEQztBQUVQTCxnQkFBUSxFQUFFLElBRkg7QUFHUHhCLGFBQUssRUFBRTtBQUhBLE9BMVpNO0FBK1pmc0YsWUFBTSxFQUFFO0FBQ056RixZQUFJLEVBQUVnQyxPQURBO0FBRU5MLGdCQUFRLEVBQUUsSUFGSjtBQUdOeEIsYUFBSyxFQUFFO0FBSEQsT0EvWk87QUFvYWZ1RixVQUFJLEVBQUU7QUFDSjFGLFlBQUksRUFBRWdDLE9BREY7QUFFSkwsZ0JBQVEsRUFBRSxJQUZOO0FBR0p4QixhQUFLLEVBQUU7QUFISCxPQXBhUztBQXlhZndGLGdCQUFVLEVBQUU7QUFDVjNGLFlBQUksRUFBRWdDLE9BREk7QUFFVkwsZ0JBQVEsRUFBRSxJQUZBO0FBR1Z4QixhQUFLLEVBQUU7QUFIRyxPQXphRztBQThhZnhCLGlCQUFXLEVBQUU7QUFDWHFCLFlBQUksRUFBRWdDLE9BREs7QUFFWEwsZ0JBQVEsRUFBRSxJQUZDO0FBR1h4QixhQUFLLEVBQUU7QUFISSxPQTlhRTtBQW1iZnlGLGNBQVEsRUFBRTtBQUNSNUYsWUFBSSxFQUFFQyxNQURFO0FBRVIwQixnQkFBUSxFQUFFO0FBRkYsT0FuYks7QUF1YmZrRSxpQkFBVyxFQUFFO0FBQ1g3RixZQUFJLEVBQUVDLE1BREs7QUFFWEkscUJBQWEsRUFBRSxDQUFDLFFBQUQsRUFBVyxXQUFYO0FBRkosT0F2YkU7QUEyYmZ5RixpQkFBVyxFQUFDO0FBQ1Y5RixZQUFJLEVBQUVDLE1BREk7QUFFVkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFBUSxJQUFSLENBRkw7QUFHVnNCLGdCQUFRLEVBQUU7QUFIQSxPQTNiRztBQWdjZm9FLGlCQUFXLEVBQUU7QUFDWC9GLFlBQUksRUFBRUMsTUFESztBQUVYMEIsZ0JBQVEsRUFBRTtBQUZDLE9BaGNFO0FBb2NmcUUsaUJBQVcsRUFBRTtBQUNYaEcsWUFBSSxFQUFFQyxNQURLO0FBRVhJLHFCQUFhLEVBQUUsQ0FBQyxXQUFELEVBQWMsU0FBZCxFQUF3QixTQUF4QixFQUFrQyxVQUFsQztBQUZKLE9BcGNFO0FBd2NmNEYsaUJBQVcsRUFBRTtBQUNYakcsWUFBSSxFQUFFaUI7QUFESyxPQXhjRTtBQTJjZmlGLGlCQUFXLEVBQUU7QUFDWGxHLFlBQUksRUFBRWlCO0FBREssT0EzY0U7QUE4Y2ZrRixrQkFBWSxFQUFFO0FBQ1puRyxZQUFJLEVBQUVpQjtBQURNLE9BOWNDO0FBaWRmbUYsa0JBQVksRUFBRTtBQUNacEcsWUFBSSxFQUFFaUI7QUFETSxPQWpkQztBQW9kZm9GLGtCQUFZLEVBQUU7QUFDWnJHLFlBQUksRUFBRUMsTUFETTtBQUVaSSxxQkFBYSxFQUFFLENBQUMsMEJBQUQsRUFDQyxzQkFERCxFQUVDLGtCQUZELEVBR0MsZUFIRCxFQUlDLGVBSkQsRUFLQyxlQUxELEVBTUMsNERBTkQsRUFPQyx5QkFQRCxFQVFDLGlEQVJELEVBU0Msa0JBVEQ7QUFGSDtBQXBkQyxLQUFqQixDQTFFYTtBQTZpQmIseUJBQ0EsSUFBSVgsWUFBSixDQUFpQjtBQUNmNEcsb0JBQWMsRUFBRTtBQUNkdEcsWUFBSSxFQUFFQyxNQURRO0FBRWRJLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQ0MsSUFERDtBQUZELE9BREQ7QUFNZmtHLG9CQUFjLEVBQUM7QUFDYnZHLFlBQUksRUFBRUMsTUFETztBQUViSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUNDLElBREQsRUFFQyx3QkFGRDtBQUZGLE9BTkE7QUFZZm1HLG9CQUFjLEVBQUU7QUFDZHhHLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUNDLElBREQ7QUFGRCxPQVpEO0FBaUJmb0csb0JBQWMsRUFBRTtBQUNkekcsWUFBSSxFQUFFQyxNQURRO0FBRWRJLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQ0MsSUFERCxFQUVDLHdCQUZEO0FBRkQsT0FqQkQ7QUF1QmZ4QixvQkFBYyxFQUFFO0FBQ2RtQixZQUFJLEVBQUVoQztBQURRLE9BdkJEO0FBMEJmLDBCQUFvQjtBQUNsQmdDLFlBQUksRUFBRUMsTUFEWTtBQUVsQkkscUJBQWEsRUFBRSxDQUFDLHFCQUFELEVBQ0MsVUFERCxFQUVDLG1CQUZELEVBR0MsNENBSEQsRUFJQyxxQ0FKRCxFQUtDLHdCQUxELEVBTUMsNkNBTkQ7QUFGRyxPQTFCTDtBQW9DZnFHLG9CQUFjLEVBQUU7QUFDZDFHLFlBQUksRUFBRUMsTUFEUTtBQUVkMEIsZ0JBQVEsRUFBRSxJQUZJO0FBR2R0QixxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUNDLElBREQsRUFFQyx3QkFGRDtBQUhELE9BcENEO0FBMkNmdEIsb0JBQWMsRUFBRTtBQUNkaUIsWUFBSSxFQUFFQyxNQURRO0FBRWRJLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQ0MsSUFERDtBQUZELE9BM0NEO0FBZ0RmckIsb0JBQWMsRUFBRTtBQUNkZ0IsWUFBSSxFQUFFQyxNQURRO0FBRWQwQixnQkFBUSxFQUFFLElBRkk7QUFHZHRCLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQ0MsSUFERDtBQUhELE9BaEREO0FBc0Rmc0csb0JBQWMsRUFBRTtBQUNkM0csWUFBSSxFQUFFQyxNQURRO0FBRWQwQixnQkFBUSxFQUFFLElBRkk7QUFHZHRCLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQ0MsSUFERDtBQUhELE9BdEREO0FBNERmdUcscUJBQWUsRUFBRTtBQUNmNUcsWUFBSSxFQUFFQyxNQURTO0FBRWZJLHFCQUFhLEVBQUUsQ0FBQyxLQUFELEVBQ0MsSUFERCxFQUVDLHdCQUZEO0FBRkEsT0E1REY7QUFrRWZ3RyxxQkFBZSxFQUFFO0FBQ2Y3RyxZQUFJLEVBQUVDLE1BRFM7QUFFZkkscUJBQWEsRUFBRSxDQUFDLEtBQUQsRUFDQyxJQURELEVBRUMsdUNBRkQ7QUFGQSxPQWxFRjtBQXdFZnlHLHFCQUFlLEVBQUU7QUFDZjlHLFlBQUksRUFBRUMsTUFEUztBQUVmSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUNDLElBREQ7QUFGQSxPQXhFRjtBQTZFZjBHLHFCQUFlLEVBQUU7QUFDZi9HLFlBQUksRUFBRUMsTUFEUztBQUVmSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUNDLElBREQ7QUFGQSxPQTdFRjtBQWtGZjJHLHFCQUFlLEVBQUU7QUFDZmhILFlBQUksRUFBRUMsTUFEUztBQUVmSSxxQkFBYSxFQUFFLENBQUMsS0FBRCxFQUNDLElBREQsRUFFQyx3QkFGRDtBQUZBO0FBbEZGLEtBQWpCO0FBOWlCYSxHQURVO0FBMG9CekIscUJBQ0EsSUFBSVgsWUFBSixDQUFpQjtBQUNmdUgsVUFBTSxFQUFFO0FBQ05qSCxVQUFJLEVBQUVpQixNQURBO0FBRU5SLFNBQUcsRUFBRSxHQUZDO0FBR055RyxTQUFHLEVBQUUsR0FIQztBQUlOL0csV0FBSyxFQUFFO0FBSkQsS0FETztBQU9mO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBZ0gsVUFBTSxFQUFFO0FBQ05uSCxVQUFJLEVBQUVpQixNQURBO0FBRU5SLFNBQUcsRUFBRSxDQUZDO0FBR055RyxTQUFHLEVBQUUsR0FIQztBQUlOL0csV0FBSyxFQUFFO0FBSkQsS0FiTztBQW1CZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQWlILFNBQUssRUFBRTtBQUNMcEgsVUFBSSxFQUFFaUIsTUFERDtBQUVMZCxXQUFLLEVBQUU7QUFGRixLQXpCUTtBQTZCZmtILE9BQUcsRUFBRTtBQUNIckgsVUFBSSxFQUFFaUIsTUFESDtBQUVIZCxXQUFLLEVBQUU7QUFGSixLQTdCVTtBQWlDZnhELG1CQUFlLEVBQUU7QUFDZnFELFVBQUksRUFBRWdDLE9BRFM7QUFFZjdCLFdBQUssRUFBRTtBQUZRO0FBakNGLEdBQWpCLENBM29CeUI7QUFrckJ6Qix3QkFDQSxJQUFJVCxZQUFKLENBQWlCO0FBQ2Y0SCxPQUFHLEVBQUU7QUFDSHRILFVBQUksRUFBRU4sWUFBWSxDQUFDYyxPQURoQjtBQUVIQyxTQUFHLEVBQUUsRUFGRjtBQUdIeUcsU0FBRyxFQUFFLEdBSEY7QUFJSC9HLFdBQUssRUFBRTtBQUpKLEtBRFU7QUFPZm9ILE1BQUUsRUFBRTtBQUNGdkgsVUFBSSxFQUFFaUIsTUFESjtBQUVGUixTQUFHLEVBQUUsQ0FGSDtBQUdGeUcsU0FBRyxFQUFFLEVBSEg7QUFJRi9HLFdBQUssRUFBRTtBQUpMLEtBUFc7QUFhZnZELCtCQUEyQixFQUFDO0FBQzFCb0QsVUFBSSxFQUFFZ0MsT0FEb0I7QUFFMUI3QixXQUFLLEVBQUU7QUFGbUI7QUFiYixHQUFqQixDQW5yQnlCO0FBc3NCekIsZ0JBQ0EsSUFBSVQsWUFBSixDQUFpQjtBQUNmOEgsbUJBQWUsRUFBRTtBQUNmeEgsVUFBSSxFQUFFZ0MsT0FEUztBQUVmN0IsV0FBSyxFQUFFO0FBRlE7QUFERixHQUFqQixDQXZzQnlCO0FBOHNCekIsZUFDQSxJQUFJVCxZQUFKLENBQWlCO0FBQ2YrSCxnQkFBWSxFQUFFO0FBQ1p6SCxVQUFJLEVBQUVnQyxPQURNO0FBRVo3QixXQUFLLEVBQUU7QUFGSyxLQURDO0FBS2Z1SCxZQUFRLEVBQUM7QUFDUDFILFVBQUksRUFBRUMsTUFEQztBQUVQMEIsY0FBUSxFQUFFLElBRkg7QUFHUHhCLFdBQUssRUFBRTtBQUhBLEtBTE07QUFVZnRELG9CQUFnQixFQUFFO0FBQ2hCbUQsVUFBSSxFQUFFZ0MsT0FEVTtBQUVoQjdCLFdBQUssRUFBRTtBQUZTO0FBVkgsR0FBakIsQ0Evc0J5QjtBQSt0QnpCLGlCQUNBLElBQUlULFlBQUosQ0FBaUI7QUFDZkgsaUJBQWEsRUFBRTtBQUNiUyxVQUFJLEVBQUVnQyxPQURPO0FBRWI3QixXQUFLLEVBQUU7QUFGTSxLQURBO0FBS2Z3SCxjQUFVLEVBQUU7QUFDVjNILFVBQUksRUFBRUMsTUFESTtBQUVWMEIsY0FBUSxFQUFFLElBRkE7QUFHVnhCLFdBQUssRUFBRTtBQUhHLEtBTEc7QUFVZnlILGlCQUFhLEVBQUU7QUFDYjVILFVBQUksRUFBRWdDLE9BRE87QUFFYjdCLFdBQUssRUFBRTtBQUZNLEtBVkE7QUFjZjBILGdCQUFZLEVBQUU7QUFDWjdILFVBQUksRUFBRWdDLE9BRE07QUFFWjdCLFdBQUssRUFBRTtBQUZLO0FBZEMsR0FBakIsQ0FodUJ5QjtBQW92QnpCLG9CQUNBLElBQUlULFlBQUosQ0FBaUI7QUFDZk4sVUFBTSxFQUFFO0FBQ05ZLFVBQUksRUFBRU4sWUFBWSxDQUFDYyxPQURiO0FBRU5DLFNBQUcsRUFBRSxFQUZDO0FBR055RyxTQUFHLEVBQUUsR0FIQztBQUlOL0csV0FBSyxFQUFFO0FBSkQsS0FETztBQU9mYixVQUFNLEVBQUU7QUFDTlUsVUFBSSxFQUFFTixZQUFZLENBQUNjLE9BRGI7QUFFTkMsU0FBRyxFQUFFLEVBRkM7QUFHTnlHLFNBQUcsRUFBRSxHQUhDO0FBSU4vRyxXQUFLLEVBQUU7QUFKRCxLQVBPO0FBYWZoQixVQUFNLEVBQUU7QUFDTmEsVUFBSSxFQUFFTixZQUFZLENBQUNjLE9BRGI7QUFFTkMsU0FBRyxFQUFFLEVBRkM7QUFHTnlHLFNBQUcsRUFBRSxHQUhDO0FBSU4vRyxXQUFLLEVBQUU7QUFKRCxLQWJPO0FBbUJmZCxVQUFNLEVBQUU7QUFDTlcsVUFBSSxFQUFFTixZQUFZLENBQUNjLE9BRGI7QUFFTkMsU0FBRyxFQUFFLEVBRkM7QUFHTnlHLFNBQUcsRUFBRSxHQUhDO0FBSU4vRyxXQUFLLEVBQUU7QUFKRCxLQW5CTztBQXlCZjJILFVBQU0sRUFBRTtBQUNOOUgsVUFBSSxFQUFFTixZQUFZLENBQUNjLE9BRGI7QUFFTm1CLGNBQVEsRUFBRSxJQUZKO0FBR05sQixTQUFHLEVBQUUsRUFIQztBQUlOeUcsU0FBRyxFQUFFLEdBSkM7QUFLTi9HLFdBQUssRUFBRTtBQUxELEtBekJPO0FBZ0NmNEgsVUFBTSxFQUFFO0FBQ04vSCxVQUFJLEVBQUVOLFlBQVksQ0FBQ2MsT0FEYjtBQUVObUIsY0FBUSxFQUFFLElBRko7QUFHTmxCLFNBQUcsRUFBRSxFQUhDO0FBSU55RyxTQUFHLEVBQUUsR0FKQztBQUtOL0csV0FBSyxFQUFFO0FBTEQsS0FoQ087QUF1Q2ZyRCxtQkFBZSxFQUFFO0FBQ2ZrRCxVQUFJLEVBQUVnQyxPQURTO0FBRWY3QixXQUFLLEVBQUU7QUFGUTtBQXZDRixHQUFqQixDQXJ2QnlCO0FBa3lCekIsc0JBQ0EsSUFBSVQsWUFBSixDQUFpQjtBQUNmRixlQUFXLEVBQUU7QUFDWFEsVUFBSSxFQUFFaEM7QUFESyxLQURFO0FBSWYscUJBQWlCO0FBQ2ZnQyxVQUFJLEVBQUVDLE1BRFM7QUFFZkksbUJBQWEsRUFBRSxDQUFDLG9CQUFELEVBQ0MsWUFERCxFQUVDLFVBRkQsRUFHQyxxQkFIRCxFQUlDLGVBSkQsRUFLQyx5QkFMRCxFQU1DLHNCQU5ELEVBT0Msc0JBUEQsRUFRQyxRQVJELEVBU0MsbUJBVEQsRUFVQyxzQkFWRCxFQVdDLGlCQVhELEVBWUMsZ0JBWkQsRUFhQyxnREFiRCxFQWNDLG9CQWREO0FBRkEsS0FKRjtBQXNCZjJILG1CQUFlLEVBQUU7QUFDZmhJLFVBQUksRUFBRUMsTUFEUztBQUVmMEIsY0FBUSxFQUFFO0FBRkssS0F0QkY7QUEwQmZzRyxlQUFXLEVBQUU7QUFDWGpJLFVBQUksRUFBRUM7QUFESyxLQTFCRTtBQTZCZlIsZUFBVyxFQUFFO0FBQ1hPLFVBQUksRUFBRWdDLE9BREs7QUFFWDdCLFdBQUssRUFBRTtBQUZJLEtBN0JFO0FBaUNmK0gsZUFBVyxFQUFFO0FBQ1hsSSxVQUFJLEVBQUVDLE1BREs7QUFFWDBCLGNBQVEsRUFBRTtBQUZDLEtBakNFO0FBcUNmd0csZUFBVyxFQUFFO0FBQ1huSSxVQUFJLEVBQUVDO0FBREs7QUFyQ0UsR0FBakIsQ0FueUJ5QjtBQTYwQnpCLG1CQUNBLElBQUlQLFlBQUosQ0FBa0I7QUFDaEIwSSxTQUFLLEVBQUU7QUFDTHBJLFVBQUksRUFBRWdDLE9BREQ7QUFFTDdCLFdBQUssRUFBRTtBQUZGLEtBRFM7QUFLaEJrSSxnQkFBWSxFQUFFO0FBQ1pySSxVQUFJLEVBQUVDLE1BRE07QUFFWkUsV0FBSyxFQUFFO0FBRkssS0FMRTtBQVNoQm1JLGVBQVcsRUFBRTtBQUNYdEksVUFBSSxFQUFFQyxNQURLO0FBRVhFLFdBQUssRUFBRTtBQUZJLEtBVEc7QUFhaEJvSSxnQkFBWSxFQUFFO0FBQ1p2SSxVQUFJLEVBQUVDLE1BRE07QUFFWkUsV0FBSyxFQUFFO0FBRkssS0FiRTtBQWlCaEJxSSxlQUFXLEVBQUU7QUFDWHhJLFVBQUksRUFBRUMsTUFESztBQUVYRSxXQUFLLEVBQUU7QUFGSSxLQWpCRztBQXFCaEJzSSxnQkFBWSxFQUFFO0FBQ1p6SSxVQUFJLEVBQUVDLE1BRE07QUFFWkUsV0FBSyxFQUFFO0FBRkssS0FyQkU7QUF5QmhCdUksZUFBVyxFQUFFO0FBQ1gxSSxVQUFJLEVBQUVDLE1BREs7QUFFWEUsV0FBSyxFQUFFO0FBRkksS0F6Qkc7QUE2QmhCd0ksUUFBSSxFQUFFO0FBQ0ozSSxVQUFJLEVBQUVDLE1BREY7QUFFSkUsV0FBSyxFQUFFO0FBRkgsS0E3QlU7QUFpQ2hCeUksZUFBVyxFQUFFO0FBQ1g1SSxVQUFJLEVBQUVDLE1BREs7QUFFWEUsV0FBSyxFQUFFO0FBRkksS0FqQ0c7QUFxQ2hCMEksVUFBTSxFQUFFO0FBQ043SSxVQUFJLEVBQUVDLE1BREE7QUFFTkUsV0FBSyxFQUFFO0FBRkQsS0FyQ1E7QUF5Q2hCMkksVUFBTSxFQUFFO0FBQ045SSxVQUFJLEVBQUVDLE1BREE7QUFFTkUsV0FBSyxFQUFFO0FBRkQsS0F6Q1E7QUE2Q2hCNEksUUFBSSxFQUFFO0FBQ0ovSSxVQUFJLEVBQUVDLE1BREY7QUFFSkUsV0FBSyxFQUFFO0FBRkgsS0E3Q1U7QUFpRGhCNkksU0FBSyxFQUFFO0FBQ0xoSixVQUFJLEVBQUVDLE1BREQ7QUFFTEUsV0FBSyxFQUFFO0FBRkYsS0FqRFM7QUFxRGhCOEksUUFBSSxFQUFFO0FBQ0pqSixVQUFJLEVBQUVDLE1BREY7QUFFSkUsV0FBSyxFQUFFO0FBRkgsS0FyRFU7QUF5RGhCK0ksV0FBTyxFQUFFO0FBQ1BsSixVQUFJLEVBQUVDLE1BREM7QUFFUEUsV0FBSyxFQUFFO0FBRkEsS0F6RE87QUE2RGhCZ0osT0FBRyxFQUFFO0FBQ0huSixVQUFJLEVBQUVDLE1BREg7QUFFSEUsV0FBSyxFQUFFO0FBRkosS0E3RFc7QUFpRWhCaUosUUFBSSxFQUFFO0FBQ0pwSixVQUFJLEVBQUVDLE1BREY7QUFFSkUsV0FBSyxFQUFFO0FBRkgsS0FqRVU7QUFxRWhCa0osT0FBRyxFQUFFO0FBQ0hySixVQUFJLEVBQUVDLE1BREg7QUFFSEUsV0FBSyxFQUFFO0FBRkosS0FyRVc7QUF5RWhCbUosVUFBTSxFQUFFO0FBQ050SixVQUFJLEVBQUVDLE1BREE7QUFFTkUsV0FBSyxFQUFFO0FBRkQsS0F6RVE7QUE2RWhCb0osVUFBTSxFQUFFO0FBQ052SixVQUFJLEVBQUVDLE1BREE7QUFFTkUsV0FBSyxFQUFFO0FBRkQsS0E3RVE7QUFpRmhCcUosYUFBUyxFQUFFO0FBQ1R4SixVQUFJLEVBQUVDLE1BREc7QUFFVEUsV0FBSyxFQUFFO0FBRkUsS0FqRks7QUFxRmhCc0osVUFBTSxFQUFFO0FBQ056SixVQUFJLEVBQUVDLE1BREE7QUFFTkUsV0FBSyxFQUFFO0FBRkQsS0FyRlE7QUF5RmhCdUosV0FBTyxFQUFFO0FBQ1AxSixVQUFJLEVBQUVDLE1BREM7QUFFUEUsV0FBSyxFQUFFO0FBRkE7QUF6Rk8sR0FBbEIsQ0E5MEJ5QjtBQTY2QnpCLGlCQUFjO0FBQ1osa0NBQ0EsSUFBSVQsWUFBSixDQUFrQjtBQUNoQmlLLHFCQUFlLEVBQUU7QUFDZjNKLFlBQUksRUFBRWdDLE9BRFM7QUFFZjdCLGFBQUssRUFBRTtBQUZRLE9BREQ7QUFLaEJ5Six3QkFBa0IsRUFBRTtBQUNwQjVKLFlBQUksRUFBRUMsTUFEYztBQUVwQkkscUJBQWEsRUFBRSxDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxFQUFnQixHQUFoQixFQUFxQixHQUFyQjtBQUZLLE9BTEo7QUFTZHdKLG1CQUFhLEVBQUU7QUFDYjdKLFlBQUksRUFBRUMsTUFETztBQUViSSxxQkFBYSxFQUFFLENBQUMsa0JBQUQsRUFBb0IsTUFBcEIsRUFBMkIsVUFBM0IsRUFBc0Msa0JBQXRDO0FBRkYsT0FURDtBQWFkeUosbUJBQWEsRUFBRTtBQUNiOUosWUFBSSxFQUFFQyxNQURPO0FBRWJJLHFCQUFhLEVBQUUsQ0FBQyxRQUFELEVBQVcsV0FBWCxFQUF3QixhQUF4QixFQUF1QyxXQUF2QztBQUZGLE9BYkQ7QUFpQlowSixtQkFBYSxFQUFFO0FBQ2YvSixZQUFJLEVBQUVDLE1BRFM7QUFFZkkscUJBQWEsRUFBRSxDQUFDLHVCQUFELEVBQTBCLGdEQUExQixFQUE0RSx3REFBNUUsRUFBc0ksNkNBQXRJO0FBRkEsT0FqQkg7QUFxQmQySixtQkFBYSxFQUFFO0FBQ2JoSyxZQUFJLEVBQUVDLE1BRE87QUFFYkkscUJBQWEsRUFBRSxDQUFDLG1CQUFELEVBQXNCLGlDQUF0QixFQUF5RCwrQkFBekQsRUFBMEYsK0JBQTFGO0FBRkYsT0FyQkQ7QUF5QmQ0SixtQkFBYSxFQUFFO0FBQ2JqSyxZQUFJLEVBQUVDLE1BRE87QUFFYkkscUJBQWEsRUFBRSxDQUFDLGFBQUQsRUFBZ0IsY0FBaEIsRUFBZ0MsYUFBaEMsRUFBK0MsaUJBQS9DO0FBRkYsT0F6QkQ7QUE2QmQ2SixtQkFBYSxFQUFFO0FBQ2JsSyxZQUFJLEVBQUVDLE1BRE87QUFFYkkscUJBQWEsRUFBRSxDQUFDLHdEQUFELEVBQTJELCtCQUEzRCxFQUE0RixrQ0FBNUYsRUFBZ0ksb0NBQWhJLEVBQXFLLGtCQUFySztBQUZGO0FBN0JELEtBQWxCLENBRlk7QUFxQ1osbUNBQ0EsSUFBSVgsWUFBSixDQUFrQjtBQUNoQnlLLHlCQUFtQixFQUFFO0FBQ3JCbkssWUFBSSxFQUFFQyxNQURlO0FBRXJCSSxxQkFBYSxFQUFFLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLEdBQWhCLEVBQXFCLEdBQXJCO0FBRk0sT0FETDtBQUtoQitKLG9CQUFjLEVBQUU7QUFDZHBLLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsa0JBQUQsRUFBb0IsTUFBcEIsRUFBMkIsVUFBM0IsRUFBc0Msa0JBQXRDO0FBRkQsT0FMQTtBQVNoQmdLLG9CQUFjLEVBQUU7QUFDZHJLLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsUUFBRCxFQUFXLFdBQVgsRUFBd0IsYUFBeEIsRUFBdUMsV0FBdkM7QUFGRCxPQVRBO0FBYWhCaUssb0JBQWMsRUFBRTtBQUNkdEssWUFBSSxFQUFFQyxNQURRO0FBRWRJLHFCQUFhLEVBQUUsQ0FBQyx1QkFBRCxFQUEwQixnREFBMUIsRUFBNEUsd0RBQTVFLEVBQXNJLDZDQUF0STtBQUZELE9BYkE7QUFpQmhCa0ssb0JBQWMsRUFBRTtBQUNkdkssWUFBSSxFQUFFQyxNQURRO0FBRWRJLHFCQUFhLEVBQUUsQ0FBQyxtQkFBRCxFQUFzQixpQ0FBdEIsRUFBeUQsK0JBQXpELEVBQTBGLCtCQUExRjtBQUZELE9BakJBO0FBcUJoQm1LLG9CQUFjLEVBQUU7QUFDZHhLLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsYUFBRCxFQUFnQixjQUFoQixFQUFnQyxhQUFoQyxFQUErQyxpQkFBL0M7QUFGRCxPQXJCQTtBQXlCaEJvSyxvQkFBYyxFQUFFO0FBQ2R6SyxZQUFJLEVBQUVDLE1BRFE7QUFFZEkscUJBQWEsRUFBRSxDQUFDLHdEQUFELEVBQTJELCtCQUEzRCxFQUE0RixrQ0FBNUYsRUFBZ0ksb0NBQWhJLEVBQXFLLGtCQUFySztBQUZEO0FBekJBLEtBQWxCO0FBdENZLEdBNzZCVztBQW0vQnpCLGVBQVk7QUFDViw0QkFDQSxJQUFJWCxZQUFKLENBQWtCO0FBQ2hCZ0wsbUJBQWEsRUFBRTtBQUNmMUssWUFBSSxFQUFFQyxNQURTO0FBRWZJLHFCQUFhLEVBQUUsQ0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLEdBQVgsRUFBZ0IsR0FBaEIsRUFBcUIsR0FBckI7QUFGQSxPQURDO0FBS2hCc0ssbUJBQWEsRUFBRTtBQUNiM0ssWUFBSSxFQUFFQyxNQURPO0FBRWJJLHFCQUFhLEVBQUUsQ0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLEdBQVgsRUFBZ0IsR0FBaEIsRUFBcUIsR0FBckI7QUFGRixPQUxDO0FBU2hCdUssbUJBQWEsRUFBRTtBQUNiNUssWUFBSSxFQUFFQyxNQURPO0FBRWJJLHFCQUFhLEVBQUUsQ0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLEdBQVgsRUFBZ0IsR0FBaEIsRUFBcUIsR0FBckI7QUFGRixPQVRDO0FBYWhCd0ssbUJBQWEsRUFBRTtBQUNiN0ssWUFBSSxFQUFFQyxNQURPO0FBRWJJLHFCQUFhLEVBQUUsQ0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLEdBQVgsRUFBZ0IsR0FBaEIsRUFBcUIsR0FBckI7QUFGRjtBQWJDLEtBQWxCLENBRlU7QUFxQlYsMEJBQ0EsSUFBSVgsWUFBSixDQUFrQjtBQUNoQm9MLGlCQUFXLEVBQUU7QUFDYjlLLFlBQUksRUFBRUMsTUFETztBQUViSSxxQkFBYSxFQUFFLENBQUMsaUJBQUQsRUFBb0IsZUFBcEIsRUFBcUMsT0FBckMsRUFBOEMsa0JBQTlDO0FBRkYsT0FERztBQUtoQjBLLGlCQUFXLEVBQUU7QUFDWC9LLFlBQUksRUFBRUMsTUFESztBQUVYSSxxQkFBYSxFQUFFLENBQUMsaUJBQUQsRUFBb0IsZUFBcEIsRUFBcUMsT0FBckMsRUFBOEMsa0JBQTlDO0FBRkosT0FMRztBQVNkMkssaUJBQVcsRUFBRTtBQUNiaEwsWUFBSSxFQUFFQyxNQURPO0FBRWJJLHFCQUFhLEVBQUUsQ0FBQyxTQUFELEVBQVksU0FBWixFQUF1QixVQUF2QixFQUFtQyxVQUFuQztBQUZGLE9BVEM7QUFhaEI0SyxpQkFBVyxFQUFFO0FBQ1hqTCxZQUFJLEVBQUVDLE1BREs7QUFFWEkscUJBQWEsRUFBRSxDQUFDLGtEQUFELEVBQXFELG1EQUFyRCxFQUEwRyx1Q0FBMUcsRUFBbUosa0RBQW5KO0FBRkosT0FiRztBQWlCaEI2SyxpQkFBVyxFQUFFO0FBQ1hsTCxZQUFJLEVBQUVDLE1BREs7QUFFWEkscUJBQWEsRUFBRSxDQUFDLE1BQUQsRUFBUyxlQUFULEVBQTBCLGdCQUExQixFQUE0QyxlQUE1QztBQUZKLE9BakJHO0FBcUJoQjhLLGlCQUFXLEVBQUU7QUFDWG5MLFlBQUksRUFBRUMsTUFESztBQUVYSSxxQkFBYSxFQUFFLENBQUMsU0FBRCxFQUFZLFNBQVosRUFBdUIsWUFBdkIsRUFBcUMsa0JBQXJDO0FBRkosT0FyQkc7QUF5QmhCK0ssaUJBQVcsRUFBRTtBQUNYcEwsWUFBSSxFQUFFQyxNQURLO0FBRVhJLHFCQUFhLEVBQUUsQ0FBQyx1Q0FBRCxFQUEwQyx5Q0FBMUMsRUFBcUYsc0NBQXJGLEVBQTZILHFFQUE3SDtBQUZKO0FBekJHLEtBQWxCLENBdEJVO0FBcURWLDZCQUNBLElBQUlYLFlBQUosQ0FBa0I7QUFDaEIyTCxvQkFBYyxFQUFFO0FBQ2hCckwsWUFBSSxFQUFFQyxNQURVO0FBRWhCSSxxQkFBYSxFQUFFLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLEdBQWhCLEVBQXFCLEdBQXJCO0FBRkMsT0FEQTtBQUtoQmlMLG9CQUFjLEVBQUU7QUFDZHRMLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLEdBQWhCLEVBQXFCLEdBQXJCO0FBRkQsT0FMQTtBQVNoQmtMLG9CQUFjLEVBQUU7QUFDZHZMLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLEdBQWhCLEVBQXFCLEdBQXJCO0FBRkQsT0FUQTtBQWFoQm1MLG9CQUFjLEVBQUU7QUFDZHhMLFlBQUksRUFBRUMsTUFEUTtBQUVkSSxxQkFBYSxFQUFFLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLEdBQWhCLEVBQXFCLEdBQXJCO0FBRkQ7QUFiQSxLQUFsQixDQXREVTtBQXlFViwyQkFDQSxJQUFJWCxZQUFKLENBQWtCO0FBQ2hCK0wsa0JBQVksRUFBRTtBQUNkekwsWUFBSSxFQUFFQyxNQURRO0FBRWRJLHFCQUFhLEVBQUUsQ0FBQyxpQkFBRCxFQUFvQixlQUFwQixFQUFxQyxPQUFyQyxFQUE4QyxrQkFBOUM7QUFGRCxPQURFO0FBS2hCcUwsa0JBQVksRUFBRTtBQUNaMUwsWUFBSSxFQUFFQyxNQURNO0FBRVpJLHFCQUFhLEVBQUUsQ0FBQyxpQkFBRCxFQUFvQixlQUFwQixFQUFxQyxPQUFyQyxFQUE4QyxrQkFBOUM7QUFGSCxPQUxFO0FBU2hCc0wsa0JBQVksRUFBRTtBQUNaM0wsWUFBSSxFQUFFQyxNQURNO0FBRVpJLHFCQUFhLEVBQUUsQ0FBQyxTQUFELEVBQVksU0FBWixFQUF1QixVQUF2QixFQUFtQyxVQUFuQztBQUZILE9BVEU7QUFhaEJ1TCxrQkFBWSxFQUFFO0FBQ1o1TCxZQUFJLEVBQUVDLE1BRE07QUFFWkkscUJBQWEsRUFBRSxDQUFDLGtEQUFELEVBQXFELG1EQUFyRCxFQUEwRyx1Q0FBMUcsRUFBbUosa0RBQW5KO0FBRkgsT0FiRTtBQWlCaEJ3TCxrQkFBWSxFQUFFO0FBQ1o3TCxZQUFJLEVBQUVDLE1BRE07QUFFWkkscUJBQWEsRUFBRSxDQUFDLE1BQUQsRUFBUyxlQUFULEVBQTBCLGdCQUExQixFQUE0QyxlQUE1QztBQUZILE9BakJFO0FBcUJoQnlMLGtCQUFZLEVBQUU7QUFDWjlMLFlBQUksRUFBRUMsTUFETTtBQUVaSSxxQkFBYSxFQUFFLENBQUMsU0FBRCxFQUFZLFNBQVosRUFBdUIsWUFBdkIsRUFBcUMsa0JBQXJDO0FBRkgsT0FyQkU7QUF5QmhCMEwsa0JBQVksRUFBRTtBQUNaL0wsWUFBSSxFQUFFQyxNQURNO0FBRVpJLHFCQUFhLEVBQUUsQ0FBQyx1Q0FBRCxFQUEwQyx5Q0FBMUMsRUFBcUYsc0NBQXJGLEVBQTZILHFFQUE3SDtBQUZIO0FBekJFLEtBQWxCO0FBMUVVLEdBbi9CYTtBQTZsQ3pCLDZCQUNBLElBQUlYLFlBQUosQ0FBa0I7QUFDaEJzTSwwQkFBc0IsRUFBRTtBQUN4QmhNLFVBQUksRUFBRUMsTUFEa0I7QUFFeEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGUyxLQURSO0FBS2hCNEwsMEJBQXNCLEVBQUU7QUFDdEJqTSxVQUFJLEVBQUVoQztBQURnQixLQUxSO0FBUWhCLGdDQUE0QjtBQUMxQmdDLFVBQUksRUFBRUMsTUFEb0I7QUFFMUJJLG1CQUFhLEVBQUUsQ0FBQyxnQ0FBRCxFQUNDLG1DQURELEVBRUMsZ0NBRkQsRUFHQyxrQ0FIRCxFQUlDLDRCQUpELEVBS0MsMEJBTEQsRUFNQyw2QkFORCxFQU9DLDRCQVBEO0FBRlcsS0FSWjtBQW1CaEI2TCwwQkFBc0IsRUFBRTtBQUN0QmxNLFVBQUksRUFBRUMsTUFEZ0I7QUFFdEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGTyxLQW5CUjtBQXVCaEI4TCwwQkFBc0IsRUFBRTtBQUN0Qm5NLFVBQUksRUFBRUMsTUFEZ0I7QUFFdEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGTyxLQXZCUjtBQTJCaEIrTCwwQkFBc0IsRUFBRTtBQUN0QnBNLFVBQUksRUFBRUMsTUFEZ0I7QUFFdEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGTyxLQTNCUjtBQStCaEJnTSwwQkFBc0IsRUFBRTtBQUN0QnJNLFVBQUksRUFBRUMsTUFEZ0I7QUFFdEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGTyxLQS9CUjtBQW1DaEJpTSwwQkFBc0IsRUFBRTtBQUN0QnRNLFVBQUksRUFBRUMsTUFEZ0I7QUFFdEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGTyxLQW5DUjtBQXVDaEJrTSwwQkFBc0IsRUFBRTtBQUN0QnZNLFVBQUksRUFBRUMsTUFEZ0I7QUFFdEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGTyxLQXZDUjtBQTJDaEJtTSwwQkFBc0IsRUFBRTtBQUN0QnhNLFVBQUksRUFBRUMsTUFEZ0I7QUFFdEJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGTyxLQTNDUjtBQStDaEJvTSwyQkFBdUIsRUFBRTtBQUN2QnpNLFVBQUksRUFBRUMsTUFEaUI7QUFFdkJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGUSxLQS9DVDtBQW1EaEJxTSwyQkFBdUIsRUFBRTtBQUN2QjFNLFVBQUksRUFBRUMsTUFEaUI7QUFFdkJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGUSxLQW5EVDtBQXVEaEJzTSwyQkFBdUIsRUFBRTtBQUN2QjNNLFVBQUksRUFBRUMsTUFEaUI7QUFFdkJJLG1CQUFhLEVBQUUsQ0FBQyxnQkFBRCxFQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxtQkFBeEM7QUFGUSxLQXZEVDtBQTJEaEJ1TSwyQkFBdUIsRUFBRTtBQUN2QjVNLFVBQUksRUFBRWhDO0FBRGlCLEtBM0RUO0FBOERoQixpQ0FBNkI7QUFDM0JnQyxVQUFJLEVBQUVDLE1BRHFCO0FBRTNCSSxtQkFBYSxFQUFFLENBQUMscUJBQUQsRUFDQyxTQURELEVBRUMsV0FGRCxFQUdDLHdCQUhELEVBSUMseUNBSkQ7QUFGWSxLQTlEYjtBQXNFaEJ3TSwyQkFBdUIsRUFBRTtBQUN2QjdNLFVBQUksRUFBRUMsTUFEaUI7QUFFdkJJLG1CQUFhLEVBQUUsQ0FBQyxPQUFELEVBQ0MsdUJBREQsRUFFQyxpQkFGRCxFQUdDLGlCQUhELEVBSUMsYUFKRCxFQUtDLHVCQUxEO0FBRlE7QUF0RVQsR0FBbEI7QUE5bEN5QixDQUFwQixDOzs7Ozs7Ozs7OztBQ2RQLElBQUl5TSxLQUFKO0FBQVV2UyxNQUFNLENBQUNNLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNpUyxPQUFLLENBQUMvUixDQUFELEVBQUc7QUFBQytSLFNBQUssR0FBQy9SLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBVlIsTUFBTSxDQUFDd1MsYUFBUCxDQUVlQyxLQUFLLEdBQUcsSUFBSUYsS0FBSyxDQUFDRyxVQUFWLENBQXFCLE9BQXJCLENBRnZCLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSUMsTUFBSjtBQUFXM1MsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDcVMsUUFBTSxDQUFDblMsQ0FBRCxFQUFHO0FBQUNtUyxVQUFNLEdBQUNuUyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrUixLQUFKO0FBQVV2UyxNQUFNLENBQUNNLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNpUyxPQUFLLENBQUMvUixDQUFELEVBQUc7QUFBQytSLFNBQUssR0FBQy9SLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSW9TLEtBQUo7QUFBVTVTLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NTLE9BQUssQ0FBQ3BTLENBQUQsRUFBRztBQUFDb1MsU0FBSyxHQUFDcFMsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJMkUsWUFBSjtBQUFpQm5GLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQzJFLGdCQUFZLEdBQUMzRSxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUlHLFdBQUo7QUFBZ0JYLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNLLGFBQVcsQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUE5QixDQUF2QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJTixXQUFKO0FBQWdCRixNQUFNLENBQUNNLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDSixhQUFXLENBQUNNLENBQUQsRUFBRztBQUFDTixlQUFXLEdBQUNNLENBQVo7QUFBYzs7QUFBOUIsQ0FBdkMsRUFBdUUsQ0FBdkU7QUFBOVdSLE1BQU0sQ0FBQ3dTLGFBQVAsQ0FRZXBOLFdBQVcsR0FBRyxJQUFJbU4sS0FBSyxDQUFDRyxVQUFWLENBQXFCLGFBQXJCLENBUjdCO0FBVUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQyxNQUFNLENBQUNFLE9BQVAsQ0FBZTtBQUNiLHVCQUFxQkMsSUFBckIsRUFBMkI7QUFDekI7QUFDQTtBQUNBLFVBQU1DLE1BQU0sR0FBSUQsSUFBSSxDQUFDLGNBQUQsQ0FBSixDQUFxQmpOLE1BQXJCLEtBQWdDLE1BQWhEO0FBQ0EsVUFBTW1OLE9BQU8sR0FBSUYsSUFBSSxDQUFDLGNBQUQsQ0FBSixDQUFxQjlNLEdBQXJCLElBQTRCLEVBQTdDLENBSnlCLENBTXpCOztBQUNBLFFBQUlpTixnQkFBZ0IsR0FBRyxDQUFDLGNBQUQsQ0FBdkI7O0FBQ0EsUUFBSUYsTUFBSixFQUFZO0FBQ1ZFLHNCQUFnQixDQUFDQyxJQUFqQixDQUFzQixXQUF0QixFQUFtQyxhQUFuQyxFQUFrRCxhQUFsRDtBQUNEOztBQUNELFFBQUlGLE9BQUosRUFBYTtBQUNYQyxzQkFBZ0IsQ0FBQ0MsSUFBakIsQ0FBc0IsZ0JBQXRCLEVBQXdDLFlBQXhDLEVBQXNELFdBQXRELEVBQW1FLGFBQW5FO0FBQ0QsS0Fid0IsQ0FjekI7OztBQUNBQyxXQUFPLENBQUNDLEdBQVIsQ0FBWU4sSUFBSSxDQUFDLG1CQUFELENBQWhCOztBQUNBLFNBQUssSUFBSU8sT0FBVCxJQUFvQlAsSUFBSSxDQUFDLG1CQUFELENBQXhCLEVBQStDO0FBQzdDLFVBQUlBLElBQUksQ0FBQyxtQkFBRCxDQUFKLENBQTBCTyxPQUExQixNQUF1QyxJQUEzQyxFQUFpRDtBQUMvQ0osd0JBQWdCLENBQUNDLElBQWpCLENBQXNCRyxPQUF0QjtBQUNEO0FBQ0YsS0FwQndCLENBc0J6QjtBQUNBOzs7QUFDQVAsUUFBSSxDQUFDUSxZQUFMLEdBQW9CQyxNQUFNLENBQUNDLElBQVAsQ0FBWXRULFdBQVosRUFBeUJ1VCxNQUF6QixDQUFnQ0MsQ0FBQyxJQUFJLENBQUNULGdCQUFnQixDQUFDclAsUUFBakIsQ0FBMEI4UCxDQUExQixDQUF0QyxDQUFwQjtBQUVBWixRQUFJLENBQUNhLFdBQUwsR0FBbUJiLElBQUksQ0FBQ1EsWUFBTCxDQUFrQixDQUFsQixDQUFuQjtBQUVBUixRQUFJLENBQUNjLElBQUwsR0FBWSxLQUFaLENBNUJ5QixDQThCekI7O0FBQ0FkLFFBQUksQ0FBQ2UsRUFBTCxHQUFVek8sV0FBVyxDQUFDME8sSUFBWixDQUFpQixFQUFqQixFQUFxQkMsS0FBckIsS0FBK0IsQ0FBekM7QUFFQTNPLGVBQVcsQ0FBQzRPLE1BQVosQ0FBbUJsQixJQUFuQjtBQUNELEdBbkNZOztBQW9DYix1QkFBcUJBLElBQXJCLEVBQTJCO0FBQ3pCLFVBQU1lLEVBQUUsR0FBR2YsSUFBSSxDQUFDZSxFQUFoQjtBQUNBLFdBQU9mLElBQUksQ0FBQ2UsRUFBWjtBQUNBLFdBQU9mLElBQUksQ0FBQ2EsV0FBWixDQUh5QixDQUt6Qjs7QUFDQSxRQUFJTCxZQUFZLEdBQUdsTyxXQUFXLENBQUMwTyxJQUFaLENBQWlCO0FBQUNELFFBQUUsRUFBQ0E7QUFBSixLQUFqQixFQUEwQkksS0FBMUIsR0FBa0MsQ0FBbEMsRUFBcUNYLFlBQXhELENBTnlCLENBUXpCOztBQUNBQSxnQkFBWSxDQUFDWSxLQUFiO0FBQ0EsVUFBTVAsV0FBVyxHQUFJLE9BQU9MLFlBQVksQ0FBQyxDQUFELENBQW5CLEtBQTRCLFdBQTdCLEdBQTRDQSxZQUFZLENBQUMsQ0FBRCxDQUF4RCxHQUE4RCxNQUFsRjtBQUVBbE8sZUFBVyxDQUFDK08sTUFBWixDQUFtQjtBQUFDTixRQUFFLEVBQUNBO0FBQUosS0FBbkIsRUFBMkI7QUFBQ08sVUFBSSxFQUFDO0FBQUNULG1CQUFXLEVBQUNBLFdBQWI7QUFBeUJDLFlBQUksRUFBQyxLQUE5QjtBQUFvQ04sb0JBQVksRUFBQ0E7QUFBakQsT0FBTjtBQUFzRWUsV0FBSyxFQUFDdkI7QUFBNUUsS0FBM0IsRUFaeUIsQ0FjekI7QUFDRCxHQW5EWTs7QUFvRGIsd0JBQXNCZSxFQUF0QixFQUEwQnZOLEtBQTFCLEVBQWlDO0FBQy9CLFVBQU1nTyxhQUFhLEdBQUlsUCxXQUFXLENBQUNtUCxPQUFaLENBQW9CO0FBQUNWLFFBQUUsRUFBQ0E7QUFBSixLQUFwQixNQUFpQyxXQUFsQyxHQUFpRHpPLFdBQVcsQ0FBQ21QLE9BQVosQ0FBb0I7QUFBQ1YsUUFBRSxFQUFDQTtBQUFKLEtBQXBCLEVBQTZCRCxJQUE5RSxHQUFxRixLQUEzRzs7QUFFQSxRQUFJVSxhQUFhLEtBQUtoTyxLQUF0QixFQUE2QjtBQUUzQjZNLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFaO0FBQ0EsYUFBTyxLQUFQO0FBRUQsS0FMRCxNQUtPO0FBRUxoTyxpQkFBVyxDQUFDK08sTUFBWixDQUFtQjtBQUFDTixVQUFFLEVBQUNBO0FBQUosT0FBbkIsRUFBMkI7QUFBQ08sWUFBSSxFQUFDO0FBQUNSLGNBQUksRUFBQ3ROO0FBQU47QUFBTixPQUEzQjs7QUFFQSxVQUFJcU0sTUFBTSxDQUFDNkIsUUFBUCxJQUFtQmxPLEtBQUssS0FBSyxJQUFqQyxFQUF1QztBQUNyQyxhQUFLbU8sVUFBTCxDQUFnQkMsT0FBaEIsQ0FBeUIsTUFBTTtBQUM3QnRQLHFCQUFXLENBQUMrTyxNQUFaLENBQW1CO0FBQUNOLGNBQUUsRUFBQ0E7QUFBSixXQUFuQixFQUEyQjtBQUFDTyxnQkFBSSxFQUFDO0FBQUNSLGtCQUFJLEVBQUM7QUFBTjtBQUFOLFdBQTNCO0FBQ0QsU0FGRDtBQUdEOztBQUVELGFBQU8sSUFBUDtBQUNEO0FBRUYsR0F6RVk7O0FBMEViLDRCQUEwQkMsRUFBMUIsRUFBOEJjLGNBQTlCLEVBQThDQyxhQUE5QyxFQUE2RDtBQUMzRDtBQUNBLFVBQU10QixZQUFZLEdBQUdsTyxXQUFXLENBQUMwTyxJQUFaLENBQWlCO0FBQUNELFFBQUUsRUFBQ0E7QUFBSixLQUFqQixFQUEwQkksS0FBMUIsR0FBa0MsQ0FBbEMsRUFBcUNYLFlBQTFELENBRjJELENBSTNEOztBQUNBLFVBQU11QixRQUFRLEdBQUd2QixZQUFZLENBQUNHLE1BQWIsQ0FBb0JxQixLQUFLLElBQUlBLEtBQUssS0FBS0YsYUFBdkMsQ0FBakI7QUFDQSxVQUFNakIsV0FBVyxHQUFJLE9BQU9rQixRQUFRLENBQUMsQ0FBRCxDQUFmLEtBQXdCLFdBQXpCLEdBQXdDQSxRQUFRLENBQUMsQ0FBRCxDQUFoRCxHQUFzRCxNQUExRTtBQUNBLFVBQU1FLGlCQUFpQixHQUFJSixjQUFjLEtBQUtDLGFBQTlDO0FBQ0F4UCxlQUFXLENBQUMrTyxNQUFaLENBQW1CO0FBQUNOLFFBQUUsRUFBQ0E7QUFBSixLQUFuQixFQUEyQjtBQUFDTyxVQUFJLEVBQUM7QUFBQ1QsbUJBQVcsRUFBQ0EsV0FBYjtBQUF5QkMsWUFBSSxFQUFDbUIsaUJBQTlCO0FBQWdEekIsb0JBQVksRUFBQ3VCO0FBQTdEO0FBQU4sS0FBM0I7QUFDRCxHQW5GWTs7QUFvRmIsZ0NBQThCaEIsRUFBOUIsRUFBa0NtQixNQUFsQyxFQUEwQ3BQLEtBQTFDLEVBQWlEVSxLQUFqRCxFQUF3RDtBQUN0RDZNLFdBQU8sQ0FBQ0MsR0FBUixDQUFZOU0sS0FBWjtBQUNBLFVBQU0yTyxpQkFBaUIsR0FBR0QsTUFBTSxHQUFHLEdBQVQsR0FBZXBQLEtBQXpDO0FBQ0FSLGVBQVcsQ0FBQytPLE1BQVosQ0FBbUI7QUFDakJOLFFBQUUsRUFBRUE7QUFEYSxLQUFuQixFQUdBO0FBQ0VPLFVBQUksRUFBQztBQUNILFNBQUNhLGlCQUFELEdBQXFCM087QUFEbEI7QUFEUCxLQUhBO0FBUUQ7O0FBL0ZZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNoQkEsSUFBSWlNLEtBQUo7QUFBVXZTLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ2lTLE9BQUssQ0FBQy9SLENBQUQsRUFBRztBQUFDK1IsU0FBSyxHQUFDL1IsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFWUixNQUFNLENBQUN3UyxhQUFQLENBRWUwQyxZQUFZLEdBQUcsSUFBSTNDLEtBQUssQ0FBQ0csVUFBVixDQUFxQixjQUFyQixDQUY5QixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlDLE1BQUo7QUFBVzNTLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3FTLFFBQU0sQ0FBQ25TLENBQUQsRUFBRztBQUFDbVMsVUFBTSxHQUFDblMsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJaVMsS0FBSjtBQUFVelMsTUFBTSxDQUFDTSxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2lTLFNBQUssR0FBQ2pTLENBQU47QUFBUTs7QUFBcEIsQ0FBakMsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSTRFLFdBQUo7QUFBZ0JwRixNQUFNLENBQUNNLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDNEUsZUFBVyxHQUFDNUUsQ0FBWjtBQUFjOztBQUExQixDQUF2QyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJMFUsWUFBSjtBQUFpQmxWLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLDJCQUFaLEVBQXdDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMwVSxnQkFBWSxHQUFDMVUsQ0FBYjtBQUFlOztBQUEzQixDQUF4QyxFQUFxRSxDQUFyRTtBQUF3RSxJQUFJTixXQUFKO0FBQWdCRixNQUFNLENBQUNNLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDSixhQUFXLENBQUNNLENBQUQsRUFBRztBQUFDTixlQUFXLEdBQUNNLENBQVo7QUFBYzs7QUFBOUIsQ0FBdkMsRUFBdUUsQ0FBdkU7O0FBUW5VLFNBQVMyVSxVQUFULENBQW9CM1AsSUFBcEIsRUFBMEJxTyxFQUExQixFQUE4QkYsV0FBOUIsRUFBMkM7QUFDekN2TyxhQUFXLENBQUM0TyxNQUFaLENBQW1CO0FBQUN4TyxRQUFJLEVBQUNBLElBQU47QUFBWXFPLE1BQUUsRUFBQ0EsRUFBZjtBQUFtQkYsZUFBVyxFQUFDQSxXQUEvQjtBQUE0Q0MsUUFBSSxFQUFDLEtBQWpEO0FBQXdEd0IsYUFBUyxFQUFFLElBQUk1TyxJQUFKO0FBQW5FLEdBQW5CO0FBQ0Q7O0FBRUQsU0FBUzZPLE9BQVQsQ0FBaUJoQyxPQUFqQixFQUEwQmlDLFFBQTFCLEVBQW9DO0FBQ2xDSixjQUFZLENBQUNsQixNQUFiLENBQW9CO0FBQUN4TyxRQUFJLEVBQUM2TixPQUFOO0FBQWVQLFFBQUksRUFBQ3dDO0FBQXBCLEdBQXBCO0FBQ0Q7O0FBRUQzQyxNQUFNLENBQUM0QyxPQUFQLENBQWUsTUFBTTtBQUNuQjtBQUNBO0FBRUE7QUFDQW5RLGFBQVcsQ0FBQytPLE1BQVosQ0FBbUI7QUFBRVAsUUFBSSxFQUFFO0FBQVIsR0FBbkIsRUFBa0M7QUFDaENRLFFBQUksRUFBQztBQUFFUixVQUFJLEVBQUU7QUFBUjtBQUQyQixHQUFsQyxFQUVHO0FBQUU0QixTQUFLLEVBQUU7QUFBVCxHQUZIOztBQUlBLE1BQUlwUSxXQUFXLENBQUMwTyxJQUFaLEdBQW1CQyxLQUFuQixPQUErQixDQUFuQyxFQUFzQztBQUNwQzNPLGVBQVcsQ0FBQzRPLE1BQVosQ0FBbUI7QUFDakJILFFBQUUsRUFBRSxHQURhO0FBRWpCLHNCQUFlO0FBQ2JyTyxZQUFJLEVBQUUsS0FETztBQUViSyxjQUFNLEVBQUUsTUFGSztBQUdiRyxXQUFHLEVBQUUsSUFIUTtBQUliZ0IscUJBQWEsRUFBRSxVQUpGO0FBS2JDLHVCQUFlLEVBQUUsQ0FBQyxTQUFELEVBQVksUUFBWixDQUxKO0FBTWJDLHdCQUFnQixFQUFFLENBQUMsU0FBRCxDQU5MO0FBT2JKLGVBQU8sRUFBRSxjQVBJO0FBUWJwRSx3QkFBZ0IsRUFBRSxLQVJMO0FBU2J5RSxxQkFBYSxFQUFFO0FBVEYsT0FGRTtBQWFqQm1NLGtCQUFZLEVBQUMsQ0FBQyxvQkFBRCxFQUF1QixnQkFBdkIsRUFBeUMsWUFBekMsRUFBdUQsa0JBQXZELEVBQTJFLGVBQTNFLEVBQTRGLFdBQTVGLENBYkk7QUFjakJLLGlCQUFXLEVBQUUsaUJBZEk7QUFlakJDLFVBQUksRUFBQyxLQWZZO0FBZ0JqQndCLGVBQVMsRUFBRSxJQUFJNU8sSUFBSjtBQWhCTSxLQUFuQjtBQWtCQXBCLGVBQVcsQ0FBQzRPLE1BQVosQ0FBbUI7QUFDakJILFFBQUUsRUFBRSxHQURhO0FBRWpCLHNCQUFlO0FBQ2JyTyxZQUFJLEVBQUUsTUFETztBQUViSyxjQUFNLEVBQUUsTUFGSztBQUdiRyxXQUFHLEVBQUUsSUFIUTtBQUliZ0IscUJBQWEsRUFBRSxVQUpGO0FBS2JDLHVCQUFlLEVBQUUsQ0FBQyxTQUFELEVBQVksUUFBWixDQUxKO0FBTWJDLHdCQUFnQixFQUFFLENBQUMsU0FBRCxDQU5MO0FBT2JKLGVBQU8sRUFBRSxjQVBJO0FBUWJwRSx3QkFBZ0IsRUFBRTtBQVJMLE9BRkU7QUFZakI0USxrQkFBWSxFQUFDLENBQUMsb0JBQUQsRUFBdUIsZ0JBQXZCLEVBQXlDLFlBQXpDLEVBQXVELGtCQUF2RCxFQUEwRSxlQUExRSxFQUEyRixXQUEzRixDQVpJO0FBYWpCSyxpQkFBVyxFQUFFLGlCQWJJO0FBY2pCQyxVQUFJLEVBQUMsS0FkWTtBQWVqQndCLGVBQVMsRUFBRSxJQUFJNU8sSUFBSjtBQWZNLEtBQW5CO0FBaUJBcEIsZUFBVyxDQUFDNE8sTUFBWixDQUFtQjtBQUNqQkgsUUFBRSxFQUFFLEdBRGE7QUFFakIsc0JBQWU7QUFDYnJPLFlBQUksRUFBRSx1QkFETztBQUViSyxjQUFNLEVBQUUsTUFGSztBQUdiRyxXQUFHLEVBQUUsSUFIUTtBQUliZ0IscUJBQWEsRUFBRSxVQUpGO0FBS2JDLHVCQUFlLEVBQUUsQ0FBQyxTQUFELEVBQVksUUFBWixDQUxKO0FBTWJDLHdCQUFnQixFQUFFLENBQUMsU0FBRCxDQU5MO0FBT2JKLGVBQU8sRUFBRSxjQVBJO0FBUWJwRSx3QkFBZ0IsRUFBRSxLQVJMO0FBU2J5RSxxQkFBYSxFQUFFO0FBVEYsT0FGRTtBQWFqQm1NLGtCQUFZLEVBQUUsRUFiRztBQWNqQkssaUJBQVcsRUFBRSxXQWRJO0FBZWpCQyxVQUFJLEVBQUMsS0FmWTtBQWdCakJ3QixlQUFTLEVBQUUsSUFBSTVPLElBQUo7QUFoQk0sS0FBbkI7QUFrQkQ7QUFDRixDQWhFRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50LCBGcmFnbWVudCB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCBEaXZpZGVyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0RpdmlkZXInO1xyXG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5JztcclxuXHJcbmltcG9ydCB7IGZvcm1TY2hlbWFzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2Zvcm1TY2hlbWFzJztcclxuXHJcbmltcG9ydCBBdXRvRm9ybSBmcm9tICd1bmlmb3Jtcy1tYXRlcmlhbC9BdXRvRm9ybSc7XHJcbmltcG9ydCBBdXRvRmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvQXV0b0ZpZWxkJztcclxuaW1wb3J0IFRleHRGaWVsZCBmcm9tICd1bmlmb3Jtcy1tYXRlcmlhbC9UZXh0RmllbGQnO1xyXG5pbXBvcnQgU3VibWl0RmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvU3VibWl0RmllbGQnO1xyXG5pbXBvcnQgU2VsZWN0RmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvU2VsZWN0RmllbGQnO1xyXG5pbXBvcnQgSGlkZGVuRmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvSGlkZGVuRmllbGQnO1xyXG5pbXBvcnQgTnVtRmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvTnVtRmllbGQnO1xyXG5pbXBvcnQgTGlzdEZpZWxkIGZyb20gJ3VuaWZvcm1zLW1hdGVyaWFsL0xpc3RGaWVsZCc7XHJcbmltcG9ydCBEYXRlRmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvRGF0ZUZpZWxkJztcclxuaW1wb3J0IFJhZGlvRmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvUmFkaW9GaWVsZCc7XHJcbmltcG9ydCBCb29sRmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvQm9vbEZpZWxkJztcclxuaW1wb3J0IExvbmdUZXh0RmllbGQgZnJvbSAndW5pZm9ybXMtbWF0ZXJpYWwvTG9uZ1RleHRGaWVsZCc7XHJcblxyXG5pbXBvcnQgQmFzZUZpZWxkIGZyb20gJ3VuaWZvcm1zL0Jhc2VGaWVsZCc7XHJcbmltcG9ydCBub3RoaW5nIGZyb20gJ3VuaWZvcm1zL25vdGhpbmcnO1xyXG5pbXBvcnQge0NoaWxkcmVufSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFJhZGlvIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5cclxuLy8gRGVmaW5lIERpc3BsYXlJZlxyXG4vLyBVc2VkIHRvIGRpc3BsYXkgZmllbGRzIGRlcGVuZGluZyBvbiBhbm90aGVyIGZpZWxkJ3MgcmVzcG9uc2VcclxuY29uc3QgRGlzcGxheUlmID0gKHtjaGlsZHJlbiwgY29uZGl0aW9ufSwge3VuaWZvcm1zfSkgPT4gKGNvbmRpdGlvbih1bmlmb3JtcykgPyBDaGlsZHJlbi5vbmx5KGNoaWxkcmVuKSA6IG5vdGhpbmcpO1xyXG5EaXNwbGF5SWYuY29udGV4dFR5cGVzID0gQmFzZUZpZWxkLmNvbnRleHRUeXBlcztcclxuXHJcbmNvbnN0IHJlcXVpcmVEb2N0b3JDb25zdWx0ID0gKGluZm8pID0+IChcclxuICA8RnJhZ21lbnQ+XHJcbiAgICB7KCh0eXBlb2YoaW5mb1tcIkhlaWdodCAmIHdlaWdodFwiXSkgIT09IFwidW5kZWZpbmVkXCIgJiYgaW5mb1tcIkhlaWdodCAmIHdlaWdodFwiXVswXS5kb2NDb25zdWx0Rm9ySFcpIHx8XHJcbiAgICAgICh0eXBlb2YoaW5mb1tcIkJsb29kIEdsdWNvc2UgJiBIYlwiXSkgIT09IFwidW5kZWZpbmVkXCIgJiYgaW5mb1tcIkJsb29kIEdsdWNvc2UgJiBIYlwiXVswXS5kb2NDb25zdWx0Rm9yQmxvb2RHbHVjQW5kSGIpIHx8XHJcbiAgICAgICh0eXBlb2YoaW5mb1tcIlBhcCBTbWVhclwiXSkgIT09IFwidW5kZWZpbmVkXCIgJiYgaW5mb1tcIlBhcCBTbWVhclwiXVswXS5kb2NDb25zdWx0Rm9yUGFwKSB8fFxyXG4gICAgICAodHlwZW9mKGluZm9bXCJCbG9vZCBQcmVzc3VyZVwiXSkgIT09IFwidW5kZWZpbmVkXCIgJiYgaW5mb1tcIkJsb29kIFByZXNzdXJlXCJdWzBdLmRvY0NvbnN1bHRGb3JCUCkpICYmXHJcbiAgICAgIDxEaXZpZGVyIC8+ICYmXHJcbiAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPSdzZWNvbmRhcnknIHZhcmlhbnQ9J2g2Jz5cclxuICAgICAgICBSZXF1aXJlIGNvbnN1bHQgZm9yOlxyXG4gICAgICA8L1R5cG9ncmFwaHk+IH1cclxuICAgIHsgdHlwZW9mKGluZm9bXCJIZWlnaHQgJiB3ZWlnaHRcIl0pICE9PSBcInVuZGVmaW5lZFwiICYmIGluZm9bXCJIZWlnaHQgJiB3ZWlnaHRcIl1bMF0uZG9jQ29uc3VsdEZvckhXICYmXHJcbiAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPSdzZWNvbmRhcnknPlxyXG4gICAgICAgIEhlaWdodCBhbmQgV2VpZ2h0XHJcbiAgICAgIDwvVHlwb2dyYXBoeT4gfVxyXG4gICAgeyB0eXBlb2YoaW5mb1tcIkJsb29kIEdsdWNvc2UgJiBIYlwiXSkgIT09IFwidW5kZWZpbmVkXCIgJiYgaW5mb1tcIkJsb29kIEdsdWNvc2UgJiBIYlwiXVswXS5kb2NDb25zdWx0Rm9yQmxvb2RHbHVjQW5kSGIgJiZcclxuICAgICAgPFR5cG9ncmFwaHkgY29sb3I9J3NlY29uZGFyeSc+XHJcbiAgICAgICAgQmxvb2QgR2x1Y29zZSBhbmQgSGJcclxuICAgICAgPC9UeXBvZ3JhcGh5PiB9XHJcbiAgICB7IHR5cGVvZihpbmZvW1wiUGFwIFNtZWFyXCJdKSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBpbmZvW1wiUGFwIFNtZWFyXCJdWzBdLmRvY0NvbnN1bHRGb3JQYXAgJiZcclxuICAgICAgPFR5cG9ncmFwaHkgY29sb3I9J3NlY29uZGFyeSc+XHJcbiAgICAgICAgUGFwIFNtZWFyXHJcbiAgICAgIDwvVHlwb2dyYXBoeT4gfVxyXG4gICAgeyB0eXBlb2YoaW5mb1tcIkJsb29kIFByZXNzdXJlXCJdKSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBpbmZvW1wiQmxvb2QgUHJlc3N1cmVcIl1bMF0uZG9jQ29uc3VsdEZvckJQICYmXHJcbiAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPSdzZWNvbmRhcnknPlxyXG4gICAgICAgIEJsb29kIFByZXNzdXJlXHJcbiAgICAgIDwvVHlwb2dyYXBoeT4gJiZcclxuICAgIDxEaXZpZGVyIC8+fVxyXG4gIDwvRnJhZ21lbnQ+XHJcbik7XHJcbi8vIERlZmluZSB0aGUgbGF5b3V0c1xyXG5leHBvcnQgY29uc3QgZm9ybUxheW91dHMgPSB7XHJcbiAgXCJSZWdpc3RyYXRpb25cIjp7XHJcbiAgICBcIlBhdGllbnQgSW5mb1wiOiAoaW5mbykgPT4gKFxyXG4gICAgICA8RnJhZ21lbnQ+XHJcbiAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwibmFtZVwiIC8+XHJcbiAgICAgICAgey8qIDxIaWRkZW5GaWVsZCBuYW1lPVwiaWRcIiAvPiAqL31cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cImdlbmRlclwiIC8+XHJcbiAgICAgICAgRW50ZXIgYmlydGhkYXRlIGluIGRkL21tL3l5eXkgZm9ybWF0XHJcbiAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwiYmlydGhkYXlcIiAvPlxyXG4gICAgICAgIDxOdW1GaWVsZCBuYW1lPVwiYWdlXCIgZGVjaW1hbD17ZmFsc2V9IC8+XHJcbiAgICAgICAgPERpdmlkZXIgdmFyaWFudD1cIm1pZGRsZVwiLz5cclxuXHJcbiAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwiZGlzdHJpY3RcIiAvPlxyXG4gICAgICAgIDxUZXh0RmllbGQgbmFtZT1cImFkZHJlc3NcIiAvPlxyXG4gICAgICAgIDxUZXh0RmllbGQgbmFtZT1cInppcGNvZGVcIiBkZWNpbWFsPXtmYWxzZX0gLz48YnIgLz5cclxuICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJjb250YWN0TnVtYmVyXCIgZGVjaW1hbD17ZmFsc2V9IC8+XHJcbiAgICAgICAgPEF1dG9GaWVsZCBuYW1lPVwic3Bva2VuTGFuZ3VhZ2VzXCIgLz5cclxuICAgICAgICA8QXV0b0ZpZWxkIG5hbWU9XCJ3cml0dGVuTGFuZ3VhZ2VzXCIgLz5cclxuICAgICAgICA8RGl2aWRlciB2YXJpYW50PVwibWlkZGxlXCIvPlxyXG5cclxuICAgICAgICA8UmFkaW9GaWVsZCBuYW1lPVwiYW55RHJ1Z0FsbGVyZ2llc1wiIC8+XHJcbiAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5hbnlEcnVnQWxsZXJnaWVzID09PSBcIlllc1wifT5cclxuICAgICAgICAgIDxUZXh0RmllbGQgbmFtZT1cImRydWdBbGxlcmdpZXNcIiAvPlxyXG4gICAgICAgIDwvRGlzcGxheUlmPlxyXG4gICAgICAgIDxEaXZpZGVyIHZhcmlhbnQ9XCJtaWRkbGVcIi8+XHJcblxyXG4gICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJwcmVnbmFudFwiIC8+XHJcblxyXG4gICAgICA8L0ZyYWdtZW50PlxyXG4gICAgKSxcclxuXHJcbiAgICBcIlBhdGllbnQgUHJvZmlsaW5nXCI6IChpbmZvKSA9PiAoXHJcbiAgICAgIDxGcmFnbWVudD5cclxuICAgICAgICA8aDI+RGlhYmV0ZXMgTWVsbGl0dXM8L2gyPlxyXG4gICAgICAgIEhhcyBhIHdlc3Rlcm4tdHJhaW5lZCBkb2N0b3IgZXZlciB0b2xkIHlvdSB0aGF0IHlvdSBoYXZlIGRpYWJldGVzP1xyXG4gICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJwYXRpZW50UHJvZmlsZTFcIiAvPlxyXG4gICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5wYXRpZW50UHJvZmlsZTEgPT09IFwiTm9cIn0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICBJZiBubyB0byBRMSwgd2hlbiB3YXMgdGhlIGxhc3QgdGltZSB5b3UgY2hlY2tlZCB5b3VyIGJsb29kIHN1Z2FyP1xyXG4gICAgICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBhdGllbnRQcm9maWxlMlwiIC8+XHJcbiAgICAgICAgICAgIElmIG5vIHRvIFExLCBkbyB5b3UgaGF2ZSBhbnkgb2YgdGhlIGZvbGxvd2luZyBzeW1wdG9tcz8gKHNlbGVjdCBhbGwgdGhhdCBhcHBseSlcclxuICAgICAgICAgICAgPEF1dG9GaWVsZCBuYW1lPVwicGF0aWVudFByb2ZpbGUzXCIgLz5cclxuICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLnBhdGllbnRQcm9maWxlMSA9PT0gXCJZZXNcIn0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICBJZiB5ZXMgdG8gUTEsIGhvdyBvZnRlbiBhcmUgeW91IHNlZWluZyB5b3VyIGRvY3RvciBmb3IgeW91ciBkaWFiZXRlcz9cclxuICAgICAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwYXRpZW50UHJvZmlsZTRcIiAvPlxyXG4gICAgICAgICAgICBJZiB5ZXMgdG8gUTEsIGFyZSB5b3UgdGFraW5nIGFueSBtZWRpY2F0aW9uIGZvciB5b3VyIGRpYWJldGVzPyBJZiBzbywgY2FuIHlvdSBuYW1lIHRoZW0/XHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cImFueVdlc3Rlcm5NZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5hbnlXZXN0ZXJuTWVkaWNpbmUgPT09IHRydWV9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwid2VzdGVybk1lZGljaW5lXCIgLz5cclxuICAgICAgICAgICAgSWYgeWVzIHRvIFdlc3Rlcm4gbWVkaWNpbmUsIGhvdyBtYW55IHRpbWVzIGRvIHlvdSBmb3JnZXQgdG8gdGFrZSB5b3VyIGRpYWJldGVzIG1lZGljYXRpb24gaW4gYSB3ZWVrP1xyXG4gICAgICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBhdGllbnRQcm9maWxlNlwiIC8+XHJcbiAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5wYXRpZW50UHJvZmlsZTEgPT09IFwiWWVzXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiYW55VHJhZGl0aW9uYWxNZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249IHtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuYW55VHJhZGl0aW9uYWxNZWRpY2luZSA9PT0gdHJ1ZX0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJ0cmFkaXRpb25hbE1lZGljaW5lXCIgLz5cclxuICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGgyPkh5cGVybGlwaWRlbWlhPC9oMj5cclxuICAgICAgICBIYXMgYSB3ZXN0ZXJuLXRyYWluZWQgZG9jdG9yIGV2ZXIgdG9sZCB5b3UgdGhhdCB5b3UgaGF2ZSBoaWdoIGNob2xlc3Rlcm9sP1xyXG4gICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJoeXBlcmxpcGlkZW1pYVExXCIgLz5cclxuICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLmh5cGVybGlwaWRlbWlhUTEgPT09IFwiTm9cIn0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgSWYgbm8gdG8gUTEsIHdoZW4gd2FzIHRoZSBsYXN0IHRpbWUgeW91IGNoZWNrZWQgeW91ciBibG9vZCBjaG9sZXN0ZXJvbD9cclxuICAgICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwiaHlwZXJsaXBpZGVtaWFRMlwiIC8+XHJcbiAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLmh5cGVybGlwaWRlbWlhUTEgPT09IFwiWWVzXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgIElmIHllcyB0byBRMSwgaG93IG9mdGVuIGFyZSB5b3Ugc2VlaW5nIHlvdXIgZG9jdG9yIGZvciB5b3VyIGhpZ2ggY2hvbGVzdGVyb2w/XHJcbiAgICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cImh5cGVybGlwaWRlbWlhUTNcIiAvPlxyXG4gICAgICAgICAgSWYgeWVzIHRvIFExLCBhcmUgeW91IHRha2luZyBhbnkgbWVkaWNhdGlvbiBmb3IgeW91ciBoaWdoIGNob2xlc3Rlcm9sPyBJZiBzbywgY2FuIHlvdSBuYW1lIHRoZW0/XHJcbiAgICAgICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJoeXBlcmxpcGlkZW1pYUFueVdlc3Rlcm5NZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5oeXBlcmxpcGlkZW1pYUFueVdlc3Rlcm5NZWRpY2luZSA9PT0gdHJ1ZX0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJoeXBlcmxpcGlkZW1pYVdlc3Rlcm5NZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICAgIElmIHllcyB0byB0YWtpbmcgV2VzdGVybiBtZWRpY2luZSwgaG93IG1hbnkgdGltZXMgZG8geW91IGZvcmdldCB0byB0YWtlIHlvdXIgaGlnaCBjaG9sZXN0ZXJvbCBtZWRpY2F0aW9uIGluIGEgd2Vlaz9cclxuICAgICAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJoeXBlcmxpcGlkZW1pYVE1XCIgLz5cclxuICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLmh5cGVybGlwaWRlbWlhUTEgPT09IFwiWWVzXCJ9PjxGcmFnbWVudD4gXHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cImh5cGVybGlwaWRlbWlhQW55VHJhZGl0aW9uYWxNZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPSB7Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLmh5cGVybGlwaWRlbWlhQW55VHJhZGl0aW9uYWxNZWRpY2luZSA9PT0gdHJ1ZX0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGQgbmFtZT1cImh5cGVybGlwaWRlbWlhVHJhZGl0aW9uYWxNZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG5cclxuICAgICAgICAgIDxoMj5IeXBlcnRlbnNpb248L2gyPlxyXG4gICAgICAgICAgSGFzIGEgd2VzdGVybi10cmFpbmVkIGRvY3RvciBldmVyIHRvbGQgeW91IHRoYXQgeW91IGhhdmUgaGlnaCBibG9vZCBwcmVzc3VyZSAoQlApP1xyXG4gICAgICAgICAgPFJhZGlvRmllbGQgbmFtZT1cImh5cGVydGVuc2lvblExXCIgLz5cclxuICAgICAgICAgIFdoZW4gd2FzIHRoZSBsYXN0IHRpbWUgeW91IGNoZWNrZWQgeW91ciBibG9vZCBwcmVzc3VyZT9cclxuICAgICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwiaHlwZXJ0ZW5zaW9uUTJcIiAvPlxyXG4gICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5oeXBlcnRlbnNpb25RMSA9PT0gXCJZZXNcIn0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICBJZiB5ZXMgdG8gUTEsIGhvdyBvZnRlbiBhcmUgeW91IHNlZWluZyB5b3VyIGRvY3RvciBmb3IgeW91ciBoaWdoIGJsb29kIHByZXNzdXJlP1xyXG4gICAgICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cImh5cGVydGVuc2lvblEzXCIgLz5cclxuICAgICAgICAgICAgSWYgeWVzIHRvIFExLCBhcmUgeW91IHRha2luZyBhbnkgbWVkaWNhdGlvbiBmb3IgeW91ciBoaWdoIGJsb29kIHByZXNzdXJlPyBJZiBzbywgY2FuIHlvdSBuYW1lIHRoZW0/XHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cImh5cGVydGVuc2lvbkFueVdlc3Rlcm5NZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuaHlwZXJ0ZW5zaW9uQW55V2VzdGVybk1lZGljaW5lID09PSB0cnVlfT48RnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwiaHlwZXJ0ZW5zaW9uV2VzdGVybk1lZGljaW5lXCIgLz5cclxuICAgICAgICAgICAgICBJZiB5ZXMgdG8gdGFraW5nIFdlc3Rlcm4gbWVkaWNpbmUsIGhvdyBtYW55IHRpbWVzIGRvIHlvdSBmb3JnZXQgdG8gdGFrZSB5b3VyIGhpZ2ggYmxvb2QgcHJlc3N1cmUgbWVkaWNhdGlvbiBpbiBhIHdlZWs/XHJcbiAgICAgICAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJoeXBlcnRlbnNpb25RNVwiIC8+XHJcbiAgICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuaHlwZXJ0ZW5zaW9uUTEgPT09IFwiWWVzXCJ9PjxGcmFnbWVudD4gXHJcbiAgICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiaHlwZXJ0ZW5zaW9uQW55VHJhZGl0aW9uYWxNZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249IHtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuaHlwZXJ0ZW5zaW9uQW55VHJhZGl0aW9uYWxNZWRpY2luZSA9PT0gdHJ1ZX0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwiaHlwZXJ0ZW5zaW9uVHJhZGl0aW9uYWxNZWRpY2luZVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuXHJcbiAgICAgICAgICAgIDxoMj5UQiBTY3JlZW5pbmc8L2gyPlxyXG4gICAgICAgICAgICBIYXZlIHlvdSBldmVyIGJlZW4gZGlhZ25vc2VkIHdpdGggdHViZXJjdWxvc2lzP1xyXG4gICAgICAgICAgICA8UmFkaW9GaWVsZCBuYW1lPVwiVEJRMVwiIC8+XHJcbiAgICAgICAgICAgIEhhdmUgeW91IGV2ZXIgbGl2ZWQgd2l0aCBzb21lb25lIHdpdGggdHViZXJjdWxvc2lzP1xyXG4gICAgICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cIlRCUTJcIiAvPlxyXG4gICAgICAgICAgICBEbyB5b3UgaGF2ZSBhbnkgb2YgdGhlIGZvbGxvd2luZyBzeW1wdG9tcz8gU2VsZWN0IGFsbCB0aGF0IGFwcGx5XHJcbiAgICAgICAgICAgIDxBdXRvRmllbGQgbmFtZT1cIlRCUTNcIiAvPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGgyPk1lZGljYWwgaGlzdG9yeTogb3RoZXJzPC9oMj5cclxuICAgICAgICAgICAgRG8geW91IGhhdmUgYW55IG1lZGljYWwgY29uZGl0aW9ucyB3ZSBzaG91bGQgdGFrZSBub3RlIG9mPyAoaWYgbm9uZSwgaW5kaWNhdGUgTklMKVxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJtZWRpY2FsSGlzdG9yeTFcIiAvPlxyXG4gICAgICAgICAgICBIb3cgYXJlIHlvdSBtYW5hZ2luZyB0aGVzZSBjb25kaXRpb25zPyAoY2hlY2stdXBzLCBtZWRpY2luZXMsIGRpZXQvZXhlcmNpc2UsIG90aGVycylcclxuICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwibWVkaWNhbEhpc3RvcnkyXCIgLz5cclxuICAgICAgICAgICAgV2hlcmUgZG8geW91IGdvIHRvIGZvciByb3V0aW5lIGhlYWx0aGNhcmU/XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbmFtZT1cIm1lZGljYWxIaXN0b3J5M1wiIC8+XHJcbiAgICAgICAgICAgIFdoZXJlIGRvIHlvdSBnbyB0byBmb3IgZW1lcmdlbmN5IG1lZGljYWwgc2VydmljZXMgKGVnLiBmYWxsLCBpbmp1cnksIGZhaW50aW5nKT9cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwibWVkaWNhbEhpc3Rvcnk0XCIgLz5cclxuICAgICAgICAgICAgQXJlIHlvdSB0YWtpbmcgYW55IG90aGVyIG1lZGljYXRpb25zPyAoSWYgeWVzLCBpbmRpY2F0ZSB3aGF0IG1lZGljYXRpb24gYW5kIHdoeS4gSWYgbm9uZSwgaW5kaWNhdGUgTklMKVxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJtZWRpY2FsSGlzdG9yeTVcIiAvPlxyXG5cclxuICAgICAgICAgICAgPGgyPlN1cmdlcnkgYW5kIGhvc3BpdGFsaXNhdGlvbnM8L2gyPlxyXG4gICAgICAgICAgICBIYXZlIHlvdSBoYWQgYW55IHN1cmdlcnkgcHJldmlvdXNseT9cclxuICAgICAgICAgICAgPFJhZGlvRmllbGQgbmFtZT1cInN1cmdBbmRIb3NwUTFcIiAvPlxyXG4gICAgICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLnN1cmdBbmRIb3NwUTEgPT09IFwiWWVzXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgICBJZiB5ZXMgdG8gUTEsIHdoYXQgc3VyZ2VyeT9cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJzdXJnQW5kSG9zcFEyXCIgLz5cclxuICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuICAgICAgICAgICAgSGF2ZSB5b3UgYmVlbiBob3NwaXRhbGlzZWQgaW4gdGhlIHBhc3QgNSB5ZWFycz8gXHJcbiAgICAgICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdXJnQW5kSG9zcFEzXCIgLz5cclxuICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5zdXJnQW5kSG9zcFEzID09PSBcIlllc1wifT48RnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgSWYgeWVzIHRvIFEzLCB3aHkgd2VyZSB5b3UgaG9zcGl0YWxpc2VkP1xyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGQgbmFtZT1cInN1cmdBbmRIb3NwUTRcIiAvPlxyXG4gICAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG5cclxuICAgICAgICAgICAgPGgyPk9jdWxhciBIaXN0b3J5PC9oMj5cclxuICAgICAgICAgICAgSGF2ZSB5b3UgaGFkIGFueSBleWUgc3VyZ2VyaWVzP1xyXG4gICAgICAgICAgICA8UmFkaW9GaWVsZCBuYW1lPVwib2N1bGFySGlzUTFhXCIgLz5cclxuICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5vY3VsYXJIaXNRMWEgPT09IFwiWWVzXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgICBJZiB5ZXMgdG8gMWEsIHBsZWFzZSBzcGVjaWZ5XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwib2N1bGFySGlzUTFiXCIgLz5cclxuICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuICAgICAgICAgICAgQW55IHByZXZpb3VzIHRyYXVtYSB0byB0aGUgZXllP1xyXG4gICAgICAgICAgICA8UmFkaW9GaWVsZCBuYW1lPVwib2N1bGFySGlzUTJhXCIgLz5cclxuICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5vY3VsYXJIaXNRMmEgPT09IFwiWWVzXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgICBJZiB5ZXMgdG8gMmEsIHBsZWFzZSBzcGVjaWZ5XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwib2N1bGFySGlzUTJiXCIgLz5cclxuICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuICAgICAgICAgICAgQXJlIHlvdSB1bmRlciB0aGUgY2FyZSBvZiBhbnkgZXllIHNwZWNpYWxpc3Qgb3IgcmVjZWl2aW5nIHRyZWF0bWVudCBmb3IgdGhlIGV5ZSBmcm9tIGFueSBob3NwaXRhbC9jbGluaWM/XHJcbiAgICAgICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJvY3VsYXJIaXNRM2FcIiAvPlxyXG4gICAgICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLm9jdWxhckhpc1EzYSA9PT0gXCJZZXNcIn0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICAgIElmIHllcyB0byAzYSwgcGxlYXNlIHNwZWNpZnkgd2hlcmVcclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJvY3VsYXJIaXNRM2JcIiAvPlxyXG4gICAgICAgICAgICAgIElmIHllcyB0byAzYSwgd2hlbiB3YXMgeW91ciBsYXN0IHJldmlldz9cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJvY3VsYXJIaXNRM2NcIiAvPlxyXG4gICAgICAgICAgICAgIElmIHllcyB0byAzYSwgd2hhdCB3YXMgdGhlIGNvbmRpdGlvbj9cclxuICAgICAgICAgICAgICA8QXV0b0ZpZWxkIG5hbWU9XCJvY3VsYXJIaXNRM2RcIiAvPlxyXG4gICAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBBcnJheS5pc0FycmF5KGNvbnRleHQubW9kZWwub2N1bGFySGlzUTNkKSAmJiBjb250ZXh0Lm1vZGVsLm9jdWxhckhpc1EzZC5pbmNsdWRlcygnT3RoZXJzIChwbGVhc2Ugc3BlY2lmeSknKX0+PEZyYWdtZW50PiBcclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJvdGhlck9jdWxhckNvbmRcIiAvPlxyXG4gICAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPiAgICAgICAgICBcclxuICAgICAgICAgICAgSGF2ZSB5b3UgaGFkIGFueSBmYWxscyBpbiB0aGUgbGFzdCAxIHllYXI/XHJcbiAgICAgICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJvY3VsYXJIaXNRNFwiIC8+XHJcbiAgICAgICAgICAgIEhvdyBkbyB5b3UgcGVyY2VpdmUgeW91ciB2aXNpb24/XHJcbiAgICAgICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwib2N1bGFySGlzUTVhXCIgLz5cclxuICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5vY3VsYXJIaXNRNWEgPT09IFwiUG9vclwifT48RnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgSWYgYW5zd2VyIHRvIDVhIHdhcyAnUG9vcicsIGRvIHlvdSBpbnRlbmQgdG8gc2VlayBtZWRpY2FsIGhlbHA/XHJcbiAgICAgICAgICAgICAgPFJhZGlvRmllbGQgbmFtZT1cIm9jdWxhckhpc1E1YlwiIC8+XHJcbiAgICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwub2N1bGFySGlzUTViID09PSBcIk5vXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgICBJZiBubyB0byA1Yiwgd2h5P1xyXG4gICAgICAgICAgICAgIDxBdXRvRmllbGQgbmFtZT1cIm9jdWxhckhpc1E1Y1wiIC8+XHJcbiAgICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IEFycmF5LmlzQXJyYXkoY29udGV4dC5tb2RlbC5vY3VsYXJIaXNRNWMpICYmIGNvbnRleHQubW9kZWwub2N1bGFySGlzUTVjLmluY2x1ZGVzKCdPdGhlcnMgKHBsZWFzZSBzcGVjaWZ5KScpfT48RnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwib3RoZXJSZWFzb25zXCIgLz5cclxuICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuXHJcbiAgICAgICAgICAgIDxoMj5CYXJyaWVycyB0byBIZWFsdGhjYXJlPC9oMj5cclxuICAgICAgICAgICAgV2hhdCB0eXBlIG9mIGRvY3RvciBkbyB5b3Ugc2VlIGZvciB5b3VyIGV4aXN0aW5nIGNvbmRpdGlvbnM/XHJcbiAgICAgICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwiYmFycmllclExXCIgLz5cclxuICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5iYXJyaWVyUTEgPT09IFwiU2VsZG9tL05ldmVyIHZpc2l0cyB0aGUgZG9jdG9yXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgICBJZiBhbnN3ZXIgdG8gUTEgd2FzICdTZWxkb20vTmV2ZXIgdmlzaXRzIHRoZSBkb2N0b3InLCB3aHkgZG8geW91IG5vdCBmb2xsb3ctdXAgd2l0aCB5b3VyIGRvY3RvciBmb3IgeW91ciBleGlzdGluZyBjb25kaXRpb25zP1xyXG4gICAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cIm5vTmVlZFwiIC8+XHJcbiAgICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwidGltZVwiIC8+XHJcbiAgICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwibW9iaWxpdHlcIiAvPlxyXG4gICAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cImZpbmFuY2lhbFwiIC8+XHJcbiAgICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwic2NhcmVkXCIgLz5cclxuICAgICAgICAgICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJwcmVmZXJUcmFkTWVkXCIgLz5cclxuICAgICAgICAgICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJhbnlPdGhlckJhcnJpZXJzXCIgLz5cclxuICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5hbnlPdGhlckJhcnJpZXJzID09PSB0cnVlfT48RnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwib3RoZXJCYXJyaWVyc1wiIC8+XHJcbiAgICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcblxyXG4gICAgICAgICAgICA8aDI+RmFtaWx5IEhpc3Rvcnk8L2gyPlxyXG4gICAgICAgICAgICBEbyB5b3VyIHBhcmVudHMsIHNpYmxpbmdzIG9yIGNoaWxkcmVuIGhhdmUgYW55IG9mIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9ucz8gTm90ZTogQ0FEID0gY29yb25hcnkgYXJ0ZXJ5IGRpc2Vhc2UgKG5hcnJvd2VkIGJsb29kIHZlc3NlbHMgc3VwcGx5aW5nIGhlYXJ0IG11c2NsZSlcclxuICAgICAgICAgICAgPEF1dG9GaWVsZCBuYW1lPVwiZmFtaWx5SGlzdG9yeVwiIC8+XHJcblxyXG4gICAgICAgICAgICA8aDI+RnJhbWluZ2hhbSBMaXBpZHMgUmlzayBTdHJhdGlmaWNhdGlvbjwvaDI+XHJcbiAgICAgICAgICAgIEhhcyBhIGRvY3RvciB0b2xkIHlvdSB0aGF0IHlvdSBoYXZlIGFueSBoZWFydCBwcm9ibGVtcz8gSWYgeWVzLCBwbGVhc2UgZWxhYm9yYXRlXHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbmFtZT1cIkZMUlNRMVwiIC8+XHJcbiAgICAgICAgICAgIEhhdmUgeW91IGV2ZXIgYmVlbiBkaWFnbm9zZWQgYnkgeW91ciBkb2N0b3IgdG8gaGF2ZSBhIHN0cm9rZT9cclxuICAgICAgICAgICAgPFJhZGlvRmllbGQgbmFtZT1cIkZMUlNRMlwiIC8+XHJcbiAgICAgICAgICAgIEhhcyB5b3VyIGRvY3RvciBldmVyIHRvbGQgeW91IHRoYXQgeW91IGhhdmUgYW55IHByb2JsZW1zIHdpdGggeW91ciBibG9vZCB2ZXNzZWxzL2Jsb29kIGZsb3c/IElmIHllcywgcGxlYXNlIGVsYWJvcmF0ZVxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJGTFJTUTNcIiAvPlxyXG4gICAgICAgICAgICBIYXZlIHlvdSBldmVyIGJlZW4gZGlhZ25vc2VkIGJ5IHlvdXIgZG9jdG9yIHRvIGhhdmUgY2hyb25pYyBraWRuZXkgZGlzZWFzZT9cclxuICAgICAgICAgICAgPFJhZGlvRmllbGQgbmFtZT1cIkZMUlNRNFwiIC8+XHJcbiAgICAgICAgICAgIERvIHlvdSBjdXJyZW50bHkgc21va2U/XHJcbiAgICAgICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJGTFJTUTVcIiAvPlxyXG4gICAgICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLkZMUlNRNSA9PT0gXCJZZXNcIn0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICAgIElmIHllcyB0byBRNSwgd2hhdCBkbyB5b3Ugc21va2U/IChzZWxlY3QgYWxsIHRoYXQgYXBwbHkpXHJcbiAgICAgICAgICAgICAgPEF1dG9GaWVsZCBuYW1lPVwiRkxSU1E2XCIgLz5cclxuICAgICAgICAgICAgICBJZiB5ZXMgdG8gUTUsIGhvdyBtdWNoIGRvIHlvdSBzbW9rZT9cclxuICAgICAgICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cIkZMUlNRN1wiIC8+XHJcbiAgICAgICAgICAgICAgSWYgeWVzIHRvIFE1LCBob3cgbWFueSB5ZWFycyBoYXZlIHlvdSBiZWVuIHNtb2tpbmcgZm9yP1xyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGQgbmFtZT1cIkZMUlNROFwiIC8+XHJcbiAgICAgICAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgICAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuRkxSU1E1ID09PSBcIk5vXCJ9PjxGcmFnbWVudD5cclxuICAgICAgICAgICAgICBJZiBubyB0byBRNSwgaGF2ZSB5b3UgZXZlciBzbW9rZWQgYmVmb3JlP1xyXG4gICAgICAgICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwiRkxSU1E5XCIgLz5cclxuICAgICAgICAgICAgPC9GcmFnbWVudD48L0Rpc3BsYXlJZj5cclxuICAgICAgICAgICAgRG8geW91IGNoZXcgcGFhbiBvciB0b2JhY2NvP1xyXG4gICAgICAgICAgICA8UmFkaW9GaWVsZCBuYW1lPVwiRkxSU1ExMFwiIC8+XHJcblxyXG4gICAgICAgICAgICA8aDI+U29jaWFsIEhpc3Rvcnk8L2gyPlxyXG4gICAgICAgICAgICBEbyB5b3UgZHJpbmsgYWxjb2hvbD9cclxuICAgICAgICAgICAgPFJhZGlvRmllbGQgbmFtZT1cInNvY2lhbEhpc1ExXCIgLz5cclxuICAgICAgICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5zb2NpYWxIaXNRMSA9PT0gXCJZZXNcIn0+PEZyYWdtZW50PlxyXG4gICAgICAgICAgICAgIElmIHllcyB0byBRMSwgaG93IG1hbnkgZ2xhc3NlcyBvZiBhbGNvaG9sIGRvIHlvdSBkcmluayBwZXIgZGF5PzxiciAvPlxyXG4gICAgICAgICAgICAgIDxOdW1GaWVsZCBuYW1lPVwic29jaWFsSGlzUTJcIiAvPjxiciAvPlxyXG4gICAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgICBXaGF0IGlzIHlvdXIgb2NjdXBhdGlvbj9cclxuICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwic3R1ZGVudFwiIC8+XHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cImhvdXNld2lmZVwiIC8+XHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cInJlbGlnXCIgLz5cclxuICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwicHJvZlwiIC8+XHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cInNlcnZpY2VcIiAvPlxyXG4gICAgICAgICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJtYW51YWxcIiAvPlxyXG4gICAgICAgICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJza2lsbGVkTGFiXCIgLz5cclxuICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiZmFybWluZ1wiIC8+XHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cIm1pbmluZ1wiIC8+XHJcbiAgICAgICAgICAgIDxCb29sRmllbGQgbmFtZT1cIm1hbnVcIiAvPlxyXG4gICAgICAgICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJ1bmVtcGxveWVkXCIgLz5cclxuICAgICAgICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiYW55T3RoZXJPY2NcIiAvPlxyXG4gICAgICAgICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLmFueU90aGVyT2NjID09PSB0cnVlfT48RnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgSWYgeWVzIHRvIFExLCBob3cgbWFueSBnbGFzc2VzIG9mIGFsY29ob2wgZG8geW91IGRyaW5rIHBlciBkYXk/XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZCBuYW1lPVwib3RoZXJPY2NcIiAvPlxyXG4gICAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgICBOYXR1cmUgb2Ygd29yay9saWZlc3R5bGVcclxuICAgICAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJzb2NpYWxIaXNRNFwiIC8+XHJcbiAgICAgICAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuc29jaWFsSGlzUTMgPT09IFwiRmFybWluZy9BZ3JpY3VsdHVyZVwifT48RnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgSWYgYW5zd2VyIHRvIFEzIGlzICdGYXJtaW5nL2FncmljdWx0dXJlJywgZG8geW91IHVzZSBwZXN0aWNpZGVzIGluIHlvdXIgZmFybWluZz9cclxuICAgICAgICAgICAgICA8UmFkaW9GaWVsZCBuYW1lPVwic29jaWFsSGlzUTVcIiAvPlxyXG4gICAgICAgICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICAgICAgICBNb250aGx5IEluY29tZSBpbiBJTlIgKG9ubHkgaWYgcGFydGljaXBhbnQgaXMgd2lsbGluZyB0byBkaXNjbG9zZSk8YnIgLz5cclxuICAgICAgICAgICAgPE51bUZpZWxkIG5hbWU9XCJzb2NpYWxIaXNRNlwiIC8+XHJcbiAgICAgICAgICAgIDxEaXZpZGVyIHZhcmlhbnQ9XCJtaWRkbGVcIiAvPk1hcml0YWwgc3RhdHVzXHJcbiAgICAgICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwic29jaWFsSGlzUTdcIiAvPlxyXG4gICAgICAgICAgICBOdW1iZXIgb2YgY2hpbGRyZW48YnIgLz5cclxuICAgICAgICAgICAgPE51bUZpZWxkIG5hbWU9XCJzb2NpYWxIaXNROFwiLz5cclxuICAgICAgICAgICAgPERpdmlkZXIgdmFyaWFudD1cIm1pZGRsZVwiIC8+XHJcbiAgICAgICAgICAgIEhvdyBtYW55IHBlb3BsZSBsaXZlIGluIHlvdXIgaG91c2Vob2xkIChpbmNsdWRpbmcgeW91KT88YnIgLz5cclxuICAgICAgICAgICAgPE51bUZpZWxkIG5hbWU9XCJzb2NpYWxIaXNROVwiLz5cclxuICAgICAgICAgICAgPERpdmlkZXIgdmFyaWFudD1cIm1pZGRsZVwiIC8+XHJcbiAgICAgICAgICAgIEhvdyBtYW55IGRlcGVuZGVudHMgYXJlIHRoZXJlIGluIHlvdXIgaG91c2Vob2xkIChjaGlsZHJlbiwgc3BvdXNlLCBwYXJlbnRzLCByZWxhdGl2ZXMgbGl2aW5nIHdpdGggeW91IHdobyByZWx5IG9uIHlvdSBmb3IgZmluYW5jaWFsIHN1cHBvcnQpP1xyXG4gICAgICAgICAgICA8TnVtRmllbGQgbmFtZT1cInNvY2lhbEhpc1ExMFwiLz5cclxuICAgICAgICAgICAgPERpdmlkZXIgdmFyaWFudD1cIm1pZGRsZVwiIC8+XHJcbiAgICAgICAgICAgIEhvdyBtYW55IHBlb3BsZSBpbiB5b3VyIGhvdXNlaG9sZCBjb250cmlidXRlIHRvIGhvdXNlaG9sZCBpbmNvbWU/PGJyIC8+XHJcbiAgICAgICAgICAgIDxOdW1GaWVsZCBuYW1lPVwic29jaWFsSGlzUTExXCIvPlxyXG4gICAgICAgICAgICA8RGl2aWRlciB2YXJpYW50PVwibWlkZGxlXCIgLz5cclxuICAgICAgICAgICAgSG93IG1hbnkgcGVvcGxlIGluIHlvdXIgaG91c2Vob2xkIGRvIG5vdCBjb250cmlidXRlIHRvIG9yIGRlcGVuZCBvbiBob3VzZWhvbGQgaW5jb21lPyAoS0lWKVxyXG4gICAgICAgICAgICA8RGl2aWRlciB2YXJpYW50PVwibWlkZGxlXCIgLz5cclxuICAgICAgICAgICAgV2hhdCBpcyB5b3VyIGhpZ2hlc3QgZWR1Y2F0aW9uIGxldmVsP1xyXG4gICAgICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInNvY2lhbEhpc1ExM1wiIC8+XHJcbiAgICAgIDwvRnJhZ21lbnQ+XHJcbiAgICAgIFxyXG4gICAgKSxcclxuXHJcbiAgICBcIlN0YXRpb24gU2VsZWN0aW9uXCI6IChpbmZvKSA9PiAoXHJcbiAgICAgIDxGcmFnbWVudD5cclxuICAgICAgPGgyPkhlaWdodCBhbmQgV2VpZ2h0ICsgV2Fpc3Q6SGlwIG1lYXN1cmVtZW50PC9oMj5cclxuICAgICAgQ2FuIHdlIG1lYXN1cmUgeW91ciBoZWlnaHQsIHdlaWdodCwgd2Fpc3Qgc2l6ZSBhbmQgaGlwIHNpemU/XHJcbiAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0MVwiIC8+XHJcbiAgICAgIDxoMj5CbG9vZCBnbHVjb3NlIGFuZCBIYjwvaDI+XHJcbiAgICAgIENhbiB3ZSBjaGVjayB5b3VyIGJsb29kIHN1Z2FyPyBUaGlzIHdpbGwgYmUgZG9uZSBieSBwcmlja2luZyB5b3VyIGZpbmdlciB0byBnZXQgYSBzbWFsbCBkcm9wIG9mIGJsb29kXHJcbiAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0MlwiIC8+XHJcbiAgICAgIENhbiB3ZSBjaGVjayBpZiB5b3UgaGF2ZSBhbmVtaWE/IFRoaXMgd2lsbCBiZSBkb25lIGJ5IHByaWNraW5nIHlvdXIgZmluZ2VyIHRvIGdldCBhIHNtYWxsIGRyb3Agb2YgYmxvb2RcclxuICAgICAgPFJhZGlvRmllbGQgbmFtZT1cInN0YXRpb25TZWxlY3QzXCIgLz5cclxuICAgICAgPGgyPkJQPC9oMj5cclxuICAgICAgQ2FuIHdlIGNoZWNrIHlvdXIgYmxvb2QgcHJlc3N1cmU/XHJcbiAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0NFwiIC8+XHJcbiAgICAgIDxoMj5QaGxlYm90b215IChmb3IgcGF0aWVudHMgYWdlZCA0MCB5ZWFycyBvbGQgYW5kIGFib3ZlKTwvaDI+XHJcbiAgICAgIEZvciBwYXRpZW50cyBhZ2VkIDQwIHllYXJzIG9sZCBhbmQgYWJvdmUsIERvIHlvdSBoYXZlIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9ucz9cclxuICAgICAgPEF1dG9GaWVsZCBuYW1lPVwic3RhdGlvblNlbGVjdDVcIiAvPlxyXG4gICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBBcnJheS5pc0FycmF5KGNvbnRleHQubW9kZWwuc3RhdGlvblNlbGVjdDUpICYmIGNvbnRleHQubW9kZWwuc3RhdGlvblNlbGVjdDUubGVuZ3RoID49IDJ9PjxGcmFnbWVudD5cclxuICAgICAgICBDYW4gd2UgZG8gYSBibG9vZCB0ZXN0IHRvIHNlZSBpZiB5b3UgaGF2ZSBoaWdoIGNob2xlc3Rlcm9sPyBBIGJsb29kIHNhbXBsZSB3aWxsIGJlIHRha2VuIGJ5IGEgdHJhaW5lZCBzdGFmZi4gVGhpcyB3aWxsIHRoZW4gYmUgc2VudCB0byB0aGUgbGFiLCBhbmQgYSByZXBvcnQgd2lsbCBiZSBtYWlsZWQgdG8geW91IGFmdGVyIHNvbWUgdGltZVxyXG4gICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0NlwiIC8+XHJcbiAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgIDxoMj5QYXAgU21lYXI8L2gyPlxyXG4gICAgICBBcmUgeW91IG1hcnJpZWQgKG9yIGhhdmUgeW91IGV2ZXIgYmVlbiBtYXJyaWVkKT9cclxuICAgICAgPFJhZGlvRmllbGQgbmFtZT1cInN0YXRpb25TZWxlY3Q3XCIgLz5cclxuICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gY29udGV4dC5tb2RlbC5zdGF0aW9uU2VsZWN0NyA9PT0gXCJZZXNcIn0+PEZyYWdtZW50PlxyXG4gICAgICAgIElmIHllcyB0byBRNywgaGF2ZSB5b3UgZG9uZSBhIFBhcCBzbWVhciBpbiB0aGUgcGFzdCAzIHllYXJzP1xyXG4gICAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0OFwiIC8+XHJcbiAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuc3RhdGlvblNlbGVjdDggPT09IFwiTm9cIn0+PEZyYWdtZW50PlxyXG4gICAgICAgIElmIG5vIHRvIFE4LCB3b3VsZCB5b3Ugd2FudCB0byB1bmRlcmdvIGEgZnJlZSBQYXAgc21lYXIgdG9kYXkgdG8gY2hlY2sgZm9yIGNlcnZpY2FsIGNhbmNlcj9cclxuICAgICAgICA8UmFkaW9GaWVsZCBuYW1lPVwic3RhdGlvblNlbGVjdDlcIiAvPlxyXG4gICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICA8aDI+QnJlYXN0PC9oMj5cclxuICAgICAgV291bGQgeW91IHdhbnQgdG8gdW5kZXJnbyBhIGJyZWFzdCBleGFtaW5hdGlvbiBmb3IgYnJlYXN0IGNhbmNlciB0b2RheT8gXHJcbiAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0MTBcIiAvPlxyXG4gICAgICA8aDI+V29tZW4ncyBFZHU8L2gyPlxyXG4gICAgICBDYW4gd2UgdGVhY2ggeW91IGFib3V0IHdvbWVuJ3MgaGVhbHRoPyBGb3IgYWR1bHRzLCB3ZSB3aWxsIGJlIHNoYXJpbmcgYWJvdXQgbWVuc3RydWFsIGhlYWx0aCBhbmQgYnJlYXN0IHNlbGYgZXhhbWluYXRpb25zLiBGb3IgZ2lybHMgYWdlZCAxMC0xOCB5ZWFycyBvbGQsIHdlIHdpbGwgYmUgc2hhcmluZyBhYm91dCBtZW5zdHJ1YWwgaGVhbHRoIG9ubHkuXHJcbiAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0MTFcIiAvPlxyXG4gICAgICA8aDI+RG9jdG9ycycgY29uc3VsdDwvaDI+XHJcbiAgICAgIFdvdWxkIHlvdSBsaWtlIHRvIHNlZSBhIGRvY3RvciB0b2RheT8gKFlvdSB3aWxsIGJlIGFza2VkIHRvIHNlZSB0aGUgZG9jdG9yIGlmIHlvdXIgdGVzdCByZXN1bHRzIGFyZSBhYm5vcm1hbCwgYnV0IHdvdWxkIHlvdSBvdGhlcndpc2Ugd2FudCB0byBzZWUgdGhlIGRvY3Rvcj8pXHJcbiAgICAgIDxSYWRpb0ZpZWxkIG5hbWU9XCJzdGF0aW9uU2VsZWN0MTJcIiAvPlxyXG4gICAgICA8aDI+RXllIHNjcmVlbmluZzwvaDI+XHJcbiAgICAgIENhbiB3ZSBjaGVjayB5b3VyIGV5ZXMvdmlzaW9uP1xyXG4gICAgICA8UmFkaW9GaWVsZCBuYW1lPVwic3RhdGlvblNlbGVjdDEzXCIgLz5cclxuICAgICAgPGgyPkVkdWNhdGlvbjwvaDI+XHJcbiAgICAgIENhbiB3ZSB0ZWFjaCB5b3UgYWJvdXQgaGVhbHRoeSBsaWZlc3R5bGVzIGFuZCBob3cgdG8gcHJldmVudCBjb21tb24gZGlzZWFzZXMgbGlrZSBkaWFiZXRlcyBhbmQgaGlnaCBibG9vZCBwcmVzc3VyZT9cclxuICAgICAgPFJhZGlvRmllbGQgbmFtZT1cInN0YXRpb25TZWxlY3QxNFwiIC8+XHJcbiAgICAgIDwvRnJhZ21lbnQ+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG5cclxuICBcIkhlaWdodCAmIHdlaWdodFwiOiAoaW5mbykgPT4gKFxyXG4gICAgPEZyYWdtZW50PlxyXG4gICAgICA8aDI+SGVpZ2h0IGFuZCBXZWlnaHQ8L2gyPlxyXG4gICAgICB7Lyoge3R5cGVvZihpbmZvW1wiUGF0aWVudCBJbmZvXCJdKSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBpbmZvW1wiUGF0aWVudCBJbmZvXCJdLmFnZX0gKi99XHJcbiAgICAgIDxUZXh0RmllbGQgbmFtZT1cImhlaWdodFwiIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8VGV4dEZpZWxkIG5hbWU9XCJ3ZWlnaHRcIiAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgICAgPGgyPldhaXN0OkhpcDwvaDI+XHJcbiAgICAgIDxUZXh0RmllbGQgbmFtZT1cIndhaXN0XCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxUZXh0RmllbGQgbmFtZT1cImhpcFwiIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8aDI+T3ZlcnZpZXc8L2gyPlxyXG4gICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJkb2NDb25zdWx0Rm9ySFdcIiAvPlxyXG4gICAgPC9GcmFnbWVudD5cclxuICApLFxyXG5cclxuICBcIkJsb29kIEdsdWNvc2UgJiBIYlwiOiAoaW5mbykgPT4gKFxyXG4gICAgPEZyYWdtZW50PlxyXG4gICAgICA8VGV4dEZpZWxkIG5hbWU9XCJjYmdcIiAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgICAgPFRleHRGaWVsZCBuYW1lPVwiaGJcIiAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiZG9jQ29uc3VsdEZvckJsb29kR2x1Y0FuZEhiXCIgLz5cclxuICAgIDwvRnJhZ21lbnQ+XHJcbiAgKSxcclxuXHJcbiAgXCJCbG9vZCBQcmVzc3VyZVwiOiAoaW5mbykgPT4gKFxyXG4gICAgPEZyYWdtZW50PlxyXG4gICAgICA8ZGl2PjxUZXh0RmllbGQgbmFtZT1cImJwMVN5c1wiIC8+PC9kaXY+XHJcbiAgICAgIDxkaXY+PFRleHRGaWVsZCBuYW1lPVwiYnAxRGlhXCIgLz48L2Rpdj5cclxuICAgICAgPGRpdj48VGV4dEZpZWxkIG5hbWU9XCJicDJTeXNcIiAvPjwvZGl2PlxyXG4gICAgICA8ZGl2PjxUZXh0RmllbGQgbmFtZT1cImJwMkRpYVwiIC8+PC9kaXY+XHJcblxyXG4gICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBNYXRoLmFicyhjb250ZXh0Lm1vZGVsLmJwMlN5cyAtIGNvbnRleHQubW9kZWwuYnAxU3lzKSA+IDUgfHwgTWF0aC5hYnMoY29udGV4dC5tb2RlbC5icDJEaWEgLSBjb250ZXh0Lm1vZGVsLmJwMURpYSkgPiA1IH0+PEZyYWdtZW50PlxyXG4gICAgICAgIDxkaXY+PFRleHRGaWVsZCBuYW1lPVwiYnAzU3lzXCIgLz48L2Rpdj5cclxuICAgICAgICA8ZGl2PjxUZXh0RmllbGQgbmFtZT1cImJwM0RpYVwiIC8+PC9kaXY+XHJcbiAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcblxyXG4gICAgICA8ZGl2PjxCb29sRmllbGQgbmFtZT1cImRvY0NvbnN1bHRGb3JCUFwiIC8+PC9kaXY+XHJcbiAgICA8L0ZyYWdtZW50PlxyXG4gICksXHJcblxyXG4gIFwiUGhsZWJvdG9teVwiOiAoaW5mbykgPT4gKFxyXG4gICAgPEZyYWdtZW50PlxyXG4gICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJwaGxlYm9Db21wbGV0ZWRcIiAvPlxyXG4gICAgPC9GcmFnbWVudD5cclxuICApLFxyXG5cclxuICBcIlBhcCBTbWVhclwiOiAoaW5mbykgPT4gKFxyXG4gICAgPEZyYWdtZW50PlxyXG4gICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJwYXBDb21wbGV0ZWRcIiAvPlxyXG4gICAgICA8TG9uZ1RleHRGaWVsZCBuYW1lPVwicGFwTm90ZXNcIiAvPlxyXG4gICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJkb2NDb25zdWx0Rm9yUGFwXCIgLz5cclxuICAgIDwvRnJhZ21lbnQ+XHJcbiAgKSxcclxuICAgIFxyXG4gIFwiQnJlYXN0IEV4YW1cIjogKGluZm8pID0+IChcclxuICAgIDxGcmFnbWVudD5cclxuICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiYWJub3JtYWxpdGllc1wiIC8+XHJcbiAgICAgIDxEaXNwbGF5SWYgY29uZGl0aW9uPXtjb250ZXh0ID0+IGNvbnRleHQubW9kZWwuYWJub3JtYWxpdGllcyA9PT0gdHJ1ZX0+PEZyYWdtZW50PlxyXG4gICAgICAgIDxMb25nVGV4dEZpZWxkIG5hbWU9XCJhYkRlc2NyaWJlXCIgLz4gIFxyXG4gICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICA8Qm9vbEZpZWxkIG5hbWU9XCJmbmFjQ29tcGxldGVkXCIgLz5cclxuICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiZWR1Q29tcGxldGVkXCIgLz5cclxuICAgIDwvRnJhZ21lbnQ+XHJcbiAgKSxcclxuXHJcbiAgXCJXb21lbidzIEVkdVwiOiB7XHJcbiAgICBcIlByZS1Xb21lbidzIEVkdWNhdGlvbiBRdWl6XCI6IChpbmZvKSA9PiAoXHJcbiAgICAgIDxGcmFnbWVudD5cclxuICAgICAgICBDb21wbGV0ZWQgYnJlYXN0IGV4YW1pbmF0aW9uP1xyXG4gICAgICAgIDxCb29sRmllbGQgbmFtZT1cImJyZWFzdENvbXBsZXRlZFwiIC8+XHJcbiAgICAgICAgRnJvbSBhIHNjYWxlIG9mIDEtNSwgaG93IG11Y2ggZG8geW91IGtub3cgYWJvdXQgbWVuc3RydWFsIGN5Y2xlcz8gMSBiZWluZyBub3QgYXQgYWxsLCBhbmQgNSBiZWluZyBhIGxvdFxyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicHJlV29tZW5FZHVTdXJ2ZXkxXCIgLz5cclxuICAgICAgICBXaGljaCBvZiB0aGUgZm9sbG93aW5nIGlzL2FyZSBub3JtYWwgc3ltcHRvbShzKSBvZiBtZW5zdHJ1YWwgcGVyaW9kcz9cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInByZVdvbWVuRWR1UTFcIiAvPlxyXG4gICAgICAgIEFsbCBvZiB0aGUgZm9sbG93aW5nIGFyZSByZWFzb25zIGZvciBtaXNzZWQgcGVyaW9kcyBleGNlcHRcclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInByZVdvbWVuRWR1UTJcIiAvPlxyXG4gICAgICAgIFdoaWNoIG9mIHRoZSBmb2xsb3dpbmcgaXMgdHJ1ZSBhYm91dCBtZW5zdHJ1YXRpb25cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInByZVdvbWVuRWR1UTNcIiAvPlxyXG4gICAgICAgIFdoZW4gaXMgdGhlIGJlc3QgdGltZSB0byBkbyBhIGJyZWFzdCBzZWxmIGV4YW1pbmF0aW9uP1xyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicHJlV29tZW5FZHVRNFwiIC8+XHJcbiAgICAgICAgSG93IG9mdGVuIHNob3VsZCB5b3UgZG8gYSBicmVhc3Qgc2VsZiBleGFtaW5hdGlvbj9cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInByZVdvbWVuRWR1UTVcIiAvPlxyXG4gICAgICAgIFlvdSBzaG91bGQgZ28gdG8gdGhlIGRvY3RvciBpZiB5b3Ugbm90aWNlOlxyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicHJlV29tZW5FZHVRNlwiIC8+XHJcbiAgICAgIDwvRnJhZ21lbnQ+XHJcbiAgICApLFxyXG5cclxuICAgIFwiUG9zdC1Xb21lbidzIEVkdWNhdGlvbiBRdWl6XCI6IChpbmZvKSA9PiAoXHJcbiAgICAgIDxGcmFnbWVudD5cclxuICAgICAgICBGcm9tIGEgc2NhbGUgb2YgMS01LCBob3cgbXVjaCBkbyB5b3Uga25vdyBhYm91dCBtZW5zdHJ1YWwgY3ljbGVzPyAxIGJlaW5nIG5vdCBhdCBhbGwsIGFuZCA1IGJlaW5nIGEgbG90XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0V29tZW5FZHVTdXJ2ZXkxXCIgLz5cclxuICAgICAgICBXaGljaCBvZiB0aGUgZm9sbG93aW5nIGlzL2FyZSBub3JtYWwgc3ltcHRvbShzKSBvZiBtZW5zdHJ1YWwgcGVyaW9kcz9cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RXb21lbkVkdVExXCIgLz5cclxuICAgICAgICBBbGwgb2YgdGhlIGZvbGxvd2luZyBhcmUgcmVhc29ucyBmb3IgbWlzc2VkIHBlcmlvZHMgZXhjZXB0XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0V29tZW5FZHVRMlwiIC8+XHJcbiAgICAgICAgV2hpY2ggb2YgdGhlIGZvbGxvd2luZyBpcyB0cnVlIGFib3V0IG1lbnN0cnVhdGlvblxyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdFdvbWVuRWR1UTNcIiAvPlxyXG4gICAgICAgIFdoZW4gaXMgdGhlIGJlc3QgdGltZSB0byBkbyBhIGJyZWFzdCBzZWxmIGV4YW1pbmF0aW9uP1xyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdFdvbWVuRWR1UTRcIiAvPlxyXG4gICAgICAgIEhvdyBvZnRlbiBzaG91bGQgeW91IGRvIGEgYnJlYXN0IHNlbGYgZXhhbWluYXRpb24/XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0V29tZW5FZHVRNVwiIC8+XHJcbiAgICAgICAgWW91IHNob3VsZCBnbyB0byB0aGUgZG9jdG9yIGlmIHlvdSBub3RpY2U6XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0V29tZW5FZHVRNlwiIC8+XHJcbiAgICAgIDwvRnJhZ21lbnQ+XHJcbiAgICApLFxyXG4gIH0sXHJcblxyXG4gIFwiRG9jdG9ycycgQ29uc3VsdFwiOiAoaW5mbykgPT4gKFxyXG4gICAgPEZyYWdtZW50PlxyXG4gICAgICB7cmVxdWlyZURvY3RvckNvbnN1bHQoaW5mbyl9XHJcbiAgICAgIENoaWVmIGNvbXBsYWludFxyXG4gICAgICA8U2VsZWN0RmllbGQgbmFtZT1cImRvY0NvbnN1bHQxXCIgLz5cclxuICAgICAgPERpc3BsYXlJZiBjb25kaXRpb249e2NvbnRleHQgPT4gQXJyYXkuaXNBcnJheShjb250ZXh0Lm1vZGVsLmRvY0NvbnN1bHQxKSAmJiBjb250ZXh0Lm1vZGVsLmRvY0NvbnN1bHQxLmluY2x1ZGVzKCdPdGhlcnMgKGZyZWUgdGV4dCknKX0+PEZyYWdtZW50PlxyXG4gICAgICAgIE90aGVyIGNvbXBsYWludHNcclxuICAgICAgICA8VGV4dEZpZWxkIG5hbWU9XCJvdGhlckNvbXBsYWludHNcIiAvPlxyXG4gICAgICA8L0ZyYWdtZW50PjwvRGlzcGxheUlmPlxyXG4gICAgICBEb2N0b3JzJyBub3Rlcy9hZHZpY2VcclxuICAgICAgPExvbmdUZXh0RmllbGQgbmFtZT1cImRvY0NvbnN1bHQyXCIgLz5cclxuICAgICAgPEJvb2xGaWVsZCBuYW1lPVwiZG9jQ29uc3VsdDNcIiAvPlxyXG4gICAgICA8RGlzcGxheUlmIGNvbmRpdGlvbj17Y29udGV4dCA9PiBjb250ZXh0Lm1vZGVsLmRvY0NvbnN1bHQzID09PSB0cnVlfT48RnJhZ21lbnQ+XHJcbiAgICAgICAgUmVmZXJyYWwgZGV0YWlsc1xyXG4gICAgICAgIDxMb25nVGV4dEZpZWxkIG5hbWU9XCJkb2NDb25zdWx0NFwiIC8+XHJcbiAgICAgIDwvRnJhZ21lbnQ+PC9EaXNwbGF5SWY+XHJcbiAgICAgIE5hbWUgb2YgZG9jdG9yXHJcbiAgICAgIDxUZXh0RmllbGQgbmFtZT1cImRvY0NvbnN1bHQ1XCIgLz5cclxuICAgIDwvRnJhZ21lbnQ+XHJcbiAgKSxcclxuXHJcbiAgXCJFeWUgU2NyZWVuaW5nXCI6IChpbmZvKSA9PiAoXHJcbiAgICA8RnJhZ21lbnQ+XHJcbiAgICAgIDxCb29sRmllbGQgbmFtZT1cInNwZWNzXCIgLz5cclxuICAgICAgPFRleHRGaWVsZCBuYW1lPVwicmlnaHRXb0dsYXNzXCIgLz5cclxuICAgICAgPFRleHRGaWVsZCBuYW1lPVwibGVmdFdvR2xhc3NcIiAvPlxyXG4gICAgICA8VGV4dEZpZWxkIG5hbWU9XCJyaWdodFdpR2xhc3NcIiAvPlxyXG4gICAgICA8VGV4dEZpZWxkIG5hbWU9XCJsZWZ0V2lHbGFzc1wiIC8+XHJcbiAgICAgIDxUZXh0RmllbGQgbmFtZT1cInJpZ2h0TmVhclZpc1wiIC8+XHJcbiAgICAgIDxUZXh0RmllbGQgbmFtZT1cImxlZnROZWFyVmlzXCIgLz5cclxuICAgICAgPExvbmdUZXh0RmllbGQgbmFtZT1cImxpZHNcIiAvPlxyXG4gICAgICA8TG9uZ1RleHRGaWVsZCBuYW1lPVwiY29uanVuY3RpdmFcIiAvPlxyXG4gICAgICA8TG9uZ1RleHRGaWVsZCBuYW1lPVwiY29ybmVhXCIgLz5cclxuICAgICAgPExvbmdUZXh0RmllbGQgbmFtZT1cImFudFNlZ1wiIC8+XHJcbiAgICAgIDxMb25nVGV4dEZpZWxkIG5hbWU9XCJpcmlzXCIgLz5cclxuICAgICAgPExvbmdUZXh0RmllbGQgbmFtZT1cInB1cGlsXCIgLz5cclxuICAgICAgPExvbmdUZXh0RmllbGQgbmFtZT1cImxlbnNcIiAvPlxyXG4gICAgICA8TG9uZ1RleHRGaWVsZCBuYW1lPVwib2N1TXZtdFwiIC8+XHJcbiAgICAgIDxMb25nVGV4dEZpZWxkIG5hbWU9XCJpb3BcIiAvPlxyXG4gICAgICA8TG9uZ1RleHRGaWVsZCBuYW1lPVwiZHVjdFwiIC8+XHJcbiAgICAgIDxMb25nVGV4dEZpZWxkIG5hbWU9XCJjZHJcIiAvPlxyXG4gICAgICA8TG9uZ1RleHRGaWVsZCBuYW1lPVwibWFjdWxhXCIgLz5cclxuICAgICAgPExvbmdUZXh0RmllbGQgbmFtZT1cInJldGluYVwiIC8+XHJcbiAgICAgIDxMb25nVGV4dEZpZWxkIG5hbWU9XCJkaWFnbm9zaXNcIiAvPlxyXG4gICAgICA8TG9uZ1RleHRGaWVsZCBuYW1lPVwiYWR2aWNlXCIgLz5cclxuICAgICAgPExvbmdUZXh0RmllbGQgbmFtZT1cIm5hbWVEb2NcIiAvPlxyXG4gICAgPC9GcmFnbWVudD5cclxuICApLFxyXG5cclxuICBcIkVkdWNhdGlvblwiIDoge1xyXG4gICAgXCJQcmUtRWR1Y2F0aW9uIFN1cnZleVwiOiAoaW5mbykgPT4gKFxyXG4gICAgICA8RnJhZ21lbnQ+XHJcbiAgICAgICAge3JlcXVpcmVEb2N0b3JDb25zdWx0KGluZm8pfVxyXG4gICAgICAgIEZyb20gYSBzY2FsZSBvZiAxLTUsIGhvdyBtdWNoIGRvIHlvdSBrbm93IGFib3V0IG1ldGFib2xpYyBzeW5kcm9tZSAoSHlwZXJ0ZW5zaW9uLCBIeXBlcmxpcGlkZW1pYSwgT2Jlc2l0eSwgSGlnaCBCbG9vZCBTdWdhcik/XHJcbiAgICAgICAgMSBiZWluZyBub3QgYXQgYWxsLCBhbmQgNSBiZWluZyBhIGxvdFxyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicHJlRWR1U3VydmV5MVwiIC8+XHJcbiAgICAgICAgRnJvbSBhIHNjYWxlIG9mIDEtNSwgaG93IG11Y2ggZG8geW91IGtub3cgYWJvdXQgaGVhbHRoeSBsaWZlc3R5bGUgYW5kIGRpZXQ/XHJcbiAgICAgICAgMSBiZWluZyBub3QgYXQgYWxsLCBhbmQgNSBiZWluZyBhIGxvdFxyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicHJlRWR1U3VydmV5MlwiIC8+XHJcbiAgICAgICAgRnJvbSBhIHNjYWxlIG9mIDEtNSwgaG93IG11Y2ggZG8geW91IGtub3cgYWJvdXQgY2FuY2VyIHJpc2sgZmFjdG9ycz9cclxuICAgICAgICAxIGJlaW5nIG5vdCBhdCBhbGwsIGFuZCA1IGJlaW5nIGEgbG90XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwcmVFZHVTdXJ2ZXkzXCIgLz5cclxuICAgICAgICBGcm9tIGEgc2NhbGUgb2YgMS01LCBob3cgbXVjaCBkbyB5b3Uga25vdyBhYm91dCBnb29kIGV5ZWNhcmUgaGFiaXRzP1xyXG4gICAgICAgIDEgYmVpbmcgbm90IGF0IGFsbCwgYW5kIDUgYmVpbmcgYSBsb3RcclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInByZUVkdVN1cnZleTRcIiAvPlxyXG4gICAgICA8L0ZyYWdtZW50PlxyXG4gICAgKSxcclxuXHJcbiAgICBcIlByZS1FZHVjYXRpb24gUXVpelwiOiAoaW5mbykgPT4gKFxyXG4gICAgICA8RnJhZ21lbnQ+XHJcbiAgICAgICAge3JlcXVpcmVEb2N0b3JDb25zdWx0KGluZm8pfVxyXG4gICAgICAgIDxEaXZpZGVyIHZhcmlhbnQ9XCJtaWRkbGVcIi8+XHJcbiAgICAgICAgWW91IGFyZSBhdCBoaWdoZXIgcmlzayBvZiBkZXZlbG9waW5nIGhpZ2ggY2hvbGVzdGVyb2wgaWYgeW91XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwcmVFZHVRdWl6MVwiIC8+XHJcbiAgICAgICAgQWxsIG9mIHRoZSBmb2xsb3dpbmcgYXJlIGNvbXBsaWNhdGlvbnMgb2YgZGlhYmV0ZXMgZXhjZXB0XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwcmVFZHVRdWl6MlwiIC8+XHJcbiAgICAgICAgSG93IG11Y2ggZXhlcmNpc2Ugc2hvdWxkIHdlIGdldCBhIHdlZWs/XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwcmVFZHVRdWl6M1wiIC8+XHJcbiAgICAgICAgV2hhdCBtYWtlcyB1cCBhIGhlYWx0aHkgcGxhdGU/XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwcmVFZHVRdWl6NFwiIC8+XHJcbiAgICAgICAgV2hpY2ggb2YgdGhlIGZvbGxvd2luZyBpcyB0aGUgaGVhbHRoaWVyIGNob2ljZSB0byBtYWtlP1xyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicHJlRWR1UXVpejVcIiAvPlxyXG4gICAgICAgIFdoaWNoIG9mIHRoZSBmb2xsb3dpbmcgaXMgYSBjYW5jZXIgcmlzayBmYWN0b3Iocyk/XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwcmVFZHVRdWl6NlwiIC8+XHJcbiAgICAgICAgV2hpY2ggb2YgdGhlIGZvbGxvd2luZyBpcyBub3QgY29uc2lkZXJlZCBnb29kIGV5ZWNhcmUgaGFiaXRzP1xyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicHJlRWR1UXVpejdcIiAvPlxyXG4gICAgICA8L0ZyYWdtZW50PlxyXG4gICAgKSxcclxuXHJcbiAgICBcIlBvc3QtRWR1Y2F0aW9uIFN1cnZleVwiOiAoaW5mbykgPT4gKFxyXG4gICAgICA8RnJhZ21lbnQ+XHJcbiAgICAgICAge3JlcXVpcmVEb2N0b3JDb25zdWx0KGluZm8pfVxyXG4gICAgICAgIEZyb20gYSBzY2FsZSBvZiAxLTUsIGhvdyBtdWNoIGRvIHlvdSBrbm93IGFib3V0IG1ldGFib2xpYyBzeW5kcm9tZSAoSHlwZXJ0ZW5zaW9uLCBIeXBlcmxpcGlkZW1pYSwgT2Jlc2l0eSwgSGlnaCBCbG9vZCBTdWdhcik/XHJcbiAgICAgICAgMSBiZWluZyBub3QgYXQgYWxsLCBhbmQgNSBiZWluZyBhIGxvdFxyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdEVkdVN1cnZleTFcIiAvPlxyXG4gICAgICAgIEZyb20gYSBzY2FsZSBvZiAxLTUsIGhvdyBtdWNoIGRvIHlvdSBrbm93IGFib3V0IGhlYWx0aHkgbGlmZXN0eWxlIGFuZCBkaWV0P1xyXG4gICAgICAgIDEgYmVpbmcgbm90IGF0IGFsbCwgYW5kIDUgYmVpbmcgYSBsb3RcclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RFZHVTdXJ2ZXkyXCIgLz5cclxuICAgICAgICBGcm9tIGEgc2NhbGUgb2YgMS01LCBob3cgbXVjaCBkbyB5b3Uga25vdyBhYm91dCBjYW5jZXIgcmlzayBmYWN0b3JzP1xyXG4gICAgICAgIDEgYmVpbmcgbm90IGF0IGFsbCwgYW5kIDUgYmVpbmcgYSBsb3RcclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RFZHVTdXJ2ZXkzXCIgLz5cclxuICAgICAgICBGcm9tIGEgc2NhbGUgb2YgMS01LCBob3cgbXVjaCBkbyB5b3Uga25vdyBhYm91dCBnb29kIGV5ZWNhcmUgaGFiaXRzP1xyXG4gICAgICAgIDEgYmVpbmcgbm90IGF0IGFsbCwgYW5kIDUgYmVpbmcgYSBsb3RcclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RFZHVTdXJ2ZXk0XCIgLz5cclxuICAgICAgPC9GcmFnbWVudD5cclxuICAgICksXHJcblxyXG4gICAgXCJQb3N0LUVkdWNhdGlvbiBRdWl6XCI6IChpbmZvKSA9PiAoXHJcbiAgICAgIDxGcmFnbWVudD5cclxuICAgICAgICB7cmVxdWlyZURvY3RvckNvbnN1bHQoaW5mbyl9XHJcbiAgICAgICAgWW91IGFyZSBhdCBoaWdoZXIgcmlzayBvZiBkZXZlbG9waW5nIGhpZ2ggY2hvbGVzdGVyb2wgaWYgeW91XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0RWR1UXVpejFcIiAvPlxyXG4gICAgICAgIEFsbCBvZiB0aGUgZm9sbG93aW5nIGFyZSBjb21wbGljYXRpb25zIG9mIGRpYWJldGVzIGV4Y2VwdFxyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdEVkdVF1aXoyXCIgLz5cclxuICAgICAgICBIb3cgbXVjaCBleGVyY2lzZSBzaG91bGQgd2UgZ2V0IGEgd2Vlaz9cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RFZHVRdWl6M1wiIC8+XHJcbiAgICAgICAgV2hhdCBtYWtlcyB1cCBhIGhlYWx0aHkgcGxhdGU/XHJcbiAgICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0RWR1UXVpejRcIiAvPlxyXG4gICAgICAgIFdoaWNoIG9mIHRoZSBmb2xsb3dpbmcgaXMgdGhlIGhlYWx0aGllciBjaG9pY2UgdG8gbWFrZT9cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RFZHVRdWl6NVwiIC8+XHJcbiAgICAgICAgV2hpY2ggb2YgdGhlIGZvbGxvd2luZyBpcyBhIGNhbmNlciByaXNrIGZhY3RvcihzKT9cclxuICAgICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RFZHVRdWl6NlwiIC8+XHJcbiAgICAgICAgV2hpY2ggb2YgdGhlIGZvbGxvd2luZyBpcyBub3QgY29uc2lkZXJlZCBnb29kIGV5ZWNhcmUgaGFiaXRzP1xyXG4gICAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdEVkdVF1aXo3XCIgLz5cclxuICAgICAgPC9GcmFnbWVudD5cclxuICAgICksXHJcbiAgfSxcclxuXHJcbiAgXCJQb3N0LVNjcmVlbmluZyBGZWVkYmFja1wiOiAoaW5mbykgPT4gKFxyXG4gICAgPEZyYWdtZW50PlxyXG4gICAgICBJIGhhdmUgaGFkIGEgZ29vZCBleHBlcmllbmNlIGF0IHRoZSBzY3JlZW5pbmdcclxuICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0U2NyZWVuaW5nRmVlZGJhY2sxXCIgLz5cclxuICAgICAgSSBjYW1lIGZvciB0aGUgc2NyZWVuaW5nIGJlY2F1c2U6IChTZWxlY3QgYWxsIHRoYXQgYXBwbHkpXHJcbiAgICAgIDxBdXRvRmllbGQgbmFtZT1cInBvc3RTY3JlZW5pbmdGZWVkYmFjazJcIiAvPlxyXG4gICAgICBJIGtub3cgdGhhdCByZWd1bGFyIGhlYWx0aCBzY3JlZW5pbmcgaXMgaW1wb3J0YW50XHJcbiAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrM1wiIC8+XHJcbiAgICAgIEkga25vdyB0aGF0IGl0IGlzIGltcG9ydGFudCB0byBkZXRlY3QgY2hyb25pYyBkaXNlYXNlcyBhbmQgY2FuY2VycyBlYXJseVxyXG4gICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RTY3JlZW5pbmdGZWVkYmFjazRcIiAvPlxyXG4gICAgICBJIGFtIHdpbGxpbmcgdG8gdGFrZSB0aGUgdHJvdWJsZSB0byBhdHRlbmQgaGVhbHRoIHNjcmVlbmluZ3NcclxuICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0U2NyZWVuaW5nRmVlZGJhY2s1XCIgLz5cclxuICAgICAgSSBhbSB3aWxsaW5nIHRvIGF0dGVuZCBteSBmb2xsb3ctdXAgc2Vzc2lvbnNcclxuICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0U2NyZWVuaW5nRmVlZGJhY2s2XCIgLz5cclxuICAgICAgVGhlIHN0dWRlbnQgdm9sdW50ZWVycyBhdHRlbmRlZCB0byBteSBuZWVkc1xyXG4gICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RTY3JlZW5pbmdGZWVkYmFjazdcIiAvPlxyXG4gICAgICBUaGUgc3R1ZGVudCB2b2x1bnRlZXJzIHdlcmUgd2VsbC10cmFpbmVkXHJcbiAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrOFwiIC8+XHJcbiAgICAgIFRoZSB3YWl0aW5nIHRpbWUgdG8gZW50ZXIgdGhlIHNjcmVlbmluZyB3YXMgcmVhc29uYWJsZVxyXG4gICAgICA8U2VsZWN0RmllbGQgbmFtZT1cInBvc3RTY3JlZW5pbmdGZWVkYmFjazlcIiAvPlxyXG4gICAgICBUaGUgd2FpdGluZyB0aW1lIGZvciBlYWNoIHN0YXRpb24gd2FzIHJlYXNvbmFibGVcclxuICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0U2NyZWVuaW5nRmVlZGJhY2sxMFwiIC8+XHJcbiAgICAgIFRoZSBmbG93IG9mIHRoZSBzY3JlZW5pbmcgd2FzIGVhc3kgdG8gZm9sbG93XHJcbiAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTFcIiAvPlxyXG4gICAgICBJIHdvdWxkIHJlY29tbWVuZCBteSBmYW1pbHkvZnJpZW5kcyB0byBhdHRlbmQgdGhpcyBzY3JlZW5pbmdcclxuICAgICAgPFNlbGVjdEZpZWxkIG5hbWU9XCJwb3N0U2NyZWVuaW5nRmVlZGJhY2sxMlwiIC8+XHJcbiAgICAgIFdoYXQgZW5jb3VyYWdlZCB5b3UgdG8gY29tZSBmb3Igb3VyIGV2ZW50PyBTZWxlY3QgYWxsIHRoYXQgYXBwbHlcclxuICAgICAgPEF1dG9GaWVsZCBuYW1lPVwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTNcIiAvPlxyXG4gICAgICBIb3cgb2Z0ZW4gZG8geW91IGF0dGVuZCBhIGhlYWx0aCBzY3JlZW5pbmc/XHJcbiAgICAgIDxTZWxlY3RGaWVsZCBuYW1lPVwicG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTRcIiAvPlxyXG4gICAgPC9GcmFnbWVudD5cclxuICApLFxyXG4gIFxyXG5cclxufTsiLCJpbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XHJcblxyXG5pbXBvcnQgUGF0aWVudGluZm8gZnJvbSAnL2ltcG9ydHMvYXBpL3BhdGllbnRpbmZvJztcclxuXHJcbi8vIEN1c3RvbWlzZSB2YWxpZGF0aW9uIGVycm9yIG1lc3NhZ2VzXHJcblNpbXBsZVNjaGVtYS5zZXREZWZhdWx0TWVzc2FnZXMoe1xyXG4gIG1lc3NhZ2VzOiB7XHJcbiAgICBlbjoge1xyXG4gICAgICBcIklEbm90VW5pcXVlXCI6IFwiSUQgaXMgYWxyZWFkeSByZWdpc3RlcmVkXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pO1xyXG5cclxuLy8gRGVmaW5lIHRoZSBzY2hlbWFcclxuZXhwb3J0IGNvbnN0IGZvcm1TY2hlbWFzID0ge1xyXG4gIFwiUmVnaXN0cmF0aW9uXCI6e1xyXG4gICAgXCJQYXRpZW50IEluZm9cIjpcclxuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xyXG4gICAgICBuYW1lOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIHJlZ0V4OiAvXlxcRCskLyxcclxuICAgICAgICBsYWJlbDogXCJOYW1lXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIC8vIGlkOiB7XHJcbiAgICAgIC8vICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAvLyAgIHJlZ0V4OiAvXlswLTldKyQvLFxyXG4gICAgICAvLyB9LFxyXG4gICAgICBnZW5kZXI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydtYWxlJywgJ2ZlbWFsZSddLFxyXG4gICAgICB9LFxyXG4gICAgICBiaXJ0aGRheToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICByZWdFeDogL15bMC05XXsxLDJ9XFwvWzAtOV17MSwyfVxcL1sxLTJdWzAtOV17M30kLyxcclxuICAgICAgfSxcclxuICAgICAgYWdlOiB7XHJcbiAgICAgICAgdHlwZTogU2ltcGxlU2NoZW1hLkludGVnZXIsXHJcbiAgICAgICAgbWluOiAwLFxyXG4gICAgICAgIGF1dG9WYWx1ZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgY29uc3QgYmlydGhkYXRlID0gdGhpcy5zaWJsaW5nRmllbGQoXCJiaXJ0aGRheVwiKS52YWx1ZTtcclxuICAgICAgICAgIGNvbnN0IGN1cnJlbnRZZWFyID0gbmV3IERhdGUoKTtcclxuICAgICAgICAgIGNvbnN0IGJpcnRoWWVhciA9IE51bWJlcihiaXJ0aGRhdGUuc3Vic3RyaW5nKGJpcnRoZGF0ZS5sZW5ndGgtNCxiaXJ0aGRhdGUubGVuZ3RoKSk7XHJcbiAgICAgICAgICBjb25zdCBhZ2UgPSBjdXJyZW50WWVhci5nZXRGdWxsWWVhcigpIC0gYmlydGhZZWFyO1xyXG4gICAgICAgICAgcmV0dXJuIGFnZVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgZGlzdHJpY3Q6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIH0sXHJcbiAgICAgIGFkZHJlc3M6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIH0sXHJcbiAgICAgIHppcGNvZGU6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgcmVnRXg6IC9eWzAtOV0rJC8sXHJcbiAgICAgIH0sXHJcbiAgICAgIGNvbnRhY3ROdW1iZXI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgcmVnRXg6IC9eWzAtOV0rJC8sXHJcbiAgICAgIH0sXHJcbiAgICAgIHNwb2tlbkxhbmd1YWdlczoge1xyXG4gICAgICAgIHR5cGU6IEFycmF5LFxyXG4gICAgICB9LFxyXG4gICAgICAnc3Bva2VuTGFuZ3VhZ2VzLiQnOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU2FtYmFscHVyaScsICdPZGlhJywgJ0VuZ2xpc2gnLCAnT3RoZXJzJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIHdyaXR0ZW5MYW5ndWFnZXM6IHtcclxuICAgICAgICB0eXBlOiBBcnJheSxcclxuICAgICAgfSxcclxuICAgICAgJ3dyaXR0ZW5MYW5ndWFnZXMuJCc6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydTYW1iYWxwdXJpJywgJ09kaWEnLCAnRW5nbGlzaCcsICdPdGhlcnMnXSxcclxuICAgICAgfSxcclxuICAgICAgYW55RHJ1Z0FsbGVyZ2llczoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsICdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBkcnVnQWxsZXJnaWVzOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBwcmVnbmFudDoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsICdObyddLFxyXG4gICAgICB9XHJcbiAgICB9KSxcclxuXHJcbiAgICBcIlBhdGllbnQgUHJvZmlsaW5nXCI6XHJcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcclxuICAgICAgcGF0aWVudFByb2ZpbGUxOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgJ05vJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgcGF0aWVudFByb2ZpbGUyOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnV2l0aGluIHBhc3QgMyB5ZWFycycsICdNb3JlIHRoYW4gMyB5ZWFycyBhZ28nXSwgICBcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICBwYXRpZW50UHJvZmlsZTM6IHtcclxuICAgICAgICB0eXBlOiBBcnJheSxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgJ3BhdGllbnRQcm9maWxlMy4kJzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0luY3JlYXNlZCB1cmluYXRpb24nLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0luY3JlYXNlZCB0aGlyc3QnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ1dlaWdodCBsb3NzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdJbmNyZWFzZWQgaHVuZ2VyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0luY3JlYXNlZCB0aXJlZG5lc3MnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnQmx1cnJlZCB2aXNpb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnU2xvdy1oZWFsaW5nIHdvdW5kcycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdOdW1ibmVzcy90aW5nbGluZyBpbiBoYW5kcyBhbmQvb3IgZmVldCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdOb25lIG9mIHRoZSBhYm92ZSdcclxuICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgfSxcclxuICAgICAgcGF0aWVudFByb2ZpbGU0OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnUmVndWxhciAoSW50ZXJ2YWwgb2YgNiBtb250aHMgb3IgbGVzcyknLCAnT2NjYXNpb25hbGx5IChJbnRlcnZhbCBvZiBtb3JlIHRoYW4gNiBtb250aHMpJywnU2VsZG9tIChsYXN0IGFwcG9pbnRtZW50IHdhcyA+MSB5ZWFyIGFnbyknLCdOb3QgYXQgYWxsJ10sICAgXHJcbiAgICAgIH0sXHJcbiAgICAgIGFueVdlc3Rlcm5NZWRpY2luZToge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiWWVzLCBXZXN0ZXJuIG1lZGljaW5lXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHdlc3Rlcm5NZWRpY2luZToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgYW55VHJhZGl0aW9uYWxNZWRpY2luZToge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiWWVzLCBUcmFkaXRpb25hbCBtZWRpY2luZVwiLFxyXG4gICAgICB9LFxyXG4gICAgICB0cmFkaXRpb25hbE1lZGljaW5lOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBwYXRpZW50UHJvZmlsZTY6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWycwJywgJzEtMycsJzQtNicsJz4gb3IgZXF1YWwgdG8gNyddLCAgIFxyXG4gICAgICB9LFxyXG4gICAgICBoeXBlcmxpcGlkZW1pYVExOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgJ05vJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgaHlwZXJsaXBpZGVtaWFRMjoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1dpdGhpbiBwYXN0IDMgeWVhcnMnLCAnTW9yZSB0aGFuIDMgeWVhcnMgYWdvJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgaHlwZXJsaXBpZGVtaWFRMzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1JlZ3VsYXIgKEludGVydmFsIG9mIDYgbW9udGhzIG9yIGxlc3MpJywgJ09jY2FzaW9uYWxseSAoSW50ZXJ2YWwgb2YgbW9yZSB0aGFuIDYgbW9udGhzKScsJ1NlbGRvbSAobGFzdCBhcHBvaW50bWVudCB3YXMgPjEgeWVhciBhZ28pJywnTm90IGF0IGFsbCddLCAgIFxyXG4gICAgICB9LFxyXG4gICAgICBoeXBlcmxpcGlkZW1pYUFueVdlc3Rlcm5NZWRpY2luZToge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiWWVzLCBXZXN0ZXJuIG1lZGljaW5lXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIGh5cGVybGlwaWRlbWlhV2VzdGVybk1lZGljaW5lOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBoeXBlcmxpcGlkZW1pYUFueVRyYWRpdGlvbmFsTWVkaWNpbmU6IHtcclxuICAgICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGxhYmVsOiBcIlllcywgVHJhZGl0aW9uYWwgbWVkaWNpbmVcIixcclxuICAgICAgfSxcclxuICAgICAgaHlwZXJsaXBpZGVtaWFUcmFkaXRpb25hbE1lZGljaW5lOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBoeXBlcmxpcGlkZW1pYVE1OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnMCcsICcxLTMnLCc0LTYnLCc+IG9yIGVxdWFsIHRvIDcnXSwgICBcclxuICAgICAgfSxcclxuICAgICAgaHlwZXJ0ZW5zaW9uUTE6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCAnTm8nXSwgICBcclxuICAgICAgICB9LFxyXG4gICAgICBoeXBlcnRlbnNpb25RMjoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1dpdGhpbiBwYXN0IDMgeWVhcnMnLCAnTW9yZSB0aGFuIDMgeWVhcnMgYWdvJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgaHlwZXJ0ZW5zaW9uUTM6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydSZWd1bGFyIChJbnRlcnZhbCBvZiA2IG1vbnRocyBvciBsZXNzKScsICdPY2Nhc2lvbmFsbHkgKEludGVydmFsIG9mIG1vcmUgdGhhbiA2IG1vbnRocyknLCdTZWxkb20gKGxhc3QgYXBwb2ludG1lbnQgd2FzID4xIHllYXIgYWdvKScsJ05vdCBhdCBhbGwnXSwgICBcclxuICAgICAgfSxcclxuICAgICAgaHlwZXJ0ZW5zaW9uQW55V2VzdGVybk1lZGljaW5lOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJZZXMsIFdlc3Rlcm4gbWVkaWNpbmVcIixcclxuICAgICAgfSxcclxuICAgICAgaHlwZXJ0ZW5zaW9uV2VzdGVybk1lZGljaW5lOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBoeXBlcnRlbnNpb25BbnlUcmFkaXRpb25hbE1lZGljaW5lOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJZZXMsIFRyYWRpdGlvbmFsIG1lZGljaW5lXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIGh5cGVydGVuc2lvblRyYWRpdGlvbmFsTWVkaWNpbmU6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICAgIGh5cGVydGVuc2lvblE1OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnMCcsICcxLTMnLCc0LTYnLCc+IG9yIGVxdWFsIHRvIDcnXSwgICBcclxuICAgICAgfSxcclxuICAgICAgVEJRMToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsJ05vJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIFRCUTI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMsIHRoZSBwZXJzb24gd2FzIGRpYWdub3NlZCB3aXRoIFRCIHdpdGhpbiB0aGUgcGFzdCA0IG1vbnRocycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnWWVzLCB0aGUgcGVyc29uIHdhcyBkaWFnbm9zZWQgd2l0aCBUQiBtb3JlIHRoYW4gNCBtb250aHMgYWdvJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIFRCUTM6IHtcclxuICAgICAgICB0eXBlOiBBcnJheSxcclxuICAgICAgfSxcclxuICAgICAgJ1RCUTMuJCc6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydDb3VnaCB0aGF0IGhhcyBsYXN0ZWQgbW9yZSB0aGFuIDIgd2Vla3MnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0NvdWdoaW5nIHVwIGJsb29kJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdCcmVhdGhsZXNzbmVzcycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnV2VpZ2h0IGxvc3MnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTmlnaHQgc3dlYXRzJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0ZldmVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0xvc3Mgb2YgYXBwZXRpdGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTm9uZSBvZiB0aGUgYWJvdmUnXSxcclxuICAgICAgfSxcclxuICAgICAgbWVkaWNhbEhpc3RvcnkxOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICB9LFxyXG4gICAgICBtZWRpY2FsSGlzdG9yeTI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIH0sXHJcbiAgICAgIG1lZGljYWxIaXN0b3J5Mzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgfSxcclxuICAgICAgbWVkaWNhbEhpc3Rvcnk0OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICB9LFxyXG4gICAgICBtZWRpY2FsSGlzdG9yeTU6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIH0sXHJcbiAgICAgIHN1cmdBbmRIb3NwUTE6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBzdXJnQW5kSG9zcFEyOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBzdXJnQW5kSG9zcFEzOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywnTm8nXSxcclxuICAgICAgfSxcclxuICAgICAgc3VyZ0FuZEhvc3BRNDoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgb2N1bGFySGlzUTFhOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywnTm8nXSxcclxuICAgICAgfSxcclxuICAgICAgb2N1bGFySGlzUTFiOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBvY3VsYXJIaXNRMmE6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBvY3VsYXJIaXNRMmI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICAgIG9jdWxhckhpc1EzYToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsJ05vJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIG9jdWxhckhpc1EzYjoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgb2N1bGFySGlzUTNjOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBvY3VsYXJIaXNRM2Q6IHtcclxuICAgICAgICB0eXBlOiBBcnJheSxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgJ29jdWxhckhpc1EzZC4kJzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0NhdGFyYWN0JywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdHbGF1Y29tYScsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnRGlhYmV0aWMgUmV0aW5vcGF0aHknLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0FnZS1yZWxhdGVkIE1hY3VsYXIgRGVnZW5lcmF0aW9uJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ090aGVycyAocGxlYXNlIHNwZWNpZnkpJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIG90aGVyT2N1bGFyQ29uZDp7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBvY3VsYXJIaXNRNDoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsJ05vJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIG9jdWxhckhpc1E1YToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ05vcm1hbCcsJ0dvb2QgZW5vdWdoIGZvciBteSBkYWlseSBhY3Rpdml0aWVzJywnUG9vciddLFxyXG4gICAgICB9LFxyXG4gICAgICBvY3VsYXJIaXNRNWI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBvY3VsYXJIaXNRNWM6IHtcclxuICAgICAgICB0eXBlOiBBcnJheSxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgJ29jdWxhckhpc1E1Yy4kJzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0NvbmNlcm5zIGFib3V0IGZpbmFuY2VzJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ1RvbyBmYXIgYXdheS9kaWZmaWN1bHQgdG8gZ2V0IHRvIHRoZSBjbGluaWMvaG9zcGl0YWwnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnUHJldmlvdXNseSB0b2xkIGJ5IGV5ZSBzcGVjaWFsaXN0IHRoYXQgbm90aGluZyBjYW4gYmUgZG9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdOb3RoaW5nIGNhbiBiZSBkb25lIGFzIGl0IGlzIHBhcnQgb2YgYWdlaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ090aGVycyAocGxlYXNlIHNwZWNpZnkpJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIG90aGVyUmVhc29uczoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgYmFycmllclExOntcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydIb3NwaXRhbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdDbGluaWNzJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ1RyYWRpdGlvbmFsIE1lZGljaW5lJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ1NlbGRvbS9OZXZlciB2aXNpdHMgdGhlIGRvY3RvciddLFxyXG4gICAgICB9LFxyXG4gICAgICBub05lZWQ6IHtcclxuICAgICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGxhYmVsOiBcIkRvIG5vdCBzZWUgdGhlIG5lZWQgZm9yIHRoZSB0ZXN0c1wiLFxyXG4gICAgICB9LFxyXG4gICAgICB0aW1lOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJDaGFsbGVuZ2luZyB0byBtYWtlIHRpbWUgdG8gZ28gZm9yIGFwcG9pbnRtZW50c1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBtb2JpbGl0eToge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiRGlmZmljdWx0eSBnZXR0aW5nIHRvIGNsaW5pYyAobW9iaWxpdHkpXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIGZpbmFuY2lhbDoge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiRmluYW5jaWFsIGlzc3Vlc1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBzY2FyZWQ6IHtcclxuICAgICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGxhYmVsOiBcIlNjYXJlZCBvZiBkb2N0b3JcIixcclxuICAgICAgfSxcclxuICAgICAgcHJlZmVyVHJhZE1lZDoge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiUHJlZmVyIHRyYWRpdGlvbmFsIG1lZGljaW5lXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIGFueU90aGVyQmFycmllcnM6IHtcclxuICAgICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGxhYmVsOiBcIk90aGVyczogKGZyZWUgdGV4dClcIixcclxuICAgICAgfSxcclxuICAgICAgb3RoZXJCYXJyaWVyczoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgZmFtaWx5SGlzdG9yeToge1xyXG4gICAgICAgIHR5cGU6IEFycmF5LFxyXG4gICAgICB9LFxyXG4gICAgICAnZmFtaWx5SGlzdG9yeS4kJzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0hpZ2ggYmxvb2QgcHJlc3N1cmUnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0hpZ2ggYmxvb2QgY2hvbGVzdGVyb2wnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0hlYXJ0IGF0dGFjayBvciBjb3JvbmFyeSBhcnRlcmlhbCBkaXNlYXNlIChuYXJyb3dlZCBibG9vZCB2ZXNzZWwgc3VwcGx5aW5nIHRoZSBoZWFydCkqJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdTdHJva2UnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnRGlhYmV0ZXMnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnQ2FuY2VyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vLCB0aGV5IGRvIG5vdCBoYXZlIGFueSBvZiB0aGUgYWJvdmUnXSxcclxuICAgICAgfSxcclxuICAgICAgRkxSU1ExOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICB9LFxyXG4gICAgICBGTFJTUTI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBGTFJTUTM6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIH0sXHJcbiAgICAgIEZMUlNRNDoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsJ05vJywnVW5zdXJlJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIEZMUlNRNToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsJ05vJ10sICAgICAgXHJcbiAgICAgIH0sXHJcbiAgICAgIEZMUlNRNjoge1xyXG4gICAgICAgIHR5cGU6IEFycmF5LFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICAnRkxSU1E2LiQnOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnQ2lnYXJldHRlJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdCZWVkaScsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnVG9iYWNjbycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnT3BpdW0nXSxcclxuICAgICAgfSxcclxuICAgICAgRkxSU1E3OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnTGVzcyB0aGFuIDEgY2lnYXJldHRlIChvciBlcXVpdmFsZW50KSBwZXIgZGF5IG9uIGF2ZXJhZ2UnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnQmV0d2VlbiAxIHRvIDEwIGNpZ2FyZXR0ZXMgKG9yIGVxdWl2YWxlbnQpIHBlciBkYXkgb24gYXZlcmFnZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdNb3JlIHRoYW4gMTAgY2lnYXJldHRlcyAob3IgZXF1aXZhbGVudCkgcGVyIGRheSBvbiBhdmVyYWdlJ10sICAgICAgXHJcbiAgICAgIH0sICAgIFxyXG4gICAgICBGTFJTUTg6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICAgIEZMUlNROToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0kgaGF2ZSBzdG9wcGVkIHNtb2tpbmcgY29tcGxldGVseScsJ0kgaGF2ZSBuZXZlciBzbW9rZWQgYmVmb3JlJ10sICAgICAgXHJcbiAgICAgIH0sXHJcbiAgICAgIEZMUlNRMTA6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCdObyddLCAgICAgIFxyXG4gICAgICB9LFxyXG4gICAgICBzb2NpYWxIaXNRMToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsJ05vJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIHNvY2lhbEhpc1EyOiB7XHJcbiAgICAgICAgdHlwZTogTnVtYmVyLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICBzdHVkZW50OiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJTdHVkZW50XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIGhvdXNld2lmZToge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiSG9tZW1ha2VyL0hvdXNld2lmZVwiLFxyXG4gICAgICB9LFxyXG4gICAgICByZWxpZzp7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJSZWxpZ2lvdXMgV29ya1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBwcm9mOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJQcm9mZXNzaW9uYWwgKHRlYWNoZXIsIGVuZ2luZWVyLCBhcmNoaXRlY3QsIGRvY3RvciwgbnVyc2UsIGxhd3llciwgbWFuYWdlbWVudCwgZmluYW5jZSwgZXRjKVwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzZXJ2aWNlOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJTZXJ2aWNlIGluZHVzdHJ5IChlLmcuIHJlc3RhdXJhbnQgc2VydmVyLCBjYWxsIGNlbnRyZSwgcmVjZXB0aW9uaXN0LCBob3RlbCBzdGFmZilcIixcclxuICAgICAgfSxcclxuICAgICAgbWFudWFsOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJNYW51YWwgbGFib3VyZXIgKGUuZy4gY29uc3RydWN0aW9uLCBjbGVhbmluZywgY2xvdGhlcyB3YXNoaW5nKVwiLFxyXG4gICAgICB9LFxyXG4gICAgICBza2lsbGVkTGFiOntcclxuICAgICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGxhYmVsOiBcIlNraWxsZWQgbGFib3VyZXIgKGUuZy4gcGx1bWJpbmcsIGVsZWN0cmljaWFuLCBjb29rLCB0YWlsb3IpXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIGZhcm1pbmc6IHtcclxuICAgICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGxhYmVsOiBcIkZhcm1pbmcvQWdyaWN1bHR1cmVcIixcclxuICAgICAgfSxcclxuICAgICAgbWluaW5nOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJNaW5pbmdcIixcclxuICAgICAgfSxcclxuICAgICAgbWFudToge1xyXG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgbGFiZWw6IFwiTWFudWZhY3R1cmluZ1wiLFxyXG4gICAgICB9LFxyXG4gICAgICB1bmVtcGxveWVkOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJVbmVtcGxveWVkXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIGFueU90aGVyT2NjOiB7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBsYWJlbDogXCJPdGhlcnMgKHBsZWFzZSBzcGVjaWZ5KSAtIGZyZWUgdGV4dFwiLFxyXG4gICAgICB9LFxyXG4gICAgICBvdGhlck9jYzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgc29jaWFsSGlzUTQ6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydMYWJvdXInLCAnU2VkZW50YXJ5J10sXHJcbiAgICAgIH0sXHJcbiAgICAgIHNvY2lhbEhpc1E1OntcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCAnTm8nXSxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgfSxcclxuICAgICAgc29jaWFsSGlzUTY6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNvY2lhbEhpc1E3OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnVW5tYXJyaWVkJywgJ01hcnJpZWQnLCdXaWRvd2VkJywnRGl2b3JjZWQnXSxcclxuICAgICAgfSxcclxuICAgICAgc29jaWFsSGlzUTg6IHtcclxuICAgICAgICB0eXBlOiBOdW1iZXIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNvY2lhbEhpc1E5OiB7XHJcbiAgICAgICAgdHlwZTogTnVtYmVyLFxyXG4gICAgICB9LFxyXG4gICAgICBzb2NpYWxIaXNRMTA6IHtcclxuICAgICAgICB0eXBlOiBOdW1iZXIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNvY2lhbEhpc1ExMToge1xyXG4gICAgICAgIHR5cGU6IE51bWJlcixcclxuICAgICAgfSxcclxuICAgICAgc29jaWFsSGlzUTEzOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnTm8gRm9ybWFsIFF1YWxpZmljYXRpb25zJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICc2dGggc3RhbmRhcmQgb3IgbGVzcycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICc3dGgtOXRoIHN0YW5kYXJkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJzEwdGggc3RhbmRhcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnMTF0aCBzdGFuZGFyZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICcxMnRoIHN0YW5kYXJkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ1ZvY2F0aW9uYWwgdHJhaW5pbmcgKGUuZy4gcGx1bWJpbmcsIGNvbnN0cnVjdGlvbiwgY29va2luZyknLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnQmFjaGVsb3JzIG9yIGVxdWl2YWxlbnQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnUG9zdC1ncmFkdWF0ZSAoTWFzdGVycy9Eb2N0b3JhdGUgb3IgZXF1aXZhbGVudCknLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnUmVmdXNlIHRvIGFuc3dlciddLFxyXG4gICAgICB9LFxyXG4gICAgfSksXHJcblxyXG4gICAgXCJTdGF0aW9uIFNlbGVjdGlvblwiOlxyXG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XHJcbiAgICAgIHN0YXRpb25TZWxlY3QxOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBzdGF0aW9uU2VsZWN0Mjp7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdObycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdOb3QgYXBwbGljYWJsZSAoY2hpbGQpJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIHN0YXRpb25TZWxlY3QzOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBzdGF0aW9uU2VsZWN0NDoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTm8nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTm90IGFwcGxpY2FibGUgKGNoaWxkKSddLFxyXG4gICAgICB9LFxyXG4gICAgICBzdGF0aW9uU2VsZWN0NToge1xyXG4gICAgICAgIHR5cGU6IEFycmF5LFxyXG4gICAgICB9LFxyXG4gICAgICAnc3RhdGlvblNlbGVjdDUuJCc6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydIaWdoIGJsb29kIHByZXNzdXJlJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdEaWFiZXRlcycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnQ2lnYXJldHRlIHNtb2tpbmcnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ0ZhbWlseSBtZW1iZXIgd2l0aCBjb3JvbmFyeSBhcnRlcnkgZGlzZWFzZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdGYW1pbHkgbWVtYmVyIHdpdGggaGlnaCBjaG9sZXN0ZXJvbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdDaHJvbmljIGtpZG5leSBkaXNlYXNlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vbmUgb2YgdGhlIGFib3ZlL25vdCBhcHBsaWNhYmxlIChBZ2UgPCA0MCknXSxcclxuICAgICAgfSxcclxuICAgICAgc3RhdGlvblNlbGVjdDY6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vdCBhcHBsaWNhYmxlIChjaGlsZCknXSxcclxuICAgICAgfSxcclxuICAgICAgc3RhdGlvblNlbGVjdDc6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIHN0YXRpb25TZWxlY3Q4OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdObyddLFxyXG4gICAgICB9LFxyXG4gICAgICBzdGF0aW9uU2VsZWN0OToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTm8nXSxcclxuICAgICAgfSxcclxuICAgICAgc3RhdGlvblNlbGVjdDEwOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdObycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdOb3QgYXBwbGljYWJsZSAoY2hpbGQpJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIHN0YXRpb25TZWxlY3QxMToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTm8nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTm90IGFwcGxpY2FibGUgKGNoaWxkIDwgMTAgeWVhcnMgb2xkKSddLFxyXG4gICAgICB9LFxyXG4gICAgICBzdGF0aW9uU2VsZWN0MTI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydZZXMnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vJ10sXHJcbiAgICAgIH0sXHJcbiAgICAgIHN0YXRpb25TZWxlY3QxMzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ1llcycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnTm8nXSxcclxuICAgICAgfSxcclxuICAgICAgc3RhdGlvblNlbGVjdDE0OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnWWVzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdObycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdOb3QgYXBwbGljYWJsZSAoY2hpbGQpJ10sXHJcbiAgICAgIH0sXHJcbiAgICB9KSxcclxuICB9LFxyXG5cclxuICBcIkhlaWdodCAmIHdlaWdodFwiOlxyXG4gIG5ldyBTaW1wbGVTY2hlbWEoe1xyXG4gICAgaGVpZ2h0OiB7XHJcbiAgICAgIHR5cGU6IE51bWJlcixcclxuICAgICAgbWluOiAwLjcsXHJcbiAgICAgIG1heDogMi44LFxyXG4gICAgICBsYWJlbDogXCJIZWlnaHQgKG0pXCIsXHJcbiAgICB9LFxyXG4gICAgLy8gY2hpbGRIZWlnaHQ6IHtcclxuICAgIC8vICAgdHlwZTogU3RyaW5nLFxyXG4gICAgLy8gICBhbGxvd2VkVmFsdWVzOiBbJ0JlbG93IDNyZCBwZXJjZW50aWxlIGN1cnZlJywgXHJcbiAgICAvLyAgICAgICAgICAgICAgICAgICAnQmV0d2VlbiAzcmQgYW5kIDk3dGggcGVyY2VudGlsZSBjdXJ2ZXMnLFxyXG4gICAgLy8gICAgICAgICAgICAgICAgICAgJ0Fib3ZlIDk3dGggcGVyY2VudGlsZSBjdXJ2ZSddLFxyXG4gICAgLy8gfSxcclxuICAgIHdlaWdodDoge1xyXG4gICAgICB0eXBlOiBOdW1iZXIsXHJcbiAgICAgIG1pbjogNSxcclxuICAgICAgbWF4OiA1MDAsXHJcbiAgICAgIGxhYmVsOiBcIldlaWdodCAoa2cpXCIsXHJcbiAgICB9LFxyXG4gICAgLy8gY2hpbGRXZWlnaHQ6e1xyXG4gICAgLy8gICB0eXBlOiBTdHJpbmcsXHJcbiAgICAvLyAgIGFsbG93ZWRWYWx1ZXM6IFsnQmVsb3cgM3JkIHBlcmNlbnRpbGUgY3VydmUnLCBcclxuICAgIC8vICAgICAgICAgICAgICAgICAgICdCZXR3ZWVuIDNyZCBhbmQgOTd0aCBwZXJjZW50aWxlIGN1cnZlcycsXHJcbiAgICAvLyAgICAgICAgICAgICAgICAgICAnQWJvdmUgOTd0aCBwZXJjZW50aWxlIGN1cnZlJ10sXHJcbiAgICAvLyB9LFxyXG4gICAgd2Fpc3Q6IHtcclxuICAgICAgdHlwZTogTnVtYmVyLFxyXG4gICAgICBsYWJlbDogXCJXYWlzdCBjaXJjdW1mZXJlbmNlIChjbSlcIixcclxuICAgIH0sXHJcbiAgICBoaXA6IHtcclxuICAgICAgdHlwZTogTnVtYmVyLFxyXG4gICAgICBsYWJlbDogXCJIaXAgY2lyY3VtZmVyZW5jZSAoY20pXCIsXHJcbiAgICB9LFxyXG4gICAgZG9jQ29uc3VsdEZvckhXOiB7XHJcbiAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgIGxhYmVsOiBcIkRvY3RvcnMgY29uc3VsdCByZXF1aXJlZD9cIixcclxuICAgIH0sXHJcbiAgfSksXHJcblxyXG4gIFwiQmxvb2QgR2x1Y29zZSAmIEhiXCI6XHJcbiAgbmV3IFNpbXBsZVNjaGVtYSh7XHJcbiAgICBjYmc6IHtcclxuICAgICAgdHlwZTogU2ltcGxlU2NoZW1hLkludGVnZXIsXHJcbiAgICAgIG1pbjogMjAsXHJcbiAgICAgIG1heDogNDAwLFxyXG4gICAgICBsYWJlbDogXCJDYXBpbGxhcnkgQmxvb2QgR2x1Y29zZSAobWcvZEwpXCIsXHJcbiAgICB9LFxyXG4gICAgaGI6IHtcclxuICAgICAgdHlwZTogTnVtYmVyLFxyXG4gICAgICBtaW46IDQsXHJcbiAgICAgIG1heDogNDAsXHJcbiAgICAgIGxhYmVsOiBcIkhlbW9nbG9iaW4gKGcvZEwpXCIsXHJcbiAgICB9LFxyXG4gICAgZG9jQ29uc3VsdEZvckJsb29kR2x1Y0FuZEhiOntcclxuICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgbGFiZWw6IFwiRG9jdG9ycyBjb25zdWx0IHJlcXVpcmVkP1wiLFxyXG4gICAgfSxcclxuICB9KSxcclxuXHJcbiAgXCJQaGxlYm90b215XCI6IFxyXG4gIG5ldyBTaW1wbGVTY2hlbWEoe1xyXG4gICAgcGhsZWJvQ29tcGxldGVkOiB7XHJcbiAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgIGxhYmVsOiBcIlBobGVib3RvbXkgY29tcGxldGVkP1wiXHJcbiAgICB9LFxyXG4gIH0pLFxyXG5cclxuICBcIlBhcCBTbWVhclwiOlxyXG4gIG5ldyBTaW1wbGVTY2hlbWEoe1xyXG4gICAgcGFwQ29tcGxldGVkOiB7XHJcbiAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgIGxhYmVsOiBcIlBhcCBzbWVhciBjb21wbGV0ZWQ/XCJcclxuICAgIH0sXHJcbiAgICBwYXBOb3Rlczp7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgIGxhYmVsOiBcIk5vdGVzIChpZiBhbnkpXCIsXHJcbiAgICB9LFxyXG4gICAgZG9jQ29uc3VsdEZvclBhcDoge1xyXG4gICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICBsYWJlbDogXCJEb2N0b3JzIGNvbnN1bHQgcmVxdWlyZWQ/XCIsXHJcbiAgICB9LFxyXG4gIH0pLFxyXG5cclxuICBcIkJyZWFzdCBFeGFtXCI6XHJcbiAgbmV3IFNpbXBsZVNjaGVtYSh7XHJcbiAgICBhYm5vcm1hbGl0aWVzOiB7XHJcbiAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgIGxhYmVsOiBcIkFueSBhYm5vcm1hbGl0aWVzIG5vdGVkIChlLmcuIGx1bXBzLCBza2luIGNoYW5nZXMpP1wiXHJcbiAgICB9LFxyXG4gICAgYWJEZXNjcmliZToge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgICBsYWJlbDogXCJJZiB5ZXMgdG8gdGhlIHByZXZpb3VzIHF1ZXN0aW9uLCBwbGVhc2UgZGVzY3JpYmUgdGhlIGFibm9ybWFsaXRpZXNcIlxyXG4gICAgfSxcclxuICAgIGZuYWNDb21wbGV0ZWQ6IHtcclxuICAgICAgdHlwZTogQm9vbGVhbiwgXHJcbiAgICAgIGxhYmVsOiBcIkZOQUMgQ29tcGxldGVkP1wiXHJcbiAgICB9LFxyXG4gICAgZWR1Q29tcGxldGVkOiB7XHJcbiAgICAgIHR5cGU6IEJvb2xlYW4sXHJcbiAgICAgIGxhYmVsOiBcIkJyZWFzdCBTY3JlZW5pbmcgRWR1Y2F0aW9uIENvbXBsZXRlZD9cIlxyXG4gICAgfVxyXG4gIH0pLFxyXG5cclxuICBcIkJsb29kIFByZXNzdXJlXCI6XHJcbiAgbmV3IFNpbXBsZVNjaGVtYSh7XHJcbiAgICBicDFTeXM6IHtcclxuICAgICAgdHlwZTogU2ltcGxlU2NoZW1hLkludGVnZXIsXHJcbiAgICAgIG1pbjogNTAsXHJcbiAgICAgIG1heDogMzAwLFxyXG4gICAgICBsYWJlbDogXCIxc3QgU3lzdG9saWMgYmxvb2QgcHJlc3N1cmVcIlxyXG4gICAgfSxcclxuICAgIGJwMURpYToge1xyXG4gICAgICB0eXBlOiBTaW1wbGVTY2hlbWEuSW50ZWdlcixcclxuICAgICAgbWluOiAyMCxcclxuICAgICAgbWF4OiAyMDAsXHJcbiAgICAgIGxhYmVsOiBcIjFzdCBEaWFzdG9saWMgYmxvb2QgcHJlc3N1cmVcIlxyXG4gICAgfSxcclxuICAgIGJwMlN5czoge1xyXG4gICAgICB0eXBlOiBTaW1wbGVTY2hlbWEuSW50ZWdlcixcclxuICAgICAgbWluOiA1MCxcclxuICAgICAgbWF4OiAzMDAsXHJcbiAgICAgIGxhYmVsOiBcIjJuZCBTeXN0b2xpYyBibG9vZCBwcmVzc3VyZVwiXHJcbiAgICB9LFxyXG4gICAgYnAyRGlhOiB7XHJcbiAgICAgIHR5cGU6IFNpbXBsZVNjaGVtYS5JbnRlZ2VyLFxyXG4gICAgICBtaW46IDIwLFxyXG4gICAgICBtYXg6IDIwMCxcclxuICAgICAgbGFiZWw6IFwiMm5kIERpYXN0b2xpYyBibG9vZCBwcmVzc3VyZVwiXHJcbiAgICB9LFxyXG4gICAgYnAzU3lzOiB7XHJcbiAgICAgIHR5cGU6IFNpbXBsZVNjaGVtYS5JbnRlZ2VyLFxyXG4gICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgbWluOiA1MCxcclxuICAgICAgbWF4OiAzMDAsXHJcbiAgICAgIGxhYmVsOiBcIjNyZCBTeXN0b2xpYyBibG9vZCBwcmVzc3VyZVwiXHJcbiAgICB9LFxyXG4gICAgYnAzRGlhOiB7XHJcbiAgICAgIHR5cGU6IFNpbXBsZVNjaGVtYS5JbnRlZ2VyLFxyXG4gICAgICBvcHRpb25hbDogdHJ1ZSxcclxuICAgICAgbWluOiAyMCxcclxuICAgICAgbWF4OiAyMDAsXHJcbiAgICAgIGxhYmVsOiBcIjNyZCBEaWFzdG9saWMgYmxvb2QgcHJlc3N1cmVcIlxyXG4gICAgfSxcclxuICAgIGRvY0NvbnN1bHRGb3JCUDoge1xyXG4gICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICBsYWJlbDogXCJEb2N0b3JzIGNvbnN1bHQgcmVxdWlyZWQ/XCIsXHJcbiAgICB9LFxyXG4gIH0pLFxyXG5cclxuICBcIkRvY3RvcnMnIENvbnN1bHRcIjpcclxuICBuZXcgU2ltcGxlU2NoZW1hKHtcclxuICAgIGRvY0NvbnN1bHQxOiB7XHJcbiAgICAgIHR5cGU6IEFycmF5LFxyXG4gICAgfSxcclxuICAgICdkb2NDb25zdWx0MS4kJzoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnT3ZlcndlaWdodC9vYmVzaXR5JywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnSGVhcnQgYnVybicsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ0RpYWJldGVzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnSGlnaCBibG9vZCBwcmVzc3VyZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnSGVhcnQgZGlzZWFzZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnVW5leHBsYWluZWQgd2VpZ2h0IGxvc3MnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ1Jlc3BpcmF0b3J5IHByb2JsZW1zJyxcclxuICAgICAgICAgICAgICAgICAgICAgICdKb2ludCBwYWluL2JhY2sgcGFpbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnU3Ryb2tlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICdWaXN1YWwgaW1wYWlybWVudCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnTWVudGFsIGhlYWx0aCBpc3N1ZXMnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ0FsY29ob2wgb3ZlcnVzZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnRHJ1ZyBhZGRpY3Rpb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ0luZmVjdGlvdXMgZGlzZWFzZXMgZS5nLiBtYWxhcmlhLCB0dWJlcmN1bG9zaXMnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ090aGVycyAoZnJlZSB0ZXh0KSddLFxyXG4gICAgfSxcclxuICAgIG90aGVyQ29tcGxhaW50czoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIG9wdGlvbmFsOiB0cnVlLFxyXG4gICAgfSxcclxuICAgIGRvY0NvbnN1bHQyOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgIH0sXHJcbiAgICBkb2NDb25zdWx0Mzoge1xyXG4gICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICBsYWJlbDogXCJQcm92aWRlZCB3aXRoIHJlZmVycmFsIGxldHRlcj9cIlxyXG4gICAgfSxcclxuICAgIGRvY0NvbnN1bHQ0OiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgZG9jQ29uc3VsdDU6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgfSxcclxuICB9KSxcclxuXHJcbiAgXCJFeWUgU2NyZWVuaW5nXCI6XHJcbiAgbmV3IFNpbXBsZVNjaGVtYSAoe1xyXG4gICAgc3BlY3M6IHtcclxuICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgbGFiZWw6IFwiRG9lcyB0aGUgcGFydGljaXBhbnQgdXNlIHNwZWN0YWNsZXM/XCJcclxuICAgIH0sXHJcbiAgICByaWdodFdvR2xhc3M6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBsYWJlbDogXCJSaWdodCBleWUgd2l0aG91dCBnbGFzc2VzXCJcclxuICAgIH0sXHJcbiAgICBsZWZ0V29HbGFzczoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGxhYmVsOiBcIkxlZnQgZXllIHdpdGhvdXQgZ2xhc3Nlc1wiXHJcbiAgICB9LFxyXG4gICAgcmlnaHRXaUdsYXNzOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiUmlnaHQgZXllIHdpdGggZ2xhc3Nlc1wiXHJcbiAgICB9LFxyXG4gICAgbGVmdFdpR2xhc3M6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBsYWJlbDogXCJMZWZ0IGV5ZSB3aXRoIGdsYXNzZXNcIlxyXG4gICAgfSxcclxuICAgIHJpZ2h0TmVhclZpczoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGxhYmVsOiBcIlJpZ2h0IGV5ZSBuZWFyIHZpc2lvblwiXHJcbiAgICB9LFxyXG4gICAgbGVmdE5lYXJWaXM6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBsYWJlbDogXCJMZWZ0IGV5ZSBuZWFyIHZpc2lvblwiXHJcbiAgICB9LFxyXG4gICAgbGlkczoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGxhYmVsOiBcIkxpZHNcIlxyXG4gICAgfSxcclxuICAgIGNvbmp1bmN0aXZhOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiQ29uanVuY3RpdmFcIlxyXG4gICAgfSxcclxuICAgIGNvcm5lYToge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGxhYmVsOiBcIkNvcm5lYVwiXHJcbiAgICB9LFxyXG4gICAgYW50U2VnOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiQW50ZXJpb3IgU2VnbWVudFwiXHJcbiAgICB9LFxyXG4gICAgaXJpczoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGxhYmVsOiBcIklyaXNcIlxyXG4gICAgfSxcclxuICAgIHB1cGlsOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiUHVwaWxcIlxyXG4gICAgfSxcclxuICAgIGxlbnM6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBsYWJlbDogXCJMZW5zXCJcclxuICAgIH0sXHJcbiAgICBvY3VNdm10OiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiT2N1bGFyIE1vdmVtZW50c1wiXHJcbiAgICB9LFxyXG4gICAgaW9wOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiSU9QXCJcclxuICAgIH0sXHJcbiAgICBkdWN0OiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiRHVjdFwiXHJcbiAgICB9LFxyXG4gICAgY2RyOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiQ0RSXCJcclxuICAgIH0sXHJcbiAgICBtYWN1bGE6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBsYWJlbDogXCJNYWN1bGFcIlxyXG4gICAgfSxcclxuICAgIHJldGluYToge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGxhYmVsOiBcIlJldGluYVwiXHJcbiAgICB9LFxyXG4gICAgZGlhZ25vc2lzOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgbGFiZWw6IFwiRGlhZ25vc2lzXCJcclxuICAgIH0sXHJcbiAgICBhZHZpY2U6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBsYWJlbDogXCJBZHZpY2VcIlxyXG4gICAgfSxcclxuICAgIG5hbWVEb2M6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBsYWJlbDogXCJOYW1lIG9mIERvY3RvclwiXHJcbiAgICB9LFxyXG4gIH0pLFxyXG5cclxuICBcIldvbWVuJ3MgRWR1XCI6e1xyXG4gICAgXCJQcmUtV29tZW4ncyBFZHVjYXRpb24gUXVpelwiOlxyXG4gICAgbmV3IFNpbXBsZVNjaGVtYSAoe1xyXG4gICAgICBicmVhc3RDb21wbGV0ZWQ6IHtcclxuICAgICAgICB0eXBlOiBCb29sZWFuLCBcclxuICAgICAgICBsYWJlbDogXCJCcmVhc3QgU2NyZWVuaW5nIENvbXBsZXRlZD9cIlxyXG4gICAgICB9LFxyXG4gICAgICBwcmVXb21lbkVkdVN1cnZleTE6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJzEnLCAnMicsICczJywgJzQnLCAnNSddLCAgIFxyXG4gICAgICB9LFxyXG4gICAgICAgIHByZVdvbWVuRWR1UTE6IHtcclxuICAgICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnQWJkb21pbmFsIGNyYW1wcycsJ0FjbmUnLCdIZWFkYWNoZScsJ0FsbCBvZiB0aGUgYWJvdmUnXSwgXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIHByZVdvbWVuRWR1UTI6IHtcclxuICAgICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3RyZXNzJywgJ1ByZWduYW5jeScsICdXZWlnaHQgbG9zcycsICdBYnJhc2lvbnMnXSwgICBcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBwcmVXb21lbkVkdVEzOiB7XHJcbiAgICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ01lbnN0cnVhdGlvbiBpcyBkaXJ0eScsICdNZW5zdHJ1YXRpb24gaGFwcGVucyBldmVyeSAyOCBkYXlzLCBvbiBhdmVyYWdlJywgJ1dlIHNob3VsZCBjaGFuZ2Ugb3VyIHNhbml0YXJ5IHBhZHMgb25jZSBldmVyeSBmZXcgZGF5cycsICdXZSBzaG91bGQgY2xlYW4gdGhlIGFyZWEgZnJvbSBiYWNrIHRvIGZyb250J10sICAgXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIHByZVdvbWVuRWR1UTQ6IHtcclxuICAgICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnMXN0IGRheSBvZiBtZW5zZXMnLCAnNy0xMCBkYXlzIGFmdGVyIHN0YXJ0IG9mIG1lbnNlcycsICcyMSBkYXlzIGFmdGVyIHN0YXJ0IG9mIG1lbnNlcycsICcyIGRheXMgYmVmb3JlIHN0YXJ0IG9mIG1lbnNlcyddLCAgIFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBwcmVXb21lbkVkdVE1OiB7XHJcbiAgICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ09uY2UgYSB3ZWVrJywgJ09uY2UgYSBtb250aCcsICdPbmNlIGEgeWVhcicsICdPbmNlIGluIDIgeWVhcnMnXSwgICBcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgcHJlV29tZW5FZHVRNjoge1xyXG4gICAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgICAgYWxsb3dlZFZhbHVlczogWydBIGx1bXAgdGhhdCBjYW4gYmUgc2Vlbi9mZWx0IGluIHRoZSBicmVhc3Qgb3IgdW5kZXJhcm0nLCAnTmlwcGxlIHRoYXQgaXMgcHVzaGVkIGlud2FyZHMnLCAnRGltcGxpbmcgb2Ygc2tpbiBvdmVyIHRoZSBicmVhc3QnLCAnVWxjZXJhdGlvbiBvZiBza2luIG92ZXIgdGhlIGJyZWFzdCcsJ0FsbCBvZiB0aGUgYWJvdmUnXSwgICBcclxuICAgICAgICAgIH0sXHJcbiAgICAgIH0pLFxyXG5cclxuICAgIFwiUG9zdC1Xb21lbidzIEVkdWNhdGlvbiBRdWl6XCI6XHJcbiAgICBuZXcgU2ltcGxlU2NoZW1hICh7XHJcbiAgICAgIHBvc3RXb21lbkVkdVN1cnZleTE6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJzEnLCAnMicsICczJywgJzQnLCAnNSddLCAgIFxyXG4gICAgICB9LFxyXG4gICAgICBwb3N0V29tZW5FZHVRMToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0FiZG9taW5hbCBjcmFtcHMnLCdBY25lJywnSGVhZGFjaGUnLCdBbGwgb2YgdGhlIGFib3ZlJ10sIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHBvc3RXb21lbkVkdVEyOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3RyZXNzJywgJ1ByZWduYW5jeScsICdXZWlnaHQgbG9zcycsICdBYnJhc2lvbnMnXSwgICBcclxuICAgICAgICB9LFxyXG4gICAgICBwb3N0V29tZW5FZHVRMzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ01lbnN0cnVhdGlvbiBpcyBkaXJ0eScsICdNZW5zdHJ1YXRpb24gaGFwcGVucyBldmVyeSAyOCBkYXlzLCBvbiBhdmVyYWdlJywgJ1dlIHNob3VsZCBjaGFuZ2Ugb3VyIHNhbml0YXJ5IHBhZHMgb25jZSBldmVyeSBmZXcgZGF5cycsICdXZSBzaG91bGQgY2xlYW4gdGhlIGFyZWEgZnJvbSBiYWNrIHRvIGZyb250J10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgcG9zdFdvbWVuRWR1UTQ6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWycxc3QgZGF5IG9mIG1lbnNlcycsICc3LTEwIGRheXMgYWZ0ZXIgc3RhcnQgb2YgbWVuc2VzJywgJzIxIGRheXMgYWZ0ZXIgc3RhcnQgb2YgbWVuc2VzJywgJzIgZGF5cyBiZWZvcmUgc3RhcnQgb2YgbWVuc2VzJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgcG9zdFdvbWVuRWR1UTU6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydPbmNlIGEgd2VlaycsICdPbmNlIGEgbW9udGgnLCAnT25jZSBhIHllYXInLCAnT25jZSBpbiAyIHllYXJzJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgcG9zdFdvbWVuRWR1UTY6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydBIGx1bXAgdGhhdCBjYW4gYmUgc2Vlbi9mZWx0IGluIHRoZSBicmVhc3Qgb3IgdW5kZXJhcm0nLCAnTmlwcGxlIHRoYXQgaXMgcHVzaGVkIGlud2FyZHMnLCAnRGltcGxpbmcgb2Ygc2tpbiBvdmVyIHRoZSBicmVhc3QnLCAnVWxjZXJhdGlvbiBvZiBza2luIG92ZXIgdGhlIGJyZWFzdCcsJ0FsbCBvZiB0aGUgYWJvdmUnXSwgICBcclxuICAgICAgICB9LFxyXG4gICAgfSksXHJcbiAgfSxcclxuICBcclxuICBcIkVkdWNhdGlvblwiOntcclxuICAgIFwiUHJlLUVkdWNhdGlvbiBTdXJ2ZXlcIjpcclxuICAgIG5ldyBTaW1wbGVTY2hlbWEgKHtcclxuICAgICAgcHJlRWR1U3VydmV5MToge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnMScsICcyJywgJzMnLCAnNCcsICc1J10sICAgXHJcbiAgICAgIH0sXHJcbiAgICAgIHByZUVkdVN1cnZleTI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWycxJywgJzInLCAnMycsICc0JywgJzUnXSwgICBcclxuICAgICAgICB9LFxyXG4gICAgICBwcmVFZHVTdXJ2ZXkzOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnMScsICcyJywgJzMnLCAnNCcsICc1J10sICAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHByZUVkdVN1cnZleTQ6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWycxJywgJzInLCAnMycsICc0JywgJzUnXSwgICBcclxuICAgICAgICB9LFxyXG4gICAgfSksXHJcblxyXG4gICAgXCJQcmUtRWR1Y2F0aW9uIFF1aXpcIjpcclxuICAgIG5ldyBTaW1wbGVTY2hlbWEgKHtcclxuICAgICAgcHJlRWR1UXVpejE6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJ0RvIG5vdCBleGVyY2lzZScsICdIYXZlIGRpYWJldGVzJywgJ1Ntb2tlJywgJ0FsbCBvZiB0aGUgYWJvdmUnXSwgICBcclxuICAgICAgfSxcclxuICAgICAgcHJlRWR1UXVpejI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydEbyBub3QgZXhlcmNpc2UnLCAnSGF2ZSBkaWFiZXRlcycsICdTbW9rZScsICdBbGwgb2YgdGhlIGFib3ZlJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBwcmVFZHVRdWl6Mzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJzYwIG1pbnMnLCAnOTAgbWlucycsICcxMjAgbWlucycsICcxNTAgbWlucyddLCAgICBcclxuICAgICAgICB9LFxyXG4gICAgICBwcmVFZHVRdWl6NDoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJzEvMiByaWNlLCAxLzQgZnJ1aXRzIGFuZCB2ZWdldGFibGVzLCAxLzQgcHJvdGVpbicsICcyLzUgcmljZSwgMS81IHZlZ2V0YWJsZXMsIDEvNSBmcnVpdHMsIDEvNSBwcm90ZWluJywgJzEvMyByaWNlLCAxLzMgdmVnZXRhYmxlcywgMS8zIHByb3RlaW4nLCAnMS8yIGZydWl0cyBhbmQgdmVnZXRhYmxlcywgMS80IHJpY2UsIDEvNCBwcm90ZWluJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgcHJlRWR1UXVpejU6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWydEYWFsJywgJ01hdHRhciBQYW5lZXInLCAnQ2hvbGUgQmhhdHR1cmEnLCAnQnV0dGVyIFBhbmVlciddLCAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHByZUVkdVF1aXo2OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnVG9iYWNjbycsICdBbGNvaG9sJywgJ1Blc3RpY2lkZXMnLCAnQWxsIG9mIHRoZSBhYm92ZSddLCAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHByZUVkdVF1aXo3OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnR2V0IGNvbXByZWhlbnNpdmUgZXllIGV4YW1zIHJlZ3VsYXJseScsICdVc2UgYSBjb21wdXRlciBmb3IgMmggdG8gZmluaXNoIG15IHdvcmsnLCAnUmVhZCB1bmRlciBzdWZmaWNpZW50bHkgYnJpZ2h0IGxpZ2h0JywgJ1dlYXIgc3VuZ2xhc3NlcyBhbmQgY2FwcyB3aGVuIG91dGRvb3JzIHRvIHByb3RlY3QgZXllcyBmcm9tIFVWIHJheXMnXSwgICBcclxuICAgICAgICB9LFxyXG4gICAgfSksXHJcblxyXG4gICAgXCJQb3N0LUVkdWNhdGlvbiBTdXJ2ZXlcIjpcclxuICAgIG5ldyBTaW1wbGVTY2hlbWEgKHtcclxuICAgICAgcG9zdEVkdVN1cnZleTE6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJzEnLCAnMicsICczJywgJzQnLCAnNSddLCAgIFxyXG4gICAgICB9LFxyXG4gICAgICBwb3N0RWR1U3VydmV5Mjoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJzEnLCAnMicsICczJywgJzQnLCAnNSddLCAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHBvc3RFZHVTdXJ2ZXkzOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnMScsICcyJywgJzMnLCAnNCcsICc1J10sICAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHBvc3RFZHVTdXJ2ZXk0OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnMScsICcyJywgJzMnLCAnNCcsICc1J10sICAgXHJcbiAgICAgICAgfSxcclxuICAgIH0pLFxyXG5cclxuICAgIFwiUG9zdC1FZHVjYXRpb24gUXVpelwiOlxyXG4gICAgbmV3IFNpbXBsZVNjaGVtYSAoe1xyXG4gICAgICBwb3N0RWR1UXVpejE6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJ0RvIG5vdCBleGVyY2lzZScsICdIYXZlIGRpYWJldGVzJywgJ1Ntb2tlJywgJ0FsbCBvZiB0aGUgYWJvdmUnXSwgICBcclxuICAgICAgfSxcclxuICAgICAgcG9zdEVkdVF1aXoyOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnRG8gbm90IGV4ZXJjaXNlJywgJ0hhdmUgZGlhYmV0ZXMnLCAnU21va2UnLCAnQWxsIG9mIHRoZSBhYm92ZSddLCAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHBvc3RFZHVRdWl6Mzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJzYwIG1pbnMnLCAnOTAgbWlucycsICcxMjAgbWlucycsICcxNTAgbWlucyddLCAgICBcclxuICAgICAgICB9LFxyXG4gICAgICBwb3N0RWR1UXVpejQ6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgYWxsb3dlZFZhbHVlczogWycxLzIgcmljZSwgMS80IGZydWl0cyBhbmQgdmVnZXRhYmxlcywgMS80IHByb3RlaW4nLCAnMi81IHJpY2UsIDEvNSB2ZWdldGFibGVzLCAxLzUgZnJ1aXRzLCAxLzUgcHJvdGVpbicsICcxLzMgcmljZSwgMS8zIHZlZ2V0YWJsZXMsIDEvMyBwcm90ZWluJywgJzEvMiBmcnVpdHMgYW5kIHZlZ2V0YWJsZXMsIDEvNCByaWNlLCAxLzQgcHJvdGVpbiddLCAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHBvc3RFZHVRdWl6NToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0RhYWwnLCAnTWF0dGFyIFBhbmVlcicsICdDaG9sZSBCaGF0dHVyYScsICdCdXR0ZXIgUGFuZWVyJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgcG9zdEVkdVF1aXo2OiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnVG9iYWNjbycsICdBbGNvaG9sJywgJ1Blc3RpY2lkZXMnLCAnQWxsIG9mIHRoZSBhYm92ZSddLCAgIFxyXG4gICAgICAgIH0sXHJcbiAgICAgIHBvc3RFZHVRdWl6Nzoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ0dldCBjb21wcmVoZW5zaXZlIGV5ZSBleGFtcyByZWd1bGFybHknLCAnVXNlIGEgY29tcHV0ZXIgZm9yIDJoIHRvIGZpbmlzaCBteSB3b3JrJywgJ1JlYWQgdW5kZXIgc3VmZmljaWVudGx5IGJyaWdodCBsaWdodCcsICdXZWFyIHN1bmdsYXNzZXMgYW5kIGNhcHMgd2hlbiBvdXRkb29ycyB0byBwcm90ZWN0IGV5ZXMgZnJvbSBVViByYXlzJ10sICAgXHJcbiAgICAgICAgfSxcclxuICAgIH0pLFxyXG4gIH0sXHJcblxyXG4gIFwiUG9zdC1TY3JlZW5pbmcgRmVlZGJhY2tcIjpcclxuICBuZXcgU2ltcGxlU2NoZW1hICh7XHJcbiAgICBwb3N0U2NyZWVuaW5nRmVlZGJhY2sxOiB7XHJcbiAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ1N0cm9uZ2x5IGFncmVlJywgJ0FncmVlJywgJ0Rpc2FncmVlJywgJ1N0cm9uZ2x5IGRpc2FncmVlJ10sICAgXHJcbiAgICB9LFxyXG4gICAgcG9zdFNjcmVlbmluZ0ZlZWRiYWNrMjoge1xyXG4gICAgICB0eXBlOiBBcnJheSxcclxuICAgIH0sXHJcbiAgICAncG9zdFNjcmVlbmluZ0ZlZWRiYWNrMi4kJzoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnSSBhbSBjb25jZXJuZWQgYWJvdXQgbXkgaGVhbHRoJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnSSBoYXZlIG5ldmVyIGJlZW4gc2NyZWVuZWQgYmVmb3JlJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnRnJpZW5kcy9mYW1pbHkgdG9sZCBtZSB0byBjb21lJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnVGhlcmUgaXMgYSBmcmVlIGhlYWx0aCBzY3JlZW5pbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ1RoZXJlIGlzIGEgZnJlZSBnb29kaWUgYmFnJyxcclxuICAgICAgICAgICAgICAgICAgICAgICdJIHdhcyBkcmF3biB0byB0aGUgY3Jvd2QnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgJ0l0IHdhcyBjb252ZW5pZW50bHkgbG9jYXRlZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnSXQgaXMgYXQgYSBjb252ZW5pZW50IHRpbWUnXSxcclxuICAgIH0sXHJcbiAgICBwb3N0U2NyZWVuaW5nRmVlZGJhY2szOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgYWxsb3dlZFZhbHVlczogWydTdHJvbmdseSBhZ3JlZScsICdBZ3JlZScsICdEaXNhZ3JlZScsICdTdHJvbmdseSBkaXNhZ3JlZSddLCAgIFxyXG4gICAgICB9LFxyXG4gICAgcG9zdFNjcmVlbmluZ0ZlZWRiYWNrNDoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3Ryb25nbHkgYWdyZWUnLCAnQWdyZWUnLCAnRGlzYWdyZWUnLCAnU3Ryb25nbHkgZGlzYWdyZWUnXSwgICBcclxuICAgIH0sXHJcbiAgICBwb3N0U2NyZWVuaW5nRmVlZGJhY2s1OiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgYWxsb3dlZFZhbHVlczogWydTdHJvbmdseSBhZ3JlZScsICdBZ3JlZScsICdEaXNhZ3JlZScsICdTdHJvbmdseSBkaXNhZ3JlZSddLCAgIFxyXG4gICAgICB9LFxyXG4gICAgcG9zdFNjcmVlbmluZ0ZlZWRiYWNrNjoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3Ryb25nbHkgYWdyZWUnLCAnQWdyZWUnLCAnRGlzYWdyZWUnLCAnU3Ryb25nbHkgZGlzYWdyZWUnXSwgICBcclxuICAgIH0sIFxyXG4gICAgcG9zdFNjcmVlbmluZ0ZlZWRiYWNrNzoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3Ryb25nbHkgYWdyZWUnLCAnQWdyZWUnLCAnRGlzYWdyZWUnLCAnU3Ryb25nbHkgZGlzYWdyZWUnXSwgICBcclxuICAgICAgfSxcclxuICAgIHBvc3RTY3JlZW5pbmdGZWVkYmFjazg6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJ1N0cm9uZ2x5IGFncmVlJywgJ0FncmVlJywgJ0Rpc2FncmVlJywgJ1N0cm9uZ2x5IGRpc2FncmVlJ10sICAgXHJcbiAgICB9LCBcclxuICAgIHBvc3RTY3JlZW5pbmdGZWVkYmFjazk6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJ1N0cm9uZ2x5IGFncmVlJywgJ0FncmVlJywgJ0Rpc2FncmVlJywgJ1N0cm9uZ2x5IGRpc2FncmVlJ10sICAgXHJcbiAgICAgIH0sXHJcbiAgICBwb3N0U2NyZWVuaW5nRmVlZGJhY2sxMDoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3Ryb25nbHkgYWdyZWUnLCAnQWdyZWUnLCAnRGlzYWdyZWUnLCAnU3Ryb25nbHkgZGlzYWdyZWUnXSwgICBcclxuICAgIH0sIFxyXG4gICAgcG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTE6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJ1N0cm9uZ2x5IGFncmVlJywgJ0FncmVlJywgJ0Rpc2FncmVlJywgJ1N0cm9uZ2x5IGRpc2FncmVlJ10sICAgXHJcbiAgICAgIH0sXHJcbiAgICBwb3N0U2NyZWVuaW5nRmVlZGJhY2sxMjoge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIGFsbG93ZWRWYWx1ZXM6IFsnU3Ryb25nbHkgYWdyZWUnLCAnQWdyZWUnLCAnRGlzYWdyZWUnLCAnU3Ryb25nbHkgZGlzYWdyZWUnXSwgICBcclxuICAgIH0sICAgXHJcbiAgICBwb3N0U2NyZWVuaW5nRmVlZGJhY2sxMzoge1xyXG4gICAgICB0eXBlOiBBcnJheSxcclxuICAgIH0sXHJcbiAgICAncG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTMuJCc6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJ0hhcHBlbmVkIHRvIHBhc3MgYnknLCBcclxuICAgICAgICAgICAgICAgICAgICAgICdQb3N0ZXJzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnTmV3c3BhcGVyJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnRG9vci10by1kb29yIHB1YmxpY2l0eScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnSGVhcmQgZnJvbSBuZWlnaGJvdXJzL3JlbGF0aXZlcy9mcmllbmRzJ10sXHJcbiAgICB9LFxyXG4gICAgcG9zdFNjcmVlbmluZ0ZlZWRiYWNrMTQ6IHtcclxuICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICBhbGxvd2VkVmFsdWVzOiBbJ05ldmVyJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnTW9yZSB0aGFuIDMgeWVhcnMgYWdvJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnT25jZSBpbiAzIHllYXJzJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAnT25jZSBpbiAyIHllYXJzJyxcclxuICAgICAgICAgICAgICAgICAgICAgICdPbmNlIGEgeWVhcicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnTW9yZSB0aGFuIG9uY2UgYSB5ZWFyJ10sICAgXHJcbiAgICB9LCAgIFxyXG5cclxuICB9KSxcclxuICBcclxufVxyXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMaW5rcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdsaW5rcycpO1xyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XHJcblxyXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XHJcbmltcG9ydCB7IGZvcm1TY2hlbWFzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2Zvcm1TY2hlbWFzJztcclxuaW1wb3J0IHsgZm9ybUxheW91dHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvZm9ybUxheW91dHMnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGF0aWVudGluZm8gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncGF0aWVudGluZm8nKTtcclxuXHJcbi8vIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuLy8gICBNZXRlb3IucHVibGlzaCgncGF0aWVudGluZm8nLCBmdW5jdGlvbiAoKSB7XHJcbi8vICAgICByZXR1cm4gUGF0aWVudGluZm8uZmluZCgpO1xyXG4vLyAgIH0pXHJcbi8vIH1cclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAncGF0aWVudGluZm8uaW5zZXJ0JyhkYXRhKSB7XHJcbiAgICAvLyBEZXRlcm1pbmUgc3RhdGlvbnMgdG8gdmlzaXQgYmFzZWQgb246XHJcbiAgICAvLyBCYXNlZCBvbiBnZW5kZXIgJiBhZ2VcclxuICAgIGNvbnN0IGlzTWFsZSA9IChkYXRhW1wiUGF0aWVudCBJbmZvXCJdLmdlbmRlciA9PT0gXCJtYWxlXCIpO1xyXG4gICAgY29uc3QgaXNDaGlsZCA9IChkYXRhW1wiUGF0aWVudCBJbmZvXCJdLmFnZSA8PSAxOCk7XHJcblxyXG4gICAgLy8gU3RhdGlvbnMgdG8gcmVtb3ZlXHJcbiAgICB2YXIgc3RhdGlvbnNUb1JlbW92ZSA9IFtcIlJlZ2lzdHJhdGlvblwiXTtcclxuICAgIGlmIChpc01hbGUpIHtcclxuICAgICAgc3RhdGlvbnNUb1JlbW92ZS5wdXNoKFwiUGFwIFNtZWFyXCIsIFwiQnJlYXN0IEV4YW1cIiwgXCJXb21lbidzIEVkdVwiKTtcclxuICAgIH1cclxuICAgIGlmIChpc0NoaWxkKSB7XHJcbiAgICAgIHN0YXRpb25zVG9SZW1vdmUucHVzaChcIkJsb29kIFByZXNzdXJlXCIsIFwiUGhsZWJvdG9teVwiLCBcIlBhcCBTbWVhclwiLCBcIkJyZWFzdCBFeGFtXCIpO1xyXG4gICAgfVxyXG4gICAgLy8gUmVtb3ZlIG9wdC1vdXQgc3RhdGlvbnNcclxuICAgIGNvbnNvbGUubG9nKGRhdGFbXCJTdGF0aW9uIFNlbGVjdGlvblwiXSk7XHJcbiAgICBmb3IgKHZhciBzdGF0aW9uIGluIGRhdGFbXCJTdGF0aW9uIFNlbGVjdGlvblwiXSkge1xyXG4gICAgICBpZiAoZGF0YVtcIlN0YXRpb24gU2VsZWN0aW9uXCJdW3N0YXRpb25dID09PSBcIk5vXCIpIHtcclxuICAgICAgICBzdGF0aW9uc1RvUmVtb3ZlLnB1c2goc3RhdGlvbik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBDb25zdHJ1Y3Qgc3RhdGlvbiBxdWV1ZSBieSBmaWx0ZXJpbmcgb3V0IHN0YXRpb25zIHRvIGV4Y2x1ZGVcclxuICAgIC8vIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzU3NjczMjUvaG93LWRvLWktcmVtb3ZlLWEtcGFydGljdWxhci1lbGVtZW50LWZyb20tYW4tYXJyYXktaW4tamF2YXNjcmlwdFxyXG4gICAgZGF0YS5zdGF0aW9uUXVldWUgPSBPYmplY3Qua2V5cyhmb3JtTGF5b3V0cykuZmlsdGVyKHMgPT4gIXN0YXRpb25zVG9SZW1vdmUuaW5jbHVkZXMocykpO1xyXG4gICAgXHJcbiAgICBkYXRhLm5leHRTdGF0aW9uID0gZGF0YS5zdGF0aW9uUXVldWVbMF07XHJcbiAgICBcclxuICAgIGRhdGEuYnVzeSA9IGZhbHNlO1xyXG5cclxuICAgIC8vIEFzc2lnbiB1bmlxdWUgaWRcclxuICAgIGRhdGEuaWQgPSBQYXRpZW50aW5mby5maW5kKHt9KS5jb3VudCgpICsgMTtcclxuXHJcbiAgICBQYXRpZW50aW5mby5pbnNlcnQoZGF0YSk7XHJcbiAgfSxcclxuICAncGF0aWVudGluZm8udXBkYXRlJyhkYXRhKSB7XHJcbiAgICBjb25zdCBpZCA9IGRhdGEuaWQ7XHJcbiAgICBkZWxldGUgZGF0YS5pZDtcclxuICAgIGRlbGV0ZSBkYXRhLm5leHRTdGF0aW9uO1xyXG5cclxuICAgIC8vIFJldHJpZXZlIHN0YXRpb24gcXVldWVcclxuICAgIHZhciBzdGF0aW9uUXVldWUgPSBQYXRpZW50aW5mby5maW5kKHtpZDppZH0pLmZldGNoKClbMF0uc3RhdGlvblF1ZXVlO1xyXG4gICAgXHJcbiAgICAvLyBQcm9jZWVkIHRvIG5leHQgc3RhdGlvblxyXG4gICAgc3RhdGlvblF1ZXVlLnNoaWZ0KCk7XHJcbiAgICBjb25zdCBuZXh0U3RhdGlvbiA9ICh0eXBlb2Yoc3RhdGlvblF1ZXVlWzBdKSAhPT0gXCJ1bmRlZmluZWRcIikgPyBzdGF0aW9uUXVldWVbMF0gOiBcIkRvbmVcIjtcclxuICAgIFxyXG4gICAgUGF0aWVudGluZm8udXBkYXRlKHtpZDppZH0seyRzZXQ6e25leHRTdGF0aW9uOm5leHRTdGF0aW9uLGJ1c3k6ZmFsc2Usc3RhdGlvblF1ZXVlOnN0YXRpb25RdWV1ZX0sICRwdXNoOmRhdGF9KTtcclxuXHJcbiAgICAvLyBjb25zb2xlLmxvZyhQYXRpZW50aW5mby5maW5kT25lKHtpZDppZH0pKTtcclxuICB9LFxyXG4gICdwYXRpZW50aW5mby5zZXRCdXN5JyhpZCwgdmFsdWUpIHtcclxuICAgIGNvbnN0IHBhdGllbnRTdGF0dXMgPSAoUGF0aWVudGluZm8uZmluZE9uZSh7aWQ6aWR9KSAhPT0gXCJ1bmRlZmluZWRcIikgPyBQYXRpZW50aW5mby5maW5kT25lKHtpZDppZH0pLmJ1c3kgOiBmYWxzZTtcclxuICAgIFxyXG4gICAgaWYgKHBhdGllbnRTdGF0dXMgPT09IHZhbHVlKSB7XHJcblxyXG4gICAgICBjb25zb2xlLmxvZyhcIlBhdGllbnQgY29uZmxpY3RcIik7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgXHJcbiAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgUGF0aWVudGluZm8udXBkYXRlKHtpZDppZH0seyRzZXQ6e2J1c3k6dmFsdWV9fSk7XHJcblxyXG4gICAgICBpZiAoTWV0ZW9yLmlzU2VydmVyICYmIHZhbHVlID09PSB0cnVlKSB7XHJcbiAgICAgICAgdGhpcy5jb25uZWN0aW9uLm9uQ2xvc2UoICgpID0+IHtcclxuICAgICAgICAgIFBhdGllbnRpbmZvLnVwZGF0ZSh7aWQ6aWR9LHskc2V0OntidXN5OmZhbHNlfX0pO1xyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICB9LFxyXG4gICdwYXRpZW50aW5mby5za2lwU3RhdGlvbicoaWQsIGN1cnJlbnRTdGF0aW9uLCBzdGF0aW9uVG9Ta2lwKSB7XHJcbiAgICAvLyBSZXRyaWV2ZSBzdGF0aW9uIHF1ZXVlXHJcbiAgICBjb25zdCBzdGF0aW9uUXVldWUgPSBQYXRpZW50aW5mby5maW5kKHtpZDppZH0pLmZldGNoKClbMF0uc3RhdGlvblF1ZXVlO1xyXG4gICAgXHJcbiAgICAvLyBGaWx0ZXIgb3V0IHN0YXRpb25cclxuICAgIGNvbnN0IG5ld1F1ZXVlID0gc3RhdGlvblF1ZXVlLmZpbHRlcihmaWVsZCA9PiBmaWVsZCAhPT0gc3RhdGlvblRvU2tpcCk7XHJcbiAgICBjb25zdCBuZXh0U3RhdGlvbiA9ICh0eXBlb2YobmV3UXVldWVbMF0pICE9PSBcInVuZGVmaW5lZFwiKSA/IG5ld1F1ZXVlWzBdIDogXCJEb25lXCI7XHJcbiAgICBjb25zdCBpc0NoYW5naW5nQ3VycmVudCA9IChjdXJyZW50U3RhdGlvbiA9PT0gc3RhdGlvblRvU2tpcCk7XHJcbiAgICBQYXRpZW50aW5mby51cGRhdGUoe2lkOmlkfSx7JHNldDp7bmV4dFN0YXRpb246bmV4dFN0YXRpb24sYnVzeTppc0NoYW5naW5nQ3VycmVudCxzdGF0aW9uUXVldWU6bmV3UXVldWV9fSk7XHJcbiAgfSxcclxuICAncGF0aWVudGluZm8uZWRpdFBhdGllbnRJbmZvJyhpZCwgcGFyZW50LCBsYWJlbCwgdmFsdWUpIHtcclxuICAgIGNvbnNvbGUubG9nKHZhbHVlKTtcclxuICAgIGNvbnN0IGNvbnN0cnVjdE9wZXJhdG9yID0gcGFyZW50ICsgXCIuXCIgKyBsYWJlbDtcclxuICAgIFBhdGllbnRpbmZvLnVwZGF0ZSh7XHJcbiAgICAgIGlkOiBpZFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgJHNldDp7XHJcbiAgICAgICAgW2NvbnN0cnVjdE9wZXJhdG9yXTogdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG59KTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdGF0aW9uZm9ybXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc3RhdGlvbmZvcm1zJyk7XHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgTGlua3MgZnJvbSAnL2ltcG9ydHMvYXBpL2xpbmtzJztcclxuaW1wb3J0IFBhdGllbnRpbmZvIGZyb20gJy9pbXBvcnRzL2FwaS9wYXRpZW50aW5mbyc7XHJcbmltcG9ydCBTdGF0aW9uZm9ybXMgZnJvbSAnL2ltcG9ydHMvYXBpL3N0YXRpb25mb3Jtcyc7XHJcblxyXG5pbXBvcnQgeyBmb3JtTGF5b3V0cyB9IGZyb20gJy9pbXBvcnRzL2FwaS9mb3JtTGF5b3V0cyc7XHJcblxyXG5cclxuZnVuY3Rpb24gYWRkUGF0aWVudChuYW1lLCBpZCwgbmV4dFN0YXRpb24pIHtcclxuICBQYXRpZW50aW5mby5pbnNlcnQoe25hbWU6bmFtZSwgaWQ6aWQsIG5leHRTdGF0aW9uOm5leHRTdGF0aW9uLCBidXN5OmZhbHNlLCBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFkZEZvcm0oc3RhdGlvbiwgZm9ybURhdGEpIHtcclxuICBTdGF0aW9uZm9ybXMuaW5zZXJ0KHtuYW1lOnN0YXRpb24sIGRhdGE6Zm9ybURhdGF9KTtcclxufVxyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gIC8vIFBhdGllbnRpbmZvLnJlbW92ZSh7fSk7XHJcbiAgLy8gU3RhdGlvbmZvcm1zLnJlbW92ZSh7fSk7XHJcblxyXG4gIC8vIFJlc2V0IGFsbCBwYXRpZW50cyB3aG8gd2VyZSBtaWR3YXkgdGhyb3VnaCBhIHN0YXRpb25cclxuICBQYXRpZW50aW5mby51cGRhdGUoeyBidXN5OiB0cnVlIH0se1xyXG4gICAgJHNldDp7IGJ1c3k6IGZhbHNlIH1cclxuICB9LCB7IG11bHRpOiB0cnVlIH0pO1xyXG5cclxuICBpZiAoUGF0aWVudGluZm8uZmluZCgpLmNvdW50KCkgPT09IDApIHtcclxuICAgIFBhdGllbnRpbmZvLmluc2VydCh7XHJcbiAgICAgIGlkOiAnMScsXHJcbiAgICAgIFwiUGF0aWVudCBJbmZvXCI6e1xyXG4gICAgICAgIG5hbWU6ICdUb20nLFxyXG4gICAgICAgIGdlbmRlcjogJ21hbGUnLFxyXG4gICAgICAgIGFnZTogJzI0JyxcclxuICAgICAgICBjb250YWN0TnVtYmVyOiAnMTIzNDQzMjEnLFxyXG4gICAgICAgIHNwb2tlbkxhbmd1YWdlczogWydFbmdsaXNoJywgJ090aGVycyddLFxyXG4gICAgICAgIHdyaXR0ZW5MYW5ndWFnZXM6IFsnRW5nbGlzaCddLFxyXG4gICAgICAgIGFkZHJlc3M6ICdCYWtlciBTdHJlZXQnLFxyXG4gICAgICAgIGFueURydWdBbGxlcmdpZXM6ICdZZXMnLFxyXG4gICAgICAgIGRydWdBbGxlcmdpZXM6ICdQYW5hZG9sJyxcclxuICAgICAgfSxcclxuICAgICAgc3RhdGlvblF1ZXVlOltcIkJsb29kIEdsdWNvc2UgJiBIYlwiLCBcIkJsb29kIFByZXNzdXJlXCIsIFwiUGhsZWJvdG9teVwiLCBcIkRvY3RvcnMnIENvbnN1bHRcIiwgXCJFeWUgU2NyZWVuaW5nXCIsIFwiRWR1Y2F0aW9uXCJdLFxyXG4gICAgICBuZXh0U3RhdGlvbjogJ0hlaWdodCAmIHdlaWdodCcsXHJcbiAgICAgIGJ1c3k6ZmFsc2UsXHJcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKVxyXG4gICAgfSk7XHJcbiAgICBQYXRpZW50aW5mby5pbnNlcnQoe1xyXG4gICAgICBpZDogJzInLFxyXG4gICAgICBcIlBhdGllbnQgSW5mb1wiOntcclxuICAgICAgICBuYW1lOiAnR2FyeScsXHJcbiAgICAgICAgZ2VuZGVyOiAnbWFsZScsXHJcbiAgICAgICAgYWdlOiAnMjQnLFxyXG4gICAgICAgIGNvbnRhY3ROdW1iZXI6ICcxMjM0NDMyMScsXHJcbiAgICAgICAgc3Bva2VuTGFuZ3VhZ2VzOiBbJ0VuZ2xpc2gnLCAnT3RoZXJzJ10sXHJcbiAgICAgICAgd3JpdHRlbkxhbmd1YWdlczogWydFbmdsaXNoJ10sXHJcbiAgICAgICAgYWRkcmVzczogJ0Jha2VyIFN0cmVldCcsXHJcbiAgICAgICAgYW55RHJ1Z0FsbGVyZ2llczogJ05vJyxcclxuICAgICAgfSxcclxuICAgICAgc3RhdGlvblF1ZXVlOltcIkJsb29kIEdsdWNvc2UgJiBIYlwiLCBcIkJsb29kIFByZXNzdXJlXCIsIFwiUGhsZWJvdG9teVwiLCBcIkRvY3RvcnMnIENvbnN1bHRcIixcIkV5ZSBTY3JlZW5pbmdcIiwgXCJFZHVjYXRpb25cIl0sXHJcbiAgICAgIG5leHRTdGF0aW9uOiAnSGVpZ2h0ICYgd2VpZ2h0JyxcclxuICAgICAgYnVzeTpmYWxzZSxcclxuICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXHJcbiAgICB9KTtcclxuICAgIFBhdGllbnRpbmZvLmluc2VydCh7XHJcbiAgICAgIGlkOiAnMycsXHJcbiAgICAgIFwiUGF0aWVudCBJbmZvXCI6e1xyXG4gICAgICAgIG5hbWU6ICdSZXlhbnNoIEFkaXR5YSBWaWhhYW4nLFxyXG4gICAgICAgIGdlbmRlcjogJ21hbGUnLFxyXG4gICAgICAgIGFnZTogJzI0JyxcclxuICAgICAgICBjb250YWN0TnVtYmVyOiAnMTIzNDQzMjEnLFxyXG4gICAgICAgIHNwb2tlbkxhbmd1YWdlczogWydFbmdsaXNoJywgJ090aGVycyddLFxyXG4gICAgICAgIHdyaXR0ZW5MYW5ndWFnZXM6IFsnRW5nbGlzaCddLFxyXG4gICAgICAgIGFkZHJlc3M6ICdCYWtlciBTdHJlZXQnLFxyXG4gICAgICAgIGFueURydWdBbGxlcmdpZXM6ICdZZXMnLFxyXG4gICAgICAgIGRydWdBbGxlcmdpZXM6ICdQYW5hZG9sJyxcclxuICAgICAgfSxcclxuICAgICAgc3RhdGlvblF1ZXVlOiBbXSxcclxuICAgICAgbmV4dFN0YXRpb246ICdFZHVjYXRpb24nLFxyXG4gICAgICBidXN5OmZhbHNlLFxyXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKClcclxuICAgIH0pO1xyXG4gIH1cclxufSk7XHJcbiJdfQ==
